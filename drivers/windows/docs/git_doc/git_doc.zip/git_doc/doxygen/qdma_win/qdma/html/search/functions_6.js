var searchData=
[
  ['read_5fbar',['read_bar',['../classxlnx_1_1qdma__device.html#a49ed61cda4c01c0c19926d127ec5b7f4',1,'xlnx::qdma_device::read_bar()'],['../classxlnx_1_1qdma__interface.html#a329f0f1adf529663d417cff45d10fdc8',1,'xlnx::qdma_interface::read_bar()']]],
  ['remove_5fqdma_5fdevice',['remove_qdma_device',['../classxlnx_1_1qdma__interface.html#a94aaab7e2b8befa644f33c396d5f983f',1,'xlnx::qdma_interface']]]
];
