var searchData=
[
  ['sop',['sop',['../structxlnx_1_1st__c2h__pkt__fragment.html#af959b4f328ddb540dc947dfa247fe8f7',1,'xlnx::st_c2h_pkt_fragment']]],
  ['st_5fcompl_5fcb',['st_compl_cb',['../structxlnx_1_1st__c2h__req.html#a1ff0090b6527681c189e722641b5b9d4',1,'xlnx::st_c2h_req']]],
  ['st_5fen',['st_en',['../structxlnx_1_1qdma__device__attributes__info.html#a271dd4a61932743d0a2b24e13b3c442d',1,'xlnx::qdma_device_attributes_info']]],
  ['st_5fmax_5fdesc_5fdata_5flen',['st_max_desc_data_len',['../qdma_8h.html#a4dd932d2823345293d2ede6f4de6826c',1,'xlnx']]],
  ['start_5fidx',['start_idx',['../structxlnx_1_1qdma__intr__ring__info.html#a50072a494e028c1f3f762695f71f7316',1,'xlnx::qdma_intr_ring_info']]],
  ['sw_5fdesc_5fsz',['sw_desc_sz',['../structxlnx_1_1queue__config.html#ad3e8e5b235ee4c742d1c732535b7fe20',1,'xlnx::queue_config']]]
];
