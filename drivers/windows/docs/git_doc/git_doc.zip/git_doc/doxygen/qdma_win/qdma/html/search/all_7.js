var searchData=
[
  ['init',['init',['../classxlnx_1_1qdma__device.html#aa19590577edb359d2360a134cddbb720',1,'xlnx::qdma_device::init()'],['../classxlnx_1_1qdma__interface.html#ae061a23e68600f8164a4fc0345b21480',1,'xlnx::qdma_interface::init()']]],
  ['intr_5fcoal_5fmode',['INTR_COAL_MODE',['../qdma__exports_8h.html#a8e7a720823699366f2e9fd109c5d7892af35b89b0d09a2de9cf63bc607475faee',1,'xlnx']]],
  ['intr_5fmode',['INTR_MODE',['../qdma__exports_8h.html#a8e7a720823699366f2e9fd109c5d7892aeed2c6112cf246a65da6a160e932e838',1,'xlnx']]],
  ['irq_5fen',['irq_en',['../structxlnx_1_1libqdma__queue__config.html#a9bc9c6ad4f37f41561e2b5efa6040616',1,'xlnx::libqdma_queue_config']]],
  ['is_5fmaster_5fpf',['is_master_pf',['../structxlnx_1_1qdma__dev__conf.html#ab3c23e170d77a814edbf72a569cc82e7',1,'xlnx::qdma_dev_conf']]],
  ['is_5fst',['is_st',['../structxlnx_1_1queue__config.html#a89724ff08d529981e8350a4b04f64ed0',1,'xlnx::queue_config']]]
];
