var searchData=
[
  ['read_5fbar',['read_bar',['../classxlnx_1_1qdma__device.html#a49ed61cda4c01c0c19926d127ec5b7f4',1,'xlnx::qdma_device::read_bar()'],['../classxlnx_1_1qdma__interface.html#a329f0f1adf529663d417cff45d10fdc8',1,'xlnx::qdma_interface::read_bar()']]],
  ['register_5faccess_5flock',['register_access_lock',['../classxlnx_1_1qdma__device.html#a4fe8557f45d10405ed1492a766b55049',1,'xlnx::qdma_device']]],
  ['remove_5fqdma_5fdevice',['remove_qdma_device',['../classxlnx_1_1qdma__interface.html#a94aaab7e2b8befa644f33c396d5f983f',1,'xlnx::qdma_interface']]],
  ['req_5fctx',['req_ctx',['../structxlnx_1_1req__ctx.html',1,'xlnx']]],
  ['requests',['requests',['../structxlnx_1_1dma__req__tracker.html#a5bc08206c3819ba764d7547074635f5e',1,'xlnx::dma_req_tracker']]],
  ['reserved',['reserved',['../structxlnx_1_1st__c2h__pkt__fragment.html#a3251672d6b45f8f09f4d64cc59a0a1b1',1,'xlnx::st_c2h_pkt_fragment']]],
  ['reserved02',['reserved02',['../structxlnx_1_1qdma__dev__conf.html#a5ec0f9bba3248104622a33236f3688be',1,'xlnx::qdma_dev_conf']]],
  ['ret_5flen',['ret_len',['../structxlnx_1_1qdma__cmpt__info.html#a1fa9bfe357865d6515213c92c0b636a8',1,'xlnx::qdma_cmpt_info::ret_len()'],['../structxlnx_1_1qdma__intr__ring__info.html#afca9c1b62cb57fde3fb6cff6f17896cd',1,'xlnx::qdma_intr_ring_info::ret_len()'],['../structxlnx_1_1qdma__reg__dump__info.html#a53a6bec66db41e703937c89875030ddd',1,'xlnx::qdma_reg_dump_info::ret_len()']]],
  ['ret_5fsz',['ret_sz',['../structxlnx_1_1qdma__ctx__info.html#ac6fee7d8244dd8eaadbc74283c2452e0',1,'xlnx::qdma_ctx_info']]],
  ['ring_5fentry_5fsz',['ring_entry_sz',['../structxlnx_1_1qdma__intr__ring__info.html#ac071bb530a3077a06ea370981ae76328',1,'xlnx::qdma_intr_ring_info']]],
  ['ring_5fsz',['ring_sz',['../structxlnx_1_1libqdma__queue__config.html#aff3f27bd42548445d5f3bd172e9b1f7d',1,'xlnx::libqdma_queue_config::ring_sz()'],['../structxlnx_1_1qdma__glbl__csr__conf.html#a04de6db0dd33d2ca3e3590e3667a4c90',1,'xlnx::qdma_glbl_csr_conf::ring_sz()']]],
  ['ring_5ftype',['ring_type',['../structxlnx_1_1qdma__ctx__info.html#a858dc897ed35583d35cb2a502838e94b',1,'xlnx::qdma_ctx_info']]]
];
