var structxlnx_1_1st__c2h__pkt__frag__queue =
[
    [ "max_q_size", "structxlnx_1_1st__c2h__pkt__frag__queue.html#aee7bb981add1c682192cce473e9a3ad6", null ]
];