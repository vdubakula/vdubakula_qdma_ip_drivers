var searchData=
[
  ['device_5foffline',['DEVICE_OFFLINE',['../qdma_8h.html#a9dd97f5e1ca3388e75c3eb120733c39daa897e14c6bc6382db48031c35246a42e',1,'xlnx']]],
  ['device_5fonline',['DEVICE_ONLINE',['../qdma_8h.html#a9dd97f5e1ca3388e75c3eb120733c39da99a6949e0d28e5a272c92e332d0f0694',1,'xlnx']]]
];
