var searchData=
[
  ['data',['data',['../structxlnx_1_1st__c2h__pkt__fragment.html#a98b984b8e37e62458e66a260c9759f3f',1,'xlnx::st_c2h_pkt_fragment']]],
  ['data_5fbuf_5fsize',['data_buf_size',['../structxlnx_1_1libqdma__queue__config.html#ac3b192156439d34de374d32e7dfa05df',1,'xlnx::libqdma_queue_config']]],
  ['data_5fsz',['data_sz',['../structxlnx_1_1qdma__desc__info.html#a6ac894c320e5326b821b6abb6d2b82be',1,'xlnx::qdma_desc_info']]],
  ['desc_5fbypass_5fen',['desc_bypass_en',['../structxlnx_1_1queue__config.html#a7dfc5dc98c3f4e8377e2fbf11bc31eba',1,'xlnx::queue_config']]],
  ['desc_5fend',['desc_end',['../structxlnx_1_1qdma__desc__info.html#aaf38a7a05ba3472a668a8577bcd72fda',1,'xlnx::qdma_desc_info']]],
  ['desc_5fstart',['desc_start',['../structxlnx_1_1qdma__desc__info.html#a9e0165b5c5831c535e786d7399c6a21c',1,'xlnx::qdma_desc_info']]],
  ['desc_5fsz',['desc_sz',['../structxlnx_1_1libqdma__queue__config.html#acd61d327785834a7d6eea490528c7c79',1,'xlnx::libqdma_queue_config::desc_sz()'],['../structxlnx_1_1qdma__desc__info.html#af6aab35b421b059f201bda15c0d506ac',1,'xlnx::qdma_desc_info::desc_sz()']]],
  ['desc_5ftype',['desc_type',['../structxlnx_1_1qdma__desc__info.html#ac5009c7c5f19d5052eb4ffc3dc1241d7',1,'xlnx::qdma_desc_info']]],
  ['dev_5fconf',['dev_conf',['../classxlnx_1_1qdma__device.html#afcd9fd0c77642f0f82ae2bb44de88aac',1,'xlnx::qdma_device']]],
  ['dev_5finfo',['dev_info',['../structxlnx_1_1qdma__dev__conf.html#a2a8540eb355c42f7e5009cb493492d90',1,'xlnx::qdma_dev_conf']]],
  ['dev_5fsbdf',['dev_sbdf',['../structxlnx_1_1qdma__dev__conf.html#a87fe26851cc02eb112c4db790659d0e7',1,'xlnx::qdma_dev_conf']]],
  ['dir',['dir',['../structxlnx_1_1qdma__desc__info.html#ade93f2e3ea004de5337c377d377c3696',1,'xlnx::qdma_desc_info']]],
  ['dma_5fenabler',['dma_enabler',['../classxlnx_1_1qdma__interface.html#a2f6aa099405c89463606a98f75ec3ef7',1,'xlnx::qdma_interface']]]
];
