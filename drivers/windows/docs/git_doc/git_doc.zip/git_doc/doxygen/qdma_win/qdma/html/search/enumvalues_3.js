var searchData=
[
  ['queue_5fadded',['QUEUE_ADDED',['../qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edba8c49517b99f8e9422cb5d7172f5cae54',1,'xlnx']]],
  ['queue_5favailable',['QUEUE_AVAILABLE',['../qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edba0c02f3442d25e70e8bf72a4df12e869b',1,'xlnx']]],
  ['queue_5fbusy',['QUEUE_BUSY',['../qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edba71ae72937b3b30ce6e1d7032a6757e31',1,'xlnx']]],
  ['queue_5fstarted',['QUEUE_STARTED',['../qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edba66f102c009f2614c5054b63e8b9fe448',1,'xlnx']]]
];
