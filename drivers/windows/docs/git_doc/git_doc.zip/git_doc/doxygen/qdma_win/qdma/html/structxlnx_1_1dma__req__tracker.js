var structxlnx_1_1dma__req__tracker =
[
    [ "create", "structxlnx_1_1dma__req__tracker.html#aa54d3ddeefc3eda5404a319b7f91c8a2", null ],
    [ "destroy", "structxlnx_1_1dma__req__tracker.html#a5a33e8e5c38b25c9fdac38494d0d25d2", null ],
    [ "requests", "structxlnx_1_1dma__req__tracker.html#a5bc08206c3819ba764d7547074635f5e", null ]
];