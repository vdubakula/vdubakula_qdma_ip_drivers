var searchData=
[
  ['pbuffer',['pbuffer',['../structxlnx_1_1qdma__desc__info.html#a8c49569cdd8af3ffda179c7d5c301198',1,'xlnx::qdma_desc_info::pbuffer()'],['../structxlnx_1_1qdma__cmpt__info.html#a9fc169550fca945ab05d4b1a78bdf149',1,'xlnx::qdma_cmpt_info::pbuffer()'],['../structxlnx_1_1qdma__ctx__info.html#a8b6a9d2f87f53467ae56c544a64802f0',1,'xlnx::qdma_ctx_info::pbuffer()'],['../structxlnx_1_1qdma__intr__ring__info.html#aad63babc06aa263b515b41405293589f',1,'xlnx::qdma_intr_ring_info::pbuffer()'],['../structxlnx_1_1qdma__reg__dump__info.html#a8281e22324a1c1c059f6395c38839c14',1,'xlnx::qdma_reg_dump_info::pbuffer()']]],
  ['pfch_5fbypass_5fen',['pfch_bypass_en',['../structxlnx_1_1queue__config.html#a4df7eb48ec02cc6e790d71b6610336b7',1,'xlnx::queue_config']]],
  ['pfch_5fen',['pfch_en',['../structxlnx_1_1queue__config.html#aa0e4f89f8126c7b70dcf199f42546332',1,'xlnx::queue_config']]],
  ['pkt_5ftype',['pkt_type',['../structxlnx_1_1st__c2h__pkt__fragment.html#aa42b534579198117acf477e3837ac447',1,'xlnx::st_c2h_pkt_fragment']]],
  ['priv',['priv',['../structxlnx_1_1req__ctx.html#a0179f995623694895bb5ab7f6f8e3d50',1,'xlnx::req_ctx::priv()'],['../structxlnx_1_1st__c2h__req.html#a86bbefa4cef78b3a8776ecbf597d6346',1,'xlnx::st_c2h_req::priv()']]],
  ['proc_5fst_5fudd_5fcb',['proc_st_udd_cb',['../structxlnx_1_1queue__config.html#a6126bbfb97a596febcc73c034c4b8e65',1,'xlnx::queue_config']]]
];
