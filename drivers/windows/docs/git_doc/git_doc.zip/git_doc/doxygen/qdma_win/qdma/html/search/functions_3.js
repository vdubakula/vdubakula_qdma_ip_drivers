var searchData=
[
  ['init',['init',['../classxlnx_1_1qdma__device.html#aa19590577edb359d2360a134cddbb720',1,'xlnx::qdma_device::init()'],['../classxlnx_1_1qdma__interface.html#ae061a23e68600f8164a4fc0345b21480',1,'xlnx::qdma_interface::init()']]]
];
