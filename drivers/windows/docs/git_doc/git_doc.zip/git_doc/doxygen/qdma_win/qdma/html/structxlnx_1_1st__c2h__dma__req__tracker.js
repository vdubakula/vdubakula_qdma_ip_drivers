var structxlnx_1_1st__c2h__dma__req__tracker =
[
    [ "capacity", "structxlnx_1_1st__c2h__dma__req__tracker.html#aeff4e07c7526355022d548d6d0d206e9", null ]
];