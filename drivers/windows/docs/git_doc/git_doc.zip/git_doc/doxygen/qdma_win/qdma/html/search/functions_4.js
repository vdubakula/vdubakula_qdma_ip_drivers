var searchData=
[
  ['open',['open',['../classxlnx_1_1qdma__device.html#a6cbf0b27abcaf0594fe93d6c6e1581ce',1,'xlnx::qdma_device::open()'],['../classxlnx_1_1qdma__interface.html#af3587cb74f4793019a90ea3488236e1a',1,'xlnx::qdma_interface::open()']]]
];
