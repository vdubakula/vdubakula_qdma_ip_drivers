var structxlnx_1_1qdma__version__info =
[
    [ "qdma_rtl_version_str", "structxlnx_1_1qdma__version__info.html#a49444572deb3e03e7a12b27ee24983ad", null ],
    [ "qdma_vivado_release_id_str", "structxlnx_1_1qdma__version__info.html#a4aff3e588e0950c151ec0a4d2454dff6", null ],
    [ "qdma_device_type_str", "structxlnx_1_1qdma__version__info.html#a30ebfa4a734c79159a6cba40e7591d97", null ],
    [ "qdma_versal_ip_type_str", "structxlnx_1_1qdma__version__info.html#a9a0db0db0b606d8411366eb9c777afec", null ],
    [ "qdma_sw_version_str", "structxlnx_1_1qdma__version__info.html#afe5e63aaf6cf9df0b3f7d4740c55f8f5", null ]
];