var searchData=
[
  ['mailbox_5fen',['mailbox_en',['../structxlnx_1_1qdma__device__attributes__info.html#aa8ef630171be6637bfc9fd4c047a8243',1,'xlnx::qdma_device_attributes_info']]],
  ['max_5fq_5fsize',['max_q_size',['../structxlnx_1_1st__c2h__pkt__frag__queue.html#aee7bb981add1c682192cce473e9a3ad6',1,'xlnx::st_c2h_pkt_frag_queue']]],
  ['mm_5fcmpl_5fen',['mm_cmpl_en',['../structxlnx_1_1qdma__device__attributes__info.html#aadc40118da1cc439910606b4f3a51807',1,'xlnx::qdma_device_attributes_info']]],
  ['mm_5fen',['mm_en',['../structxlnx_1_1qdma__device__attributes__info.html#a61826fb830a53fcca7a897da6141d828',1,'xlnx::qdma_device_attributes_info']]]
];
