var structxlnx_1_1qdma__dev__conf =
[
    [ "dev_sbdf", "structxlnx_1_1qdma__dev__conf.html#a87fe26851cc02eb112c4db790659d0e7", null ],
    [ "is_master_pf", "structxlnx_1_1qdma__dev__conf.html#ab3c23e170d77a814edbf72a569cc82e7", null ],
    [ "reserved02", "structxlnx_1_1qdma__dev__conf.html#a5ec0f9bba3248104622a33236f3688be", null ],
    [ "name", "structxlnx_1_1qdma__dev__conf.html#a40921643f3db03db50c8d99f53bc126c", null ],
    [ "dev_info", "structxlnx_1_1qdma__dev__conf.html#a2a8540eb355c42f7e5009cb493492d90", null ]
];