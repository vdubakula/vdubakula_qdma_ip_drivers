var qdma__exports_8h =
[
    [ "qdma_glbl_csr_conf", "structxlnx_1_1qdma__glbl__csr__conf.html", "structxlnx_1_1qdma__glbl__csr__conf" ],
    [ "queue_config", "structxlnx_1_1queue__config.html", "structxlnx_1_1queue__config" ],
    [ "st_c2h_pkt_fragment", "structxlnx_1_1st__c2h__pkt__fragment.html", "structxlnx_1_1st__c2h__pkt__fragment" ],
    [ "qdma_device_attributes_info", "structxlnx_1_1qdma__device__attributes__info.html", "structxlnx_1_1qdma__device__attributes__info" ],
    [ "qdma_version_info", "structxlnx_1_1qdma__version__info.html", "structxlnx_1_1qdma__version__info" ],
    [ "qdma_desc_info", "structxlnx_1_1qdma__desc__info.html", "structxlnx_1_1qdma__desc__info" ],
    [ "qdma_cmpt_info", "structxlnx_1_1qdma__cmpt__info.html", "structxlnx_1_1qdma__cmpt__info" ],
    [ "qdma_ctx_info", "structxlnx_1_1qdma__ctx__info.html", "structxlnx_1_1qdma__ctx__info" ],
    [ "qdma_intr_ring_info", "structxlnx_1_1qdma__intr__ring__info.html", "structxlnx_1_1qdma__intr__ring__info" ],
    [ "qdma_reg_dump_info", "structxlnx_1_1qdma__reg__dump__info.html", "structxlnx_1_1qdma__reg__dump__info" ],
    [ "qdma_qstat_info", "structxlnx_1_1qdma__qstat__info.html", null ],
    [ "qdma_interface", "classxlnx_1_1qdma__interface.html", "classxlnx_1_1qdma__interface" ],
    [ "qdma_queue_dir", "qdma__exports_8h.html#aa52c217fd540ce912cf41a5a1a828975", [
      [ "QDMA_QUEUE_DIR_H2C", "qdma__exports_8h.html#aa52c217fd540ce912cf41a5a1a828975af3a5da2d5306d0545a4d2daca59edc53", null ],
      [ "QDMA_QUEUE_DIR_C2H", "qdma__exports_8h.html#aa52c217fd540ce912cf41a5a1a828975aba141899970d2b896403285dacb5ea90", null ]
    ] ],
    [ "qdma_desc_type", "qdma__exports_8h.html#a5a6723e8923acef089c21bfaeaa2b3a6", null ],
    [ "queue_op_mode", "qdma__exports_8h.html#a8e7a720823699366f2e9fd109c5d7892", [
      [ "POLL_MODE", "qdma__exports_8h.html#a8e7a720823699366f2e9fd109c5d7892a116d3b44028db7a180015bb1654988d7", null ],
      [ "INTR_MODE", "qdma__exports_8h.html#a8e7a720823699366f2e9fd109c5d7892aeed2c6112cf246a65da6a160e932e838", null ],
      [ "INTR_COAL_MODE", "qdma__exports_8h.html#a8e7a720823699366f2e9fd109c5d7892af35b89b0d09a2de9cf63bc607475faee", null ]
    ] ],
    [ "qdma_bar_type", "qdma__exports_8h.html#a61ed8a5377bef794c95e50b0402ef9c4", [
      [ "CONFIG_BAR", "qdma__exports_8h.html#a61ed8a5377bef794c95e50b0402ef9c4a55d4e0eec95d860f6c8ae2854f878ad8", null ],
      [ "USER_BAR", "qdma__exports_8h.html#a61ed8a5377bef794c95e50b0402ef9c4a0539c52b0b74af80f3136d66196f7a04", null ],
      [ "BYPASS_BAR", "qdma__exports_8h.html#a61ed8a5377bef794c95e50b0402ef9c4a01ebb0edf56d6abfa32c34201a4e8bbd", null ]
    ] ],
    [ "QDMA_GLBL_CSR_REG_CNT", "qdma__exports_8h.html#a799a74ea07ac7506793b39e4694b9003", null ]
];