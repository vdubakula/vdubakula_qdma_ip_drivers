var searchData=
[
  ['dma_5freq_5ftracker',['dma_req_tracker',['../structxlnx_1_1dma__req__tracker.html',1,'xlnx']]]
];
