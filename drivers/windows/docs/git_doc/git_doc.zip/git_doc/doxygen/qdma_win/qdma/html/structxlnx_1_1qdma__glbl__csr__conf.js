var structxlnx_1_1qdma__glbl__csr__conf =
[
    [ "ring_sz", "structxlnx_1_1qdma__glbl__csr__conf.html#a04de6db0dd33d2ca3e3590e3667a4c90", null ],
    [ "c2h_timer_cnt", "structxlnx_1_1qdma__glbl__csr__conf.html#a9feee06a1cae21e6e0d725e7d9db72b1", null ],
    [ "c2h_th_cnt", "structxlnx_1_1qdma__glbl__csr__conf.html#a5226ad9532fadff9748b3e784ea4d52d", null ],
    [ "c2h_buff_sz", "structxlnx_1_1qdma__glbl__csr__conf.html#af5cc72842f604d19bb5ccbc06d3dc455", null ],
    [ "wb_interval", "structxlnx_1_1qdma__glbl__csr__conf.html#ac481bb391a9ee56ab43603f09f62c03f", null ]
];