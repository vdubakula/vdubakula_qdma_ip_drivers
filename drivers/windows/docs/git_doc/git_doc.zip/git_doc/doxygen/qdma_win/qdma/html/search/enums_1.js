var searchData=
[
  ['qdma_5fbar_5ftype',['qdma_bar_type',['../qdma__exports_8h.html#a61ed8a5377bef794c95e50b0402ef9c4',1,'xlnx']]],
  ['qdma_5fdesc_5ftype',['qdma_desc_type',['../qdma__exports_8h.html#a5a6723e8923acef089c21bfaeaa2b3a6',1,'xlnx']]],
  ['qdma_5fqueue_5fdir',['qdma_queue_dir',['../qdma__exports_8h.html#aa52c217fd540ce912cf41a5a1a828975',1,'xlnx']]],
  ['queue_5fop_5fmode',['queue_op_mode',['../qdma__exports_8h.html#a8e7a720823699366f2e9fd109c5d7892',1,'xlnx']]],
  ['queue_5fstate',['queue_state',['../qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edb',1,'xlnx']]],
  ['queue_5ftype',['queue_type',['../qdma_8h.html#a0f85e1b4cc3cbabbf713019f837d0340',1,'xlnx']]]
];
