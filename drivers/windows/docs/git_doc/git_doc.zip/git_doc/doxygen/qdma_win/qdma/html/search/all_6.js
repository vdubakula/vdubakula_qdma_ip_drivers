var searchData=
[
  ['h2c_5fring_5fsz_5findex',['h2c_ring_sz_index',['../structxlnx_1_1queue__config.html#af055b01bdcb90a6e5f5af0cfdf8aa57e',1,'xlnx::queue_config']]],
  ['hw',['hw',['../classxlnx_1_1qdma__device.html#a596e5fdafa3378fc1cccf89b09e4d012',1,'xlnx::qdma_device']]]
];
