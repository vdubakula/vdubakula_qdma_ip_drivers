var structxlnx_1_1qdma__desc__info =
[
    [ "qid", "structxlnx_1_1qdma__desc__info.html#a88aaa9c6b0e28057a692af41bea194bd", null ],
    [ "dir", "structxlnx_1_1qdma__desc__info.html#ade93f2e3ea004de5337c377d377c3696", null ],
    [ "desc_type", "structxlnx_1_1qdma__desc__info.html#ac5009c7c5f19d5052eb4ffc3dc1241d7", null ],
    [ "desc_start", "structxlnx_1_1qdma__desc__info.html#a9e0165b5c5831c535e786d7399c6a21c", null ],
    [ "desc_end", "structxlnx_1_1qdma__desc__info.html#aaf38a7a05ba3472a668a8577bcd72fda", null ],
    [ "buffer_sz", "structxlnx_1_1qdma__desc__info.html#a6d00d0f19367e4f50b1c7504e3089af3", null ],
    [ "pbuffer", "structxlnx_1_1qdma__desc__info.html#a8c49569cdd8af3ffda179c7d5c301198", null ],
    [ "desc_sz", "structxlnx_1_1qdma__desc__info.html#af6aab35b421b059f201bda15c0d506ac", null ],
    [ "data_sz", "structxlnx_1_1qdma__desc__info.html#a6ac894c320e5326b821b6abb6d2b82be", null ]
];