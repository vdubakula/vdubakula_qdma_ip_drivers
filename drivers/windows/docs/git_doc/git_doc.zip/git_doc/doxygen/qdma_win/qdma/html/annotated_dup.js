var annotated_dup =
[
    [ "xlnx", null, [
      [ "dma_req_tracker", "structxlnx_1_1dma__req__tracker.html", "structxlnx_1_1dma__req__tracker" ],
      [ "libqdma_queue_config", "structxlnx_1_1libqdma__queue__config.html", "structxlnx_1_1libqdma__queue__config" ],
      [ "qdma_cmpt_info", "structxlnx_1_1qdma__cmpt__info.html", "structxlnx_1_1qdma__cmpt__info" ],
      [ "qdma_ctx_info", "structxlnx_1_1qdma__ctx__info.html", "structxlnx_1_1qdma__ctx__info" ],
      [ "qdma_desc_info", "structxlnx_1_1qdma__desc__info.html", "structxlnx_1_1qdma__desc__info" ],
      [ "qdma_dev_conf", "structxlnx_1_1qdma__dev__conf.html", "structxlnx_1_1qdma__dev__conf" ],
      [ "qdma_device", "classxlnx_1_1qdma__device.html", "classxlnx_1_1qdma__device" ],
      [ "qdma_device_attributes_info", "structxlnx_1_1qdma__device__attributes__info.html", "structxlnx_1_1qdma__device__attributes__info" ],
      [ "qdma_glbl_csr_conf", "structxlnx_1_1qdma__glbl__csr__conf.html", "structxlnx_1_1qdma__glbl__csr__conf" ],
      [ "qdma_interface", "classxlnx_1_1qdma__interface.html", "classxlnx_1_1qdma__interface" ],
      [ "qdma_intr_ring_info", "structxlnx_1_1qdma__intr__ring__info.html", "structxlnx_1_1qdma__intr__ring__info" ],
      [ "qdma_qstat_info", "structxlnx_1_1qdma__qstat__info.html", null ],
      [ "qdma_reg_dump_info", "structxlnx_1_1qdma__reg__dump__info.html", "structxlnx_1_1qdma__reg__dump__info" ],
      [ "qdma_version_info", "structxlnx_1_1qdma__version__info.html", "structxlnx_1_1qdma__version__info" ],
      [ "queue_config", "structxlnx_1_1queue__config.html", "structxlnx_1_1queue__config" ],
      [ "req_ctx", "structxlnx_1_1req__ctx.html", "structxlnx_1_1req__ctx" ],
      [ "st_c2h_dma_req_tracker", "structxlnx_1_1st__c2h__dma__req__tracker.html", "structxlnx_1_1st__c2h__dma__req__tracker" ],
      [ "st_c2h_pkt_frag_queue", "structxlnx_1_1st__c2h__pkt__frag__queue.html", "structxlnx_1_1st__c2h__pkt__frag__queue" ],
      [ "st_c2h_pkt_fragment", "structxlnx_1_1st__c2h__pkt__fragment.html", "structxlnx_1_1st__c2h__pkt__fragment" ],
      [ "st_c2h_req", "structxlnx_1_1st__c2h__req.html", "structxlnx_1_1st__c2h__req" ]
    ] ]
];