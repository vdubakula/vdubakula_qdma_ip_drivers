var indexSectionsWithContent =
{
  0: "_bcdefhilmnopqrstuvw~",
  1: "dlqrs",
  2: "q",
  3: "_cdioqrw~",
  4: "bcdefhilmnpqrstuvw",
  5: "dq",
  6: "dipq",
  7: "q"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

