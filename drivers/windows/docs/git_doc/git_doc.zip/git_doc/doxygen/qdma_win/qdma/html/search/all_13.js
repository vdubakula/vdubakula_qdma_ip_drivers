var searchData=
[
  ['wb_5finterval',['wb_interval',['../structxlnx_1_1qdma__glbl__csr__conf.html#ac481bb391a9ee56ab43603f09f62c03f',1,'xlnx::qdma_glbl_csr_conf']]],
  ['write_5fbar',['write_bar',['../classxlnx_1_1qdma__device.html#a191e1f41cf5abfb54564814102190dac',1,'xlnx::qdma_device::write_bar()'],['../classxlnx_1_1qdma__interface.html#a7bfccb9ed33d905254ebc6a9d987a344',1,'xlnx::qdma_interface::write_bar()']]]
];
