var searchData=
[
  ['buffer_5flen',['buffer_len',['../structxlnx_1_1qdma__cmpt__info.html#adcec570160aecbffe670f3592918a03d',1,'xlnx::qdma_cmpt_info::buffer_len()'],['../structxlnx_1_1qdma__intr__ring__info.html#a05822fed03eeb9e74524c8bbe9489cc1',1,'xlnx::qdma_intr_ring_info::buffer_len()'],['../structxlnx_1_1qdma__reg__dump__info.html#aa0f22666e6e69b116eb506c9aa447fef',1,'xlnx::qdma_reg_dump_info::buffer_len()']]],
  ['buffer_5fsz',['buffer_sz',['../structxlnx_1_1qdma__desc__info.html#a6d00d0f19367e4f50b1c7504e3089af3',1,'xlnx::qdma_desc_info::buffer_sz()'],['../structxlnx_1_1qdma__ctx__info.html#a99b3fddb7d72251cc5006c4a11853e39',1,'xlnx::qdma_ctx_info::buffer_sz()']]]
];
