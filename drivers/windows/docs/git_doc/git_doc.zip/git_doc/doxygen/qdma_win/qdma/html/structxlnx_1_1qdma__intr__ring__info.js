var structxlnx_1_1qdma__intr__ring__info =
[
    [ "vec_id", "structxlnx_1_1qdma__intr__ring__info.html#a56d88670cf359879e329ea9f6c1b167f", null ],
    [ "start_idx", "structxlnx_1_1qdma__intr__ring__info.html#a50072a494e028c1f3f762695f71f7316", null ],
    [ "end_idx", "structxlnx_1_1qdma__intr__ring__info.html#aa024f0504f111c93c6156ba226900143", null ],
    [ "buffer_len", "structxlnx_1_1qdma__intr__ring__info.html#a05822fed03eeb9e74524c8bbe9489cc1", null ],
    [ "ret_len", "structxlnx_1_1qdma__intr__ring__info.html#afca9c1b62cb57fde3fb6cff6f17896cd", null ],
    [ "ring_entry_sz", "structxlnx_1_1qdma__intr__ring__info.html#ac071bb530a3077a06ea370981ae76328", null ],
    [ "pbuffer", "structxlnx_1_1qdma__intr__ring__info.html#aad63babc06aa263b515b41405293589f", null ]
];