var hierarchy =
[
    [ "xlnx::dma_req_tracker", "structxlnx_1_1dma__req__tracker.html", null ],
    [ "xlnx::libqdma_queue_config", "structxlnx_1_1libqdma__queue__config.html", null ],
    [ "xlnx::qdma_cmpt_info", "structxlnx_1_1qdma__cmpt__info.html", null ],
    [ "xlnx::qdma_ctx_info", "structxlnx_1_1qdma__ctx__info.html", null ],
    [ "xlnx::qdma_desc_info", "structxlnx_1_1qdma__desc__info.html", null ],
    [ "xlnx::qdma_dev_conf", "structxlnx_1_1qdma__dev__conf.html", null ],
    [ "xlnx::qdma_device_attributes_info", "structxlnx_1_1qdma__device__attributes__info.html", null ],
    [ "xlnx::qdma_glbl_csr_conf", "structxlnx_1_1qdma__glbl__csr__conf.html", null ],
    [ "xlnx::qdma_interface", "classxlnx_1_1qdma__interface.html", [
      [ "xlnx::qdma_device", "classxlnx_1_1qdma__device.html", null ]
    ] ],
    [ "xlnx::qdma_intr_ring_info", "structxlnx_1_1qdma__intr__ring__info.html", null ],
    [ "xlnx::qdma_qstat_info", "structxlnx_1_1qdma__qstat__info.html", null ],
    [ "xlnx::qdma_reg_dump_info", "structxlnx_1_1qdma__reg__dump__info.html", null ],
    [ "xlnx::qdma_version_info", "structxlnx_1_1qdma__version__info.html", null ],
    [ "xlnx::queue_config", "structxlnx_1_1queue__config.html", null ],
    [ "xlnx::req_ctx", "structxlnx_1_1req__ctx.html", null ],
    [ "xlnx::st_c2h_dma_req_tracker", "structxlnx_1_1st__c2h__dma__req__tracker.html", null ],
    [ "xlnx::st_c2h_pkt_frag_queue", "structxlnx_1_1st__c2h__pkt__frag__queue.html", null ],
    [ "xlnx::st_c2h_pkt_fragment", "structxlnx_1_1st__c2h__pkt__fragment.html", null ],
    [ "xlnx::st_c2h_req", "structxlnx_1_1st__c2h__req.html", null ]
];