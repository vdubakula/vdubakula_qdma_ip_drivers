var searchData=
[
  ['irq_5fen',['irq_en',['../structxlnx_1_1libqdma__queue__config.html#a9bc9c6ad4f37f41561e2b5efa6040616',1,'xlnx::libqdma_queue_config']]],
  ['is_5fmaster_5fpf',['is_master_pf',['../structxlnx_1_1qdma__dev__conf.html#ab3c23e170d77a814edbf72a569cc82e7',1,'xlnx::qdma_dev_conf']]],
  ['is_5fst',['is_st',['../structxlnx_1_1queue__config.html#a89724ff08d529981e8350a4b04f64ed0',1,'xlnx::queue_config']]]
];
