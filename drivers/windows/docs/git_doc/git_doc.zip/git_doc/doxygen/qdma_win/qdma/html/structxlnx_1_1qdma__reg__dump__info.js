var structxlnx_1_1qdma__reg__dump__info =
[
    [ "buffer_len", "structxlnx_1_1qdma__reg__dump__info.html#aa0f22666e6e69b116eb506c9aa447fef", null ],
    [ "ret_len", "structxlnx_1_1qdma__reg__dump__info.html#a53a6bec66db41e703937c89875030ddd", null ],
    [ "pbuffer", "structxlnx_1_1qdma__reg__dump__info.html#a8281e22324a1c1c059f6395c38839c14", null ]
];