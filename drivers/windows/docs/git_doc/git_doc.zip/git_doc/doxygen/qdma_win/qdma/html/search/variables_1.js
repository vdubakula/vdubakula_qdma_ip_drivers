var searchData=
[
  ['c2h_5fbuff_5fsz',['c2h_buff_sz',['../structxlnx_1_1qdma__glbl__csr__conf.html#af5cc72842f604d19bb5ccbc06d3dc455',1,'xlnx::qdma_glbl_csr_conf']]],
  ['c2h_5fbuff_5fsz_5findex',['c2h_buff_sz_index',['../structxlnx_1_1queue__config.html#aedc87cea67d5fa37e70c592f4454db39',1,'xlnx::queue_config']]],
  ['c2h_5fring_5fsz_5findex',['c2h_ring_sz_index',['../structxlnx_1_1queue__config.html#a518a6979bc56c22e1760b948fbf295db',1,'xlnx::queue_config']]],
  ['c2h_5fth_5fcnt',['c2h_th_cnt',['../structxlnx_1_1qdma__glbl__csr__conf.html#a5226ad9532fadff9748b3e784ea4d52d',1,'xlnx::qdma_glbl_csr_conf']]],
  ['c2h_5fth_5fcnt_5findex',['c2h_th_cnt_index',['../structxlnx_1_1queue__config.html#aa27a67980c8cdd4ce34c212ec843e54e',1,'xlnx::queue_config']]],
  ['c2h_5ftimer_5fcnt',['c2h_timer_cnt',['../structxlnx_1_1qdma__glbl__csr__conf.html#a9feee06a1cae21e6e0d725e7d9db72b1',1,'xlnx::qdma_glbl_csr_conf']]],
  ['c2h_5ftimer_5fcnt_5findex',['c2h_timer_cnt_index',['../structxlnx_1_1queue__config.html#aed9bdf261848f516ce6f7ea47849a10f',1,'xlnx::queue_config']]],
  ['capacity',['capacity',['../structxlnx_1_1st__c2h__dma__req__tracker.html#aeff4e07c7526355022d548d6d0d206e9',1,'xlnx::st_c2h_dma_req_tracker']]],
  ['cmpl_5fovf_5fdis',['cmpl_ovf_dis',['../structxlnx_1_1queue__config.html#ac8a28fade793392df9e9411eb2a94e14',1,'xlnx::queue_config']]],
  ['cmpt_5fdesc_5fsz',['cmpt_desc_sz',['../structxlnx_1_1qdma__cmpt__info.html#a0203faa3d1ee3edb358aa3ff36a35819',1,'xlnx::qdma_cmpt_info']]],
  ['cmpt_5fring_5fid',['cmpt_ring_id',['../structxlnx_1_1libqdma__queue__config.html#a1381d7d6afe876cf84ec51c78ead5e45',1,'xlnx::libqdma_queue_config']]],
  ['cmpt_5fring_5fsz',['cmpt_ring_sz',['../structxlnx_1_1libqdma__queue__config.html#a48b3aa60d7d5c0b65f1c4087de86f77e',1,'xlnx::libqdma_queue_config']]],
  ['cmpt_5fsz',['cmpt_sz',['../structxlnx_1_1queue__config.html#a19e267a8ce1b203800cc6005ac77efa8',1,'xlnx::queue_config']]],
  ['compl_5fcb',['compl_cb',['../structxlnx_1_1req__ctx.html#abc9eb93ca612d7b7947908583d30129a',1,'xlnx::req_ctx']]],
  ['csr_5fconf',['csr_conf',['../classxlnx_1_1qdma__device.html#a41563d431085bdc27794c67c2b16a14d',1,'xlnx::qdma_device']]]
];
