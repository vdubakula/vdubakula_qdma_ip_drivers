var structxlnx_1_1qdma__device__attributes__info =
[
    [ "num_pfs", "structxlnx_1_1qdma__device__attributes__info.html#ad9873df8fad6d5185a1528bfeec7cc5d", null ],
    [ "num_qs", "structxlnx_1_1qdma__device__attributes__info.html#aab079177d5f0eda55fed538d1bfafc7c", null ],
    [ "flr_present", "structxlnx_1_1qdma__device__attributes__info.html#a257da303c9a39e4313de3da5a14cb26b", null ],
    [ "st_en", "structxlnx_1_1qdma__device__attributes__info.html#a271dd4a61932743d0a2b24e13b3c442d", null ],
    [ "mm_en", "structxlnx_1_1qdma__device__attributes__info.html#a61826fb830a53fcca7a897da6141d828", null ],
    [ "mm_cmpl_en", "structxlnx_1_1qdma__device__attributes__info.html#aadc40118da1cc439910606b4f3a51807", null ],
    [ "mailbox_en", "structxlnx_1_1qdma__device__attributes__info.html#aa8ef630171be6637bfc9fd4c047a8243", null ],
    [ "num_mm_channels", "structxlnx_1_1qdma__device__attributes__info.html#ae511629b409beeff3db88298510711b8", null ]
];