var structxlnx_1_1qdma__ctx__info =
[
    [ "qid", "structxlnx_1_1qdma__ctx__info.html#a05fb4f29430244814b42b77d9af69417", null ],
    [ "ring_type", "structxlnx_1_1qdma__ctx__info.html#a858dc897ed35583d35cb2a502838e94b", null ],
    [ "buffer_sz", "structxlnx_1_1qdma__ctx__info.html#a99b3fddb7d72251cc5006c4a11853e39", null ],
    [ "ret_sz", "structxlnx_1_1qdma__ctx__info.html#ac6fee7d8244dd8eaadbc74283c2452e0", null ],
    [ "pbuffer", "structxlnx_1_1qdma__ctx__info.html#a8b6a9d2f87f53467ae56c544a64802f0", null ]
];