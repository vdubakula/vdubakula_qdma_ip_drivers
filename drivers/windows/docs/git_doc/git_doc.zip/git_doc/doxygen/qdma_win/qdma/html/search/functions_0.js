var searchData=
[
  ['_5firql_5frequires_5fmax_5f',['_IRQL_requires_max_',['../classxlnx_1_1qdma__interface.html#a853c3c5bd7299268259cdb4655fe32c5',1,'xlnx::qdma_interface::_IRQL_requires_max_(PASSIVE_LEVEL) void *operator new(_In_ size_t num_bytes)'],['../classxlnx_1_1qdma__interface.html#a4999249ce9ff3f6cfd4b6ce8095aecd1',1,'xlnx::qdma_interface::_IRQL_requires_max_(PASSIVE_LEVEL) void operator delete(_In_ void *addr)']]]
];
