var structxlnx_1_1st__c2h__pkt__fragment =
[
    [ "data", "structxlnx_1_1st__c2h__pkt__fragment.html#a98b984b8e37e62458e66a260c9759f3f", null ],
    [ "udd_data", "structxlnx_1_1st__c2h__pkt__fragment.html#a17c8c3222a14cdc6c871dfafcb873091", null ],
    [ "length", "structxlnx_1_1st__c2h__pkt__fragment.html#af82c779e6b82c1ed90e4f45bbd61884d", null ],
    [ "sop", "structxlnx_1_1st__c2h__pkt__fragment.html#af959b4f328ddb540dc947dfa247fe8f7", null ],
    [ "eop", "structxlnx_1_1st__c2h__pkt__fragment.html#aa601c49ac9480ad01704fef4ad2477a8", null ],
    [ "pkt_type", "structxlnx_1_1st__c2h__pkt__fragment.html#aa42b534579198117acf477e3837ac447", null ],
    [ "reserved", "structxlnx_1_1st__c2h__pkt__fragment.html#a3251672d6b45f8f09f4d64cc59a0a1b1", null ]
];