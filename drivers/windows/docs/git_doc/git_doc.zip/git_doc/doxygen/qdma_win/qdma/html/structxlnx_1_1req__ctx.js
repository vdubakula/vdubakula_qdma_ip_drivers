var structxlnx_1_1req__ctx =
[
    [ "priv", "structxlnx_1_1req__ctx.html#a0179f995623694895bb5ab7f6f8e3d50", null ],
    [ "compl_cb", "structxlnx_1_1req__ctx.html#abc9eb93ca612d7b7947908583d30129a", null ]
];