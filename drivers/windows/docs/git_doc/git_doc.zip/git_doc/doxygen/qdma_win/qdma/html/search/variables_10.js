var searchData=
[
  ['vec_5fid',['vec_id',['../structxlnx_1_1qdma__intr__ring__info.html#a56d88670cf359879e329ea9f6c1b167f',1,'xlnx::qdma_intr_ring_info']]],
  ['vector_5fid',['vector_id',['../structxlnx_1_1libqdma__queue__config.html#a55906089150c448d9f420c24cae66877',1,'xlnx::libqdma_queue_config']]]
];
