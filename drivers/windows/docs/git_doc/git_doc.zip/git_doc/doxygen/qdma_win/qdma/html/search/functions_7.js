var searchData=
[
  ['write_5fbar',['write_bar',['../classxlnx_1_1qdma__device.html#a191e1f41cf5abfb54564814102190dac',1,'xlnx::qdma_device::write_bar()'],['../classxlnx_1_1qdma__interface.html#a7bfccb9ed33d905254ebc6a9d987a344',1,'xlnx::qdma_interface::write_bar()']]]
];
