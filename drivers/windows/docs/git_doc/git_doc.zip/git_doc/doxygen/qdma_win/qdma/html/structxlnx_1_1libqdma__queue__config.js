var structxlnx_1_1libqdma__queue__config =
[
    [ "irq_en", "structxlnx_1_1libqdma__queue__config.html#a9bc9c6ad4f37f41561e2b5efa6040616", null ],
    [ "vector_id", "structxlnx_1_1libqdma__queue__config.html#a55906089150c448d9f420c24cae66877", null ],
    [ "desc_sz", "structxlnx_1_1libqdma__queue__config.html#acd61d327785834a7d6eea490528c7c79", null ],
    [ "ring_sz", "structxlnx_1_1libqdma__queue__config.html#aff3f27bd42548445d5f3bd172e9b1f7d", null ],
    [ "cmpt_ring_sz", "structxlnx_1_1libqdma__queue__config.html#a48b3aa60d7d5c0b65f1c4087de86f77e", null ],
    [ "cmpt_ring_id", "structxlnx_1_1libqdma__queue__config.html#a1381d7d6afe876cf84ec51c78ead5e45", null ],
    [ "data_buf_size", "structxlnx_1_1libqdma__queue__config.html#ac3b192156439d34de374d32e7dfa05df", null ]
];