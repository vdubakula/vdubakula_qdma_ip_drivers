var files =
[
    [ "qdma.h", "qdma_8h.html", "qdma_8h" ],
    [ "qdma_exports.h", "qdma__exports_8h.html", "qdma__exports_8h" ]
];