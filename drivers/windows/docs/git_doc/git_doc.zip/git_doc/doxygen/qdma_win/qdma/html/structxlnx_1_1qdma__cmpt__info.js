var structxlnx_1_1qdma__cmpt__info =
[
    [ "qid", "structxlnx_1_1qdma__cmpt__info.html#ae16c7c876208280d489d4342b5ef7c6e", null ],
    [ "buffer_len", "structxlnx_1_1qdma__cmpt__info.html#adcec570160aecbffe670f3592918a03d", null ],
    [ "ret_len", "structxlnx_1_1qdma__cmpt__info.html#a1fa9bfe357865d6515213c92c0b636a8", null ],
    [ "cmpt_desc_sz", "structxlnx_1_1qdma__cmpt__info.html#a0203faa3d1ee3edb358aa3ff36a35819", null ],
    [ "pbuffer", "structxlnx_1_1qdma__cmpt__info.html#a9fc169550fca945ab05d4b1a78bdf149", null ]
];