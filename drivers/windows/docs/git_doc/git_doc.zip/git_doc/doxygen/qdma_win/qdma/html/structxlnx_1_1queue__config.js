var structxlnx_1_1queue__config =
[
    [ "is_st", "structxlnx_1_1queue__config.html#a89724ff08d529981e8350a4b04f64ed0", null ],
    [ "h2c_ring_sz_index", "structxlnx_1_1queue__config.html#af055b01bdcb90a6e5f5af0cfdf8aa57e", null ],
    [ "c2h_ring_sz_index", "structxlnx_1_1queue__config.html#a518a6979bc56c22e1760b948fbf295db", null ],
    [ "c2h_buff_sz_index", "structxlnx_1_1queue__config.html#aedc87cea67d5fa37e70c592f4454db39", null ],
    [ "c2h_th_cnt_index", "structxlnx_1_1queue__config.html#aa27a67980c8cdd4ce34c212ec843e54e", null ],
    [ "c2h_timer_cnt_index", "structxlnx_1_1queue__config.html#aed9bdf261848f516ce6f7ea47849a10f", null ],
    [ "cmpt_sz", "structxlnx_1_1queue__config.html#a19e267a8ce1b203800cc6005ac77efa8", null ],
    [ "trig_mode", "structxlnx_1_1queue__config.html#a20f9ef1f6948a8b6ea3b1450e35dc8d8", null ],
    [ "sw_desc_sz", "structxlnx_1_1queue__config.html#ad3e8e5b235ee4c742d1c732535b7fe20", null ],
    [ "desc_bypass_en", "structxlnx_1_1queue__config.html#a7dfc5dc98c3f4e8377e2fbf11bc31eba", null ],
    [ "pfch_en", "structxlnx_1_1queue__config.html#aa0e4f89f8126c7b70dcf199f42546332", null ],
    [ "pfch_bypass_en", "structxlnx_1_1queue__config.html#a4df7eb48ec02cc6e790d71b6610336b7", null ],
    [ "cmpl_ovf_dis", "structxlnx_1_1queue__config.html#ac8a28fade793392df9e9411eb2a94e14", null ],
    [ "en_mm_cmpl", "structxlnx_1_1queue__config.html#afb56f0d7dff0c7770e17bc889b766dcd", null ],
    [ "proc_st_udd_cb", "structxlnx_1_1queue__config.html#a6126bbfb97a596febcc73c034c4b8e65", null ]
];