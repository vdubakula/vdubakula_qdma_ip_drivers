var searchData=
[
  ['libqdma_5fqueue_5fconfig',['libqdma_queue_config',['../structxlnx_1_1libqdma__queue__config.html',1,'xlnx']]]
];
