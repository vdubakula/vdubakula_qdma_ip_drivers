var searchData=
[
  ['_7eqdma_5finterface',['~qdma_interface',['../classxlnx_1_1qdma__interface.html#ae7675d3f3c6cb1b4650cd13165f2e2d2',1,'xlnx::qdma_interface']]]
];
