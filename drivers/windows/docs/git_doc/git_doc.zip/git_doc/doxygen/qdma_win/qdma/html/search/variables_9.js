var searchData=
[
  ['name',['name',['../structxlnx_1_1qdma__dev__conf.html#a40921643f3db03db50c8d99f53bc126c',1,'xlnx::qdma_dev_conf']]],
  ['num_5fmm_5fchannels',['num_mm_channels',['../structxlnx_1_1qdma__device__attributes__info.html#ae511629b409beeff3db88298510711b8',1,'xlnx::qdma_device_attributes_info']]],
  ['num_5fpfs',['num_pfs',['../structxlnx_1_1qdma__device__attributes__info.html#ad9873df8fad6d5185a1528bfeec7cc5d',1,'xlnx::qdma_device_attributes_info']]],
  ['num_5fqs',['num_qs',['../structxlnx_1_1qdma__device__attributes__info.html#aab079177d5f0eda55fed538d1bfafc7c',1,'xlnx::qdma_device_attributes_info']]]
];
