var searchData=
[
  ['flr_5fpresent',['flr_present',['../structxlnx_1_1qdma__device__attributes__info.html#a257da303c9a39e4313de3da5a14cb26b',1,'xlnx::qdma_device_attributes_info']]]
];
