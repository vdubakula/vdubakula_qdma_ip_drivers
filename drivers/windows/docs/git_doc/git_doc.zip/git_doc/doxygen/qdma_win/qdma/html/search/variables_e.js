var searchData=
[
  ['trig_5fmode',['trig_mode',['../structxlnx_1_1queue__config.html#a20f9ef1f6948a8b6ea3b1450e35dc8d8',1,'xlnx::queue_config']]]
];
