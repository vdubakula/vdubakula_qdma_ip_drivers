var searchData=
[
  ['destroy',['destroy',['../structxlnx_1_1dma__req__tracker.html#a5a33e8e5c38b25c9fdac38494d0d25d2',1,'xlnx::dma_req_tracker']]]
];
