var qdma_8h =
[
    [ "qdma_dev_conf", "structxlnx_1_1qdma__dev__conf.html", "structxlnx_1_1qdma__dev__conf" ],
    [ "st_c2h_pkt_frag_queue", "structxlnx_1_1st__c2h__pkt__frag__queue.html", "structxlnx_1_1st__c2h__pkt__frag__queue" ],
    [ "libqdma_queue_config", "structxlnx_1_1libqdma__queue__config.html", "structxlnx_1_1libqdma__queue__config" ],
    [ "req_ctx", "structxlnx_1_1req__ctx.html", "structxlnx_1_1req__ctx" ],
    [ "dma_req_tracker", "structxlnx_1_1dma__req__tracker.html", "structxlnx_1_1dma__req__tracker" ],
    [ "st_c2h_req", "structxlnx_1_1st__c2h__req.html", "structxlnx_1_1st__c2h__req" ],
    [ "st_c2h_dma_req_tracker", "structxlnx_1_1st__c2h__dma__req__tracker.html", "structxlnx_1_1st__c2h__dma__req__tracker" ],
    [ "qdma_device", "classxlnx_1_1qdma__device.html", "classxlnx_1_1qdma__device" ],
    [ "QDMA_DEV_NAME_MAXLEN", "qdma_8h.html#ab4320c7434dccd6b84e1590fed855e9a", null ],
    [ "queue_type", "qdma_8h.html#a0f85e1b4cc3cbabbf713019f837d0340", [
      [ "MEMORY_MAPPED", "qdma_8h.html#a0f85e1b4cc3cbabbf713019f837d0340a6f184a337f73146a9e5b51f53bf3f38a", null ],
      [ "STREAMING", "qdma_8h.html#a0f85e1b4cc3cbabbf713019f837d0340ab8f87bd0ae829f0fa0fcaa1a0a2bf91e", null ],
      [ "NONE", "qdma_8h.html#a0f85e1b4cc3cbabbf713019f837d0340ab50339a10e1de285ac99d4c3990b8693", null ]
    ] ],
    [ "queue_state", "qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edb", [
      [ "QUEUE_AVAILABLE", "qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edba0c02f3442d25e70e8bf72a4df12e869b", null ],
      [ "QUEUE_ADDED", "qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edba8c49517b99f8e9422cb5d7172f5cae54", null ],
      [ "QUEUE_STARTED", "qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edba66f102c009f2614c5054b63e8b9fe448", null ],
      [ "QUEUE_BUSY", "qdma_8h.html#ad5f8ebb7c782183ce8ce1a3cfc3d5edba71ae72937b3b30ce6e1d7032a6757e31", null ]
    ] ],
    [ "device_state", "qdma_8h.html#a9dd97f5e1ca3388e75c3eb120733c39d", [
      [ "DEVICE_ONLINE", "qdma_8h.html#a9dd97f5e1ca3388e75c3eb120733c39da99a6949e0d28e5a272c92e332d0f0694", null ],
      [ "DEVICE_OFFLINE", "qdma_8h.html#a9dd97f5e1ca3388e75c3eb120733c39daa897e14c6bc6382db48031c35246a42e", null ]
    ] ],
    [ "qdma_version", "qdma_8h.html#a37dec294ec6ac901f186a3bc278f361c", null ],
    [ "st_max_desc_data_len", "qdma_8h.html#a4dd932d2823345293d2ede6f4de6826c", null ]
];