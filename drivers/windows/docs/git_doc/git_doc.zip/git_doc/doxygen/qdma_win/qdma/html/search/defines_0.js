var searchData=
[
  ['qdma_5fdev_5fname_5fmaxlen',['QDMA_DEV_NAME_MAXLEN',['../qdma_8h.html#ab4320c7434dccd6b84e1590fed855e9a',1,'qdma.h']]]
];
