var structxlnx_1_1st__c2h__req =
[
    [ "len", "structxlnx_1_1st__c2h__req.html#a5d8c8533ae1eaec6d1cad1439448991c", null ],
    [ "priv", "structxlnx_1_1st__c2h__req.html#a86bbefa4cef78b3a8776ecbf597d6346", null ],
    [ "st_compl_cb", "structxlnx_1_1st__c2h__req.html#a1ff0090b6527681c189e722641b5b9d4", null ]
];