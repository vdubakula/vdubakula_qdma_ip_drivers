var searchData=
[
  ['device_5fstate',['device_state',['../qdma_8h.html#a9dd97f5e1ca3388e75c3eb120733c39d',1,'xlnx']]]
];
