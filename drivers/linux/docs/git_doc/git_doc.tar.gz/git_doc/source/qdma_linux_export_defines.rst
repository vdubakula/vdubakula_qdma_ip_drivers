
.. include:: ../doxygen/qdma_linux/rst/group_libqdma_defines.rst
