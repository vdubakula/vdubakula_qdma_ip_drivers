var searchData=
[
  ['wb_5fintvl',['wb_intvl',['../structglobal__csr__conf.html#a4a09a626ca50257f82e8c316996154ec',1,'global_csr_conf']]],
  ['wb_5fstatus_5fen',['wb_status_en',['../structqdma__queue__conf.html#a9bfc8a2ced31cb75c3afbd266aa1f985',1,'qdma_queue_conf']]],
  ['write',['write',['../structqdma__request.html#aaf4640f77ca09e2bf2216e3775d4d877',1,'qdma_request']]]
];
