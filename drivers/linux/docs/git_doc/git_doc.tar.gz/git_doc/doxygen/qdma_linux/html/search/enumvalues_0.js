var searchData=
[
  ['auto_5fmode',['AUTO_MODE',['../group__libqdma__enums.html#ggada00378b695c456022546aec7d0e9e32ab1d633b014db4f3b67ec587e14035755',1,'libqdma_export.h']]]
];
