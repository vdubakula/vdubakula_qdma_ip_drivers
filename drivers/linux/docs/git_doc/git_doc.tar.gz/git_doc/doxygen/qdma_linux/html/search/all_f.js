var searchData=
[
  ['ring_5fsz',['ring_sz',['../structglobal__csr__conf.html#a267c2b0898276a84d13c1206e10d2672',1,'global_csr_conf']]],
  ['rngsz',['rngsz',['../structqdma__queue__conf.html#a3e3db4c991d653ad3daf898e091dd1e1',1,'qdma_queue_conf']]],
  ['rngsz_5fcmpt',['rngsz_cmpt',['../structqdma__queue__conf.html#a4f0424af6fc5612da673b902823cd83a',1,'qdma_queue_conf']]],
  ['rsvd',['rsvd',['../structqdma__ul__cmpt__info.html#a8bdebf2a86f01569f05ee3d256ea1df2',1,'qdma_ul_cmpt_info']]],
  ['rsvd1',['rsvd1',['../structqdma__dev__conf.html#a96d8117b8de2f5a8cbf64ea7063fccef',1,'qdma_dev_conf']]],
  ['rsvd2',['rsvd2',['../structqdma__dev__conf.html#ac5ae57008064a5c53e1739a809ebd008',1,'qdma_dev_conf']]],
  ['rtl_5fversion_5fstr',['rtl_version_str',['../structqdma__version__info.html#a9dbdafa1178e24fcf3a3884d108ea3f5',1,'qdma_version_info']]]
];
