var searchData=
[
  ['libqdma_5fexit',['libqdma_exit',['../libqdma__export_8h.html#ae17b39672d285044885a0637dbdf45d1',1,'libqdma_export.h']]],
  ['libqdma_5finit',['libqdma_init',['../libqdma__export_8h.html#a9be491da0929478d3669f05c31ec4aa0',1,'libqdma_export.h']]]
];
