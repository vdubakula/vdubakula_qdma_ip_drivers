var searchData=
[
  ['data_5fmsix_5fqvec_5fmax',['data_msix_qvec_max',['../structqdma__dev__conf.html#a27006da4091d1be72772d1e67fa6a295',1,'qdma_dev_conf']]],
  ['debugfs_5fdev_5froot',['debugfs_dev_root',['../structqdma__dev__conf.html#a30abd21b3456470a5cba8e6af702103b',1,'qdma_dev_conf']]],
  ['desc_5fbypass',['desc_bypass',['../structqdma__queue__conf.html#accf91e2649412db949523d94843b6768',1,'qdma_queue_conf']]],
  ['desc_5frng_5fsz_5fidx',['desc_rng_sz_idx',['../structqdma__queue__conf.html#a5285a4bd136b9a7a10ab0f0f9316f630',1,'qdma_queue_conf']]],
  ['desc_5fsz_5f16b',['DESC_SZ_16B',['../group__libqdma__enums.html#ggad333efea5db7a4bd3ccab5f9c682f995a18e9bc5102572f3e0aa137117ad0456a',1,'libqdma_export.h']]],
  ['desc_5fsz_5f32b',['DESC_SZ_32B',['../group__libqdma__enums.html#ggad333efea5db7a4bd3ccab5f9c682f995a74fbc791b671e1878826305e74bebe56',1,'libqdma_export.h']]],
  ['desc_5fsz_5f64b',['DESC_SZ_64B',['../group__libqdma__enums.html#ggad333efea5db7a4bd3ccab5f9c682f995a455599145898c49ff04e56c27194ed15',1,'libqdma_export.h']]],
  ['desc_5fsz_5f8b',['DESC_SZ_8B',['../group__libqdma__enums.html#ggad333efea5db7a4bd3ccab5f9c682f995aa0a21e5212c6ed3d1931bfb08b1bdab9',1,'libqdma_export.h']]],
  ['desc_5fsz_5ft',['desc_sz_t',['../group__libqdma__enums.html#gad333efea5db7a4bd3ccab5f9c682f995',1,'libqdma_export.h']]],
  ['desc_5fused',['desc_used',['../structqdma__ul__cmpt__info.html#abcfffeda190bc401af358c641787e28a',1,'qdma_ul_cmpt_info']]],
  ['device_5ftype_5fstr',['device_type_str',['../structqdma__version__info.html#a2489509cb87f0824c06010ea1b2a8674',1,'qdma_version_info']]],
  ['device_5fversion_5finfo_5fstr_5flength',['DEVICE_VERSION_INFO_STR_LENGTH',['../group__libqdma__defines.html#gabe6fa2d94e71aa3f740a996b1eaf569a',1,'libqdma_export.h']]],
  ['direct_5fintr_5fmode',['DIRECT_INTR_MODE',['../group__libqdma__enums.html#ggada00378b695c456022546aec7d0e9e32a5a5568ee6bc2a8b32830f3ce76cae84f',1,'libqdma_export.h']]],
  ['dma_5faddr',['dma_addr',['../structqdma__sw__sg.html#a7daec386d7e7355b7767660be7861ace',1,'qdma_sw_sg']]],
  ['dma_5fmapped',['dma_mapped',['../structqdma__request.html#ac1355dce7c53e2a127cb072a9060692c',1,'qdma_request']]],
  ['drv_5fmode',['drv_mode',['../structdrv__mode__name.html#a1d4257c25b4178d82fbd13ed282e417c',1,'drv_mode_name']]],
  ['drv_5fmode_5fname',['drv_mode_name',['../structdrv__mode__name.html',1,'']]],
  ['definitions',['Definitions',['../group__libqdma__defines.html',1,'']]],
  ['data_20structures',['Data Structures',['../group__libqdma__struct.html',1,'']]]
];
