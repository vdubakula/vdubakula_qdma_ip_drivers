.. index:: pair: struct; qdma_ul_cmpt_info
.. _doxid-structqdma__ul__cmpt__info:
.. _cid-qdma_ul_cmpt_info:

struct qdma_ul_cmpt_info
------------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

Completion entry format

Completion Entry is user logic dependent Current SW supported the following completion entry format

.. _doxid-structqdma__ul__cmpt__info_1a95b9e437786b95f2ce9277ef626d3209:
.. _cid-qdma_ul_cmpt_info::f:
.. _doxid-structqdma__ul__cmpt__info_1ab5e770de05c85d392bba3d299088d5af:
.. _cid-qdma_ul_cmpt_info::@1:
.. 	
	// fields

	u8 :ref:`fbits<doxid-structqdma__ul__cmpt__info_1a319f73bfa85a006d7402d87a429ca74d>`
	u8 :ref:`format<doxid-structqdma__ul__cmpt__info_1a0575d0f72bb4004bd0c81e329e8d7ab8>` :1
	u8 :ref:`color<doxid-structqdma__ul__cmpt__info_1a06f3354942311f0404eac2fa83fdba54>` :1
	u8 :ref:`err<doxid-structqdma__ul__cmpt__info_1aa10a0a130ec850f97983bc5ecd46d439>` :1
	u8 :ref:`desc_used<doxid-structqdma__ul__cmpt__info_1abcfffeda190bc401af358c641787e28a>` :1
	u8 :ref:`eot<doxid-structqdma__ul__cmpt__info_1aad9caeb082e420f7ed189a8f6a0ff12e>` :1
	u8 :ref:`filler<doxid-structqdma__ul__cmpt__info_1a6fb816ffe8cdcf67d48809c6993655b5>` :3
	struct qdma_ul_cmpt_info::@0::cmpl_flag f
	u8 :ref:`rsvd<doxid-structqdma__ul__cmpt__info_1a8bdebf2a86f01569f05ee3d256ea1df2>`
	u16 :ref:`len<doxid-structqdma__ul__cmpt__info_1a6d1114401843edb7ddf8fb7861e8b5ba>`
	unsigned int :ref:`pidx<doxid-structqdma__ul__cmpt__info_1a2d4baac6f400430ab8cb3dbadd37348f>`
	__be64* :ref:`entry<doxid-structqdma__ul__cmpt__info_1aca877a815ec1d127f130541571d5dc9c>`

.. rubric:: Fields


.. _doxid-structqdma__ul__cmpt__info_1a319f73bfa85a006d7402d87a429ca74d:
.. _cid-qdma_ul_cmpt_info::fbits:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 fbits

Flag bits

.. _doxid-structqdma__ul__cmpt__info_1a0575d0f72bb4004bd0c81e329e8d7ab8:
.. _cid-qdma_ul_cmpt_info::format:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 format :1

Format of the entry

.. _doxid-structqdma__ul__cmpt__info_1a06f3354942311f0404eac2fa83fdba54:
.. _cid-qdma_ul_cmpt_info::color:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 color :1

Indicates the validity of the entry

.. _doxid-structqdma__ul__cmpt__info_1aa10a0a130ec850f97983bc5ecd46d439:
.. _cid-qdma_ul_cmpt_info::err:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 err :1

Indicates the error status

.. _doxid-structqdma__ul__cmpt__info_1abcfffeda190bc401af358c641787e28a:
.. _cid-qdma_ul_cmpt_info::desc_used:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 desc_used :1

Indicates the descriptor used status

.. _doxid-structqdma__ul__cmpt__info_1aad9caeb082e420f7ed189a8f6a0ff12e:
.. _cid-qdma_ul_cmpt_info::eot:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 eot :1

Indicates the end of transfer

.. _doxid-structqdma__ul__cmpt__info_1a6fb816ffe8cdcf67d48809c6993655b5:
.. _cid-qdma_ul_cmpt_info::filler:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 filler :3

Filler bits

.. _doxid-structqdma__ul__cmpt__info_1a8bdebf2a86f01569f05ee3d256ea1df2:
.. _cid-qdma_ul_cmpt_info::rsvd:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 rsvd

Reserved filed added for structure alignment

.. _doxid-structqdma__ul__cmpt__info_1a6d1114401843edb7ddf8fb7861e8b5ba:
.. _cid-qdma_ul_cmpt_info::len:
.. ref-code-block:: cpp
	:class: title-code-block

	u16 len

Length of the completion entry

.. _doxid-structqdma__ul__cmpt__info_1a2d4baac6f400430ab8cb3dbadd37348f:
.. _cid-qdma_ul_cmpt_info::pidx:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int pidx

Producer Index

.. _doxid-structqdma__ul__cmpt__info_1aca877a815ec1d127f130541571d5dc9c:
.. _cid-qdma_ul_cmpt_info::entry:
.. ref-code-block:: cpp
	:class: title-code-block

	__be64* entry

Completion entry

