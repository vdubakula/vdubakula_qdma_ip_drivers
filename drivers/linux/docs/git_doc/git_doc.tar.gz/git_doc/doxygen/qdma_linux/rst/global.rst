.. _global-namespace:

Global Namespace
================

.. index:: pair: namespace; global








.. 	
	// enums

	enum :ref:`cmpt_desc_sz_t<doxid-group__libqdma__enums_1ga4fde724ed70ff4414fa0ab2d6bbe62d9>`
	enum :ref:`desc_sz_t<doxid-group__libqdma__enums_1gad333efea5db7a4bd3ccab5f9c682f995>`
	enum :ref:`intr_ring_size_sel<doxid-group__libqdma__enums_1gab35fd77940d3f2986774dda02415447c>`
	enum :ref:`q_state_t<doxid-group__libqdma__enums_1ga4e31046f711ac398650a6a56f3c0c0ce>`
	enum :ref:`qdma_dev_qmax_state<doxid-group__libqdma__enums_1ga252f71bb17ef7f319490e0c89f07e5bc>`
	enum :ref:`qdma_drv_mode<doxid-group__libqdma__enums_1gada00378b695c456022546aec7d0e9e32>`
	enum :ref:`qdma_q_dir<doxid-group__libqdma__enums_1gafd6884069689db6ff5c38c7bc0df8ea4>`
	enum :ref:`qdma_q_mode<doxid-group__libqdma__enums_1gaefb7758f05f40e42f0a298b3e55570e4>`
	enum :ref:`queue_type_t<doxid-group__libqdma__enums_1ga65e1a42224ea5650b05097504931ec7e>`
	enum :ref:`tigger_mode_t<doxid-group__libqdma__enums_1ga4bb6156b0570debde51f16f2a8b509a9>`

	// structs

	struct :ref:`drv_mode_name<doxid-structdrv__mode__name>` 
	struct :ref:`global_csr_conf<doxid-structglobal__csr__conf>` 
	struct :ref:`qdma_cmpl_ctrl<doxid-structqdma__cmpl__ctrl>` 
	struct :ref:`qdma_dev_conf<doxid-structqdma__dev__conf>` 
	struct :ref:`qdma_q_state<doxid-structqdma__q__state>` 
	struct :ref:`qdma_q_type<doxid-structqdma__q__type>` 
	struct :ref:`qdma_queue_conf<doxid-structqdma__queue__conf>` 
	struct :ref:`qdma_queue_count<doxid-structqdma__queue__count>` 
	struct :ref:`qdma_request<doxid-structqdma__request>` 
	struct :ref:`qdma_sw_sg<doxid-structqdma__sw__sg>` 
	struct :ref:`qdma_ul_cmpt_info<doxid-structqdma__ul__cmpt__info>` 
	struct :ref:`qdma_version_info<doxid-structqdma__version__info>` 

	// fields

	struct :ref:`drv_mode_name<doxid-structdrv__mode__name>` :ref:`mode_name_list<doxid-group__libqdma__struct_1ga0273499757d4829ebbb4a5d0b682292e>`[]
	struct :ref:`qdma_q_type<doxid-structqdma__q__type>` :ref:`q_type_list<doxid-group__libqdma__struct_1ga5dc4f80a3b9e9ba8b4281f08df757748>`[]

	// macros

	#define :ref:`DEVICE_VERSION_INFO_STR_LENGTH<doxid-group__libqdma__defines_1gabe6fa2d94e71aa3f740a996b1eaf569a>`
	#define :ref:`QDMA_DEV_NAME_MAXLEN<doxid-group__libqdma__defines_1gab4320c7434dccd6b84e1590fed855e9a>`
	#define :ref:`QDMA_FUNC_ID_INVALID<doxid-group__libqdma__defines_1ga5bc05b59b1631e6fa628657bf9eac3b1>`
	#define :ref:`QDMA_QUEUE_IDX_INVALID<doxid-group__libqdma__defines_1gae168a38d476610e8ee964f722f1b0b62>`
	#define :ref:`QDMA_QUEUE_NAME_MAXLEN<doxid-group__libqdma__defines_1ga802600b551da03925a314bc513c23bc4>`
	#define :ref:`QDMA_QUEUE_VEC_INVALID<doxid-group__libqdma__defines_1ga67136280e4723ae4a90175eb523b5f77>`
	#define :ref:`QDMA_REQ_OPAQUE_SIZE<doxid-group__libqdma__defines_1gaf876ffaacb505d5671ce1570ecebd61c>`
	#define :ref:`QDMA_UDD_MAXLEN<doxid-group__libqdma__defines_1gab9b01e82a91686606380701978fc0c56>`


.. FunctionSection

Global Functions
~~~~~~~~~~~~~~~~

.. _doxid-libqdma__export_8h_1a9be491da0929478d3669f05c31ec4aa0:
.. _cid-libqdma_init:

libqdma_init
------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int libqdma_init (
	    unsigned int num_threads,
	    void* debugfs_root
	    )

.. rubric:: Details:

Initializes the QDMA core library



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - num_threads

        - number of threads to be created each for request processing and writeback processing

    *
        - debugfs_root

        - root path for debugfs



.. rubric:: Returns:

0: success <0: error

.. _doxid-libqdma__export_8h_1ae17b39672d285044885a0637dbdf45d1:
.. _cid-libqdma_exit:

libqdma_exit
------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	void libqdma_exit (void)

.. rubric:: Details:

cleanup the QDMA core library before exiting

.. _doxid-libqdma__export_8h_1aefc7d824542af39a820ea9141e8ea6f0:
.. _cid-intr_legacy_init:

intr_legacy_init
----------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	void intr_legacy_init (void)

.. rubric:: Details:

legacy interrupt init

.. _doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64:
.. _cid-qdma_device_open:

qdma_device_open
----------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_open (
	    const char* mod_name,
	    struct :ref:`qdma_dev_conf<doxid-structqdma__dev__conf>`* conf,
	    unsigned long* dev_hndl
	    )

.. rubric:: Details:

Read the pci bars and configure the fpga This API should be called from probe()

User interrupt will not be enabled until qdma_user_isr_enable() is called



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - mod_name

        - the module name, used for request_irq

    *
        - conf

        - device configuration

    *
        - dev_hndl

        - an opaque handle for libqdma to identify the device



.. rubric:: Returns:

0 in case of success and <0 in case of error

.. _doxid-libqdma__export_8h_1a2b4548756ac6440277894c3ef0746ac2:
.. _cid-qdma_device_close:

qdma_device_close
-----------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_close (
	    struct pci_dev* pdev,
	    unsigned long dev_hndl
	    )

.. rubric:: Details:

Prepare fpga for removal: disable all interrupts (users and qdma) and release all resources.This API should be called from remove()



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - pdev

        - ptr to struct pci_dev

    *
        - dev_hndl

        - dev_hndl retured from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`



.. rubric:: Returns:

0 in case of success and <0 in case of error

.. _doxid-libqdma__export_8h_1a0b1d0abc4914f53115d79f504b1e0511:
.. _cid-qdma_device_offline:

qdma_device_offline
-------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_offline (
	    struct pci_dev* pdev,
	    unsigned long dev_hndl,
	    int reset
	    )

.. rubric:: Details:

Set the device in offline mode



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - pdev

        - ptr to struct pci_dev

    *
        - dev_hndl

        - dev_hndl retured from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - reset

        - 0/1 function level reset active or not



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1ad1df411947d3919d4e299422ebb2d9b0:
.. _cid-qdma_device_online:

qdma_device_online
------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_online (
	    struct pci_dev* pdev,
	    unsigned long dev_hndl,
	    int reset
	    )

.. rubric:: Details:

Set the device in online mode and re-initialze it



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - pdev

        - ptr to struct pci_dev

    *
        - dev_hndl

        - dev_hndl retured from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - reset

        - 0/1 function level reset active or not



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1ac4683f6e29a82e036bb5091727cc7ba8:
.. _cid-qdma_device_flr_quirk_set:

qdma_device_flr_quirk_set
-------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_flr_quirk_set (
	    struct pci_dev* pdev,
	    unsigned long dev_hndl
	    )

.. rubric:: Details:

Start pre-flr processing



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - pdev

        - ptr to struct pci_dev

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a8421329dddb9720e06f360c9d466fd99:
.. _cid-qdma_device_flr_quirk_check:

qdma_device_flr_quirk_check
---------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_flr_quirk_check (
	    struct pci_dev* pdev,
	    unsigned long dev_hndl
	    )

.. rubric:: Details:

Check if pre-flr processing completed



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - pdev

        - ptr to struct pci_dev

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`



.. rubric:: Returns:

0 for success <0 for error

.. _doxid-libqdma__export_8h_1a7153b3b7e9f3b10fc8b66ef194990e79:
.. _cid-qdma_device_get_config:

qdma_device_get_config
----------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_get_config (
	    unsigned long dev_hndl,
	    struct :ref:`qdma_dev_conf<doxid-structqdma__dev__conf>`* conf,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Retrieve the current device configuration



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - conf

        - device configuration

    *
        - buflen

        - input buffer length

    *
        - buf

        - error message buffer, can be NULL/0 (i.e., optional)



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a72164fc72ebeb7829d8b7f4af9b15d68:
.. _cid-qdma_device_clear_stats:

qdma_device_clear_stats
-----------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_clear_stats (unsigned long dev_hndl)

.. rubric:: Details:

Clear device statistics



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a0081ac1b973d053aeaf95e154314a40a:
.. _cid-qdma_device_get_mmh2c_pkts:

qdma_device_get_mmh2c_pkts
--------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_get_mmh2c_pkts (
	    unsigned long dev_hndl,
	    unsigned long long* mmh2c_pkts
	    )

.. rubric:: Details:

Get mm h2c packets processed



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - mmh2c_pkts

        - number of mm h2c packets processed



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1aac310b857337898ca9f11e5ab871efd4:
.. _cid-qdma_device_get_mmc2h_pkts:

qdma_device_get_mmc2h_pkts
--------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_get_mmc2h_pkts (
	    unsigned long dev_hndl,
	    unsigned long long* mmc2h_pkts
	    )

.. rubric:: Details:

Get mm c2h packets processed



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - mmc2h_pkts

        - number of mm c2h packets processed



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1aceccdc697f911d6ab6d65e33ebef7a69:
.. _cid-qdma_device_get_sth2c_pkts:

qdma_device_get_sth2c_pkts
--------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_get_sth2c_pkts (
	    unsigned long dev_hndl,
	    unsigned long long* sth2c_pkts
	    )

.. rubric:: Details:

Get st h2c packets processed



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - sth2c_pkts

        - number of st h2c packets processed



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a9c8bddbbfd11db4485a005d9576a82d7:
.. _cid-qdma_device_get_stc2h_pkts:

qdma_device_get_stc2h_pkts
--------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_get_stc2h_pkts (
	    unsigned long dev_hndl,
	    unsigned long long* stc2h_pkts
	    )

.. rubric:: Details:

Get st c2h packets processed



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - stc2h_pkts

        - number of st c2h packets processed



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a84217c0b3564e4a1fc5022f93bf97ad8:
.. _cid-qdma_device_get_ping_pong_min_lat:

qdma_device_get_ping_pong_min_lat
---------------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_get_ping_pong_min_lat (
	    unsigned long dev_hndl,
	    unsigned long long* min_lat
	    )

.. rubric:: Details:

Min latency (in CPU ticks) observed for all packets to do H2C-C2H loopback. Packet is transmitted in ST H2C direction, the user-logic ST Traffic generator is configured to loop back the packet in C2H direction. Timestamp (in CPU ticks) of the H2C transmission is embedded in H2C packet at time of PIDX update, then timestamp of the loopback packet is taken at time when data interrupt is hit, diff is used to measure roundtrip latency.



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - min_lat

        - Minimum ping pong latency in CPU ticks. Divide with the nominal CPU freqeuncy to get latency in NS.



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a6c5810f0d1023639934c49f594acd0cc:
.. _cid-qdma_device_get_ping_pong_max_lat:

qdma_device_get_ping_pong_max_lat
---------------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_get_ping_pong_max_lat (
	    unsigned long dev_hndl,
	    unsigned long long* max_lat
	    )

.. rubric:: Details:

Max latency (in CPU ticks) observed for all packets to do H2C-C2H loopback. Packet is transmitted in ST H2C direction, the user-logic ST Traffic generator is configured to loop back the packet in C2H direction. Timestamp (in CPU ticks) of the H2C transmission is embedded in H2C packet at time of PIDX update, then timestamp of the loopback packet is taken at time when data interrupt is hit, diff is used to measure roundtrip latency.



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - max_lat

        - Max ping pong latency in CPU ticks. Divide with the nominal CPU freqeuncy to get latency in NS.



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a8e758168266479412899c283ca7d1809:
.. _cid-qdma_device_get_ping_pong_tot_lat:

qdma_device_get_ping_pong_tot_lat
---------------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_get_ping_pong_tot_lat (
	    unsigned long dev_hndl,
	    unsigned long long* lat_total
	    )

.. rubric:: Details:

Total latency (in CPU ticks) observed for all packets to do H2C-C2H loopback. Packet is transmitted in ST H2C direction, the user-logic ST Traffic generator is configured to loop back the packet in C2H direction. Timestamp (in CPU ticks) of the H2C transmission is embedded in H2C packet at time of PIDX update, then timestamp of the loopback packet is taken at time when data interrupt is hit, diff is used to measure roundtrip latency.



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl retunred from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - lat_total

        - Total Ping Pong latency. Divide with total loopback C2H packets to get average ping pong latency. Divide further with the nominal CPU frequency to get the avg latency in NS.



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1afd04084cd80dfb6a7c2bd4eb51faaca7:
.. _cid-qdma_device_set_config:

qdma_device_set_config
----------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_set_config (
	    unsigned long dev_hndl,
	    struct :ref:`qdma_dev_conf<doxid-structqdma__dev__conf>`* conf
	    )

.. rubric:: Details:

Set the current device configuration



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - conf

        - device configuration to set



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1ad6374ce2cdca42f55f8d3a0252b8b49f:
.. _cid-qdma_device_sriov_config:

qdma_device_sriov_config
------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_sriov_config (
	    struct pci_dev* pdev,
	    unsigned long dev_hndl,
	    int num_vfs
	    )

.. rubric:: Details:

Configure sriov

configures sriov



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - pdev

        - ptr to struct pci_dev

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - num_vfs

        - # of VFs to be instantiated



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a336f962f589105a2d3d62c8cefb1b106:
.. _cid-qdma_device_read_config_register:

qdma_device_read_config_register
--------------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_read_config_register (
	    unsigned long dev_hndl,
	    unsigned int reg_addr,
	    unsigned int* value
	    )

.. rubric:: Details:

Read dma config register

reads dma config register



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - reg_addr

        - register address

    *
        - value

        - pointer to hold the read value



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1ac51abc604d3d628c3483c90d26fdf875:
.. _cid-qdma_device_write_config_register:

qdma_device_write_config_register
---------------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_write_config_register (
	    unsigned long dev_hndl,
	    unsigned int reg_addr,
	    unsigned int val
	    )

.. rubric:: Details:

Write dma config register



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - reg_addr

        - register address

    *
        - val

        - register value to be writen



.. rubric:: Returns:

0 for success and <0 for error writes dma config register

.. _doxid-libqdma__export_8h_1ad857c394cb2a320dbee117ee13a39a61:
.. _cid-qdma_device_capabilities_info:

qdma_device_capabilities_info
-----------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_capabilities_info (
	    unsigned long dev_hndl,
	    struct qdma_dev_attributes* dev_attr
	    )

.. rubric:: Details:

retrieve the capabilities of a device.



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - handle returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - dev_attr

        - pointer to hold all the device attributes



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a1f7c67271741a3da6efeea2a1aba6efa:
.. _cid-qdma_device_version_info:

qdma_device_version_info
------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_device_version_info (
	    unsigned long dev_hndl,
	    struct :ref:`qdma_version_info<doxid-structqdma__version__info>`* version_info
	    )

.. rubric:: Details:

Retrieve the RTL version , Vivado Release ID and Versal IP info

retrieves the RTL version , Vivado Release ID and Versal IP info



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - handle returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - version_info

        - pointer to hold all the version details



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1af666ae5739179031a7c07bea4f5eb7cf:
.. _cid-qdma_software_version_info:

qdma_software_version_info
--------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_software_version_info (
	    char* software_version,
	    int length
	    )

.. rubric:: Details:

Retrieve the software version

retrieves the software version



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - software_version

        - A pointer to a null-terminated string

    *
        - length

        - Length of the version name string



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1ae8f21a5d6519aa56bdeec87c1288052f:
.. _cid-qdma_global_csr_get:

qdma_global_csr_get
-------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_global_csr_get (
	    unsigned long dev_hndl,
	    u8 index,
	    u8 count,
	    struct :ref:`global_csr_conf<doxid-structglobal__csr__conf>`* csr
	    )

.. rubric:: Details:

Retrieve the global csr settings

retrieves the global csr settings



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - handle returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - index

        - Index from where the values needs to read

    *
        - count

        - number of entries to be read

    *
        - csr

        - data structures to hold the csr values



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1ad4cab740315f3bf19e1674c147cb68a5:
.. _cid-qdma_queue_add:

qdma_queue_add
--------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_add (
	    unsigned long dev_hndl,
	    struct :ref:`qdma_queue_conf<doxid-structqdma__queue__conf>`* qconf,
	    unsigned long* qhndl,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Add a queue



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - qconf

        - queue configuration parameters

    *
        - qhndl

        - list of unsigned long values that are the opaque qhndl

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a39f043a8c668ef39cf97cb4c340334ed:
.. _cid-qdma_queue_config:

qdma_queue_config
-----------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_config (
	    unsigned long dev_hndl,
	    unsigned long qid,
	    struct :ref:`qdma_queue_conf<doxid-structqdma__queue__conf>`* qconf,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Configure the queue with qcong parameters



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - qid

        - queue id

    *
        - qconf

        - queue configuration parameters

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

0: success <0: error

.. _doxid-libqdma__export_8h_1a74326dd1071208637c85bf5626abd96b:
.. _cid-qdma_queue_start:

qdma_queue_start
----------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_start (
	    unsigned long dev_hndl,
	    unsigned long id,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

start a queue (i.e, online, ready for dma)



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - the opaque qhndl

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a9c00516375596381df5368400d1968f4:
.. _cid-qdma_queue_stop:

qdma_queue_stop
---------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_stop (
	    unsigned long dev_hndl,
	    unsigned long id,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Stop a queue (i.e., offline, NOT ready for dma)



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - the opaque qhndl

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a928f60c072a0684181596680d83ffea8:
.. _cid-qdma_get_queue_state:

qdma_get_queue_state
--------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_get_queue_state (
	    unsigned long dev_hndl,
	    unsigned long id,
	    struct :ref:`qdma_q_state<doxid-structqdma__q__state>`* q_state,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Get the state of the queue



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - the opaque qhndl

    *
        - q_state

        - state of the queue

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1ae03433d4617435d20eafbfbeace3758b:
.. _cid-qdma_queue_remove:

qdma_queue_remove
-----------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_remove (
	    unsigned long dev_hndl,
	    unsigned long id,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

remove a queue



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - the opaque qhndl

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

0 for success and <0 for error

.. _doxid-libqdma__export_8h_1a4e21094e499d5a599d822db7b4c57b1f:
.. _cid-qdma_queue_get_config:

qdma_queue_get_config
---------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_get_config (
	    unsigned long dev_hndl,
	    unsigned long id,
	    struct :ref:`qdma_queue_conf<doxid-structqdma__queue__conf>`* qconf,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

retrieve the configuration of a queue



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - an opaque queue handle of type unsigned long

    *
        - qconf

        - pointer to hold the :ref:`qdma_queue_conf <doxid-structqdma__queue__conf>` structure.

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

0: success <0: error

.. _doxid-libqdma__export_8h_1ad05ba3eb049d358fd8edb5e4398ce6eb:
.. _cid-qdma_queue_list:

qdma_queue_list
---------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_list (
	    unsigned long dev_hndl,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Display all configured queues in a string buffer



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

if optional message buffer used then strlen of buf, otherwise QDMA_OPERATION_SUCCESSFUL and <0 for error

.. _doxid-libqdma__export_8h_1a31e2c0ef69baacb4b775bff3d4977dd3:
.. _cid-qdma_config_reg_dump:

qdma_config_reg_dump
--------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_config_reg_dump (
	    unsigned long dev_hndl,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Display a config registers in a string buffer



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

success: if optional message buffer used then strlen of buf, otherwise 0 and <0: error

.. _doxid-libqdma__export_8h_1a147d26dfba5d7c905a31789ef629fc4e:
.. _cid-qdma_queue_dump:

qdma_queue_dump
---------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_dump (
	    unsigned long dev_hndl,
	    unsigned long id,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

display a queue's state in a string buffer



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - an opaque queue handle of type unsigned long

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

if optional message buffer used then strlen of buf, otherwise QDMA_OPERATION_SUCCESSFUL and <0 for error

.. _doxid-libqdma__export_8h_1a70c8137b6882cd1776d3e1e8c8947f6b:
.. _cid-qdma_queue_dump_desc:

qdma_queue_dump_desc
--------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_dump_desc (
	    unsigned long dev_hndl,
	    unsigned long id,
	    unsigned int start,
	    unsigned int end,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Display a queue's descriptor ring from index start ~ end in a string buffer



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - an opaque queue handle of type unsigned long

    *
        - start

        - start index

    *
        - end

        - end index

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

if optional message buffer used then strlen of buf, otherwise QDMA_OPERATION_SUCCESSFUL and <0 for error

.. _doxid-libqdma__export_8h_1a8ed2d13212c31923f6e5dad17cc25492:
.. _cid-qdma_queue_dump_cmpt:

qdma_queue_dump_cmpt
--------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_dump_cmpt (
	    unsigned long dev_hndl,
	    unsigned long id,
	    unsigned int start,
	    unsigned int end,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

display a queue's descriptor ring from index start ~ end in a string buffer



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - an opaque queue handle of type unsigned long

    *
        - start

        - start index

    *
        - end

        - end index

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message buffer



.. rubric:: Returns:

if optional message buffer used then strlen of buf, otherwise QDMA_OPERATION_SUCCESSFUL and <0 for error

.. _doxid-libqdma__export_8h_1ac2ff14d7a19433423c91939b7101e784:
.. _cid-qdma_request_submit:

qdma_request_submit
-------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	ssize_t qdma_request_submit (
	    unsigned long dev_hndl,
	    unsigned long id,
	    struct :ref:`qdma_request<doxid-structqdma__request>`* req
	    )

.. rubric:: Details:

Submit a scatter-gather list of data for dma operation (for both read and write)



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - queue index

    *
        - req

        - qdma request



.. rubric:: Returns:

# of bytes transferred for success and <0 for error

.. _doxid-libqdma__export_8h_1a16bb0aff06abeb856be0157c3dec0289:
.. _cid-qdma_batch_request_submit:

qdma_batch_request_submit
-------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	ssize_t qdma_batch_request_submit (
	    unsigned long dev_hndl,
	    unsigned long id,
	    unsigned long count,
	    struct :ref:`qdma_request<doxid-structqdma__request>`** reqv
	    )

.. rubric:: Details:

Submit a scatter-gather list of data for dma operation (for both read and write)



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - queue index

    *
        - count

        - number of requests

    *
        - reqv

        - qdma request



.. rubric:: Returns:

# of bytes transferred for success and <0 for error

.. _doxid-libqdma__export_8h_1a901bbedd1825a43745ba2405e0551af7:
.. _cid-qdma_queue_c2h_peek:

qdma_queue_c2h_peek
-------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_c2h_peek (
	    unsigned long dev_hndl,
	    unsigned long id,
	    unsigned int* udd_cnt,
	    unsigned int* pkt_cnt,
	    unsigned int* data_len
	    )

.. rubric:: Details:

Peek a receive (c2h) queue

filled in by libqdma:



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - queue hndl returned from :ref:`qdma_queue_add() <doxid-libqdma__export_8h_1ad4cab740315f3bf19e1674c147cb68a5>`

    *
        - udd_cnt

        - # of udd received

    *
        - pkt_cnt

        - # of packets received

    *
        - data_len

        - # of bytes of packet data received



.. rubric:: Returns:

# of packets received in the Q or <0 for error

.. _doxid-libqdma__export_8h_1a65c5650bd3cd810a631808a1036c2a3d:
.. _cid-qdma_queue_avail_desc:

qdma_queue_avail_desc
---------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_avail_desc (
	    unsigned long dev_hndl,
	    unsigned long id
	    )

.. rubric:: Details:

Query of # of free descriptor



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - queue hndl returned from :ref:`qdma_queue_add() <doxid-libqdma__export_8h_1ad4cab740315f3bf19e1674c147cb68a5>`



.. rubric:: Returns:

# of available desc in the queue or <0 for error

.. _doxid-libqdma__export_8h_1aeeca2bdaab031ce6c3ff425212c4f561:
.. _cid-qdma_queue_cmpl_ctrl:

qdma_queue_cmpl_ctrl
--------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_cmpl_ctrl (
	    unsigned long dev_hndl,
	    unsigned long id,
	    struct :ref:`qdma_cmpl_ctrl<doxid-structqdma__cmpl__ctrl>`* cctrl,
	    bool set
	    )

.. rubric:: Details:

packet/streaming interfaces Read/set the c2h Q's completion control



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - hndl returned from :ref:`qdma_queue_add() <doxid-libqdma__export_8h_1ad4cab740315f3bf19e1674c147cb68a5>`

    *
        - cctrl

        - completion control

    *
        - set

        - read or set



.. rubric:: Returns:

0 for success or <0 for error

.. _doxid-libqdma__export_8h_1a839035c2c14e0b95c20d304a261a5ace:
.. _cid-qdma_queue_packet_read:

qdma_queue_packet_read
----------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_packet_read (
	    unsigned long dev_hndl,
	    unsigned long id,
	    struct :ref:`qdma_request<doxid-structqdma__request>`* req,
	    struct :ref:`qdma_cmpl_ctrl<doxid-structqdma__cmpl__ctrl>`* cctrl
	    )

.. rubric:: Details:

Read rcv'ed data (ST C2H dma operation)



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - queue hndl returned from :ref:`qdma_queue_add() <doxid-libqdma__export_8h_1ad4cab740315f3bf19e1674c147cb68a5>`

    *
        - req

        - pointer to the request data

    *
        - cctrl

        - completion control, if no change is desired, set it to NULL



.. rubric:: Returns:

# of bytes transferred for success and <0 for error

.. _doxid-libqdma__export_8h_1a34effa676deb355ecdbf991971fca797:
.. _cid-qdma_queue_packet_write:

qdma_queue_packet_write
-----------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_packet_write (
	    unsigned long dev_hndl,
	    unsigned long id,
	    struct :ref:`qdma_request<doxid-structqdma__request>`* req
	    )

.. rubric:: Details:

Submit data for ST H2C dma operation



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - queue hndl returned from :ref:`qdma_queue_add() <doxid-libqdma__export_8h_1ad4cab740315f3bf19e1674c147cb68a5>`

    *
        - req

        - pointer to the list of packet data



.. rubric:: Returns:

# of bytes transferred for success and <0 for error

.. _doxid-libqdma__export_8h_1a3685b11813567a5ffb6f377a7ab3d02d:
.. _cid-qdma_queue_service:

qdma_queue_service
------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_service (
	    unsigned long dev_hndl,
	    unsigned long id,
	    int budget,
	    bool c2h_upd_cmpl
	    )

.. rubric:: Details:

Service the queue in the case of irq handler is registered by the user, the user should call :ref:`qdma_queue_service() <doxid-libqdma__export_8h_1a3685b11813567a5ffb6f377a7ab3d02d>` in its interrupt handler to service the queue

Return: 0 for success or <0 for error



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - queue hndl returned from :ref:`qdma_queue_add() <doxid-libqdma__export_8h_1ad4cab740315f3bf19e1674c147cb68a5>`

    *
        - budget

        - ST C2H only, max number of completions to be processed.

    *
        - c2h_upd_cmpl

        - flag to update the completion

.. _doxid-libqdma__export_8h_1aa0056ed262621009a8070ae90a96aac6:
.. _cid-qdma_queue_update_pointers:

qdma_queue_update_pointers
--------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_queue_update_pointers (
	    unsigned long dev_hndl,
	    unsigned long qhndl
	    )

.. rubric:: Details:

Update queue pointers

Return: 0 for success or <0 for error



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - qhndl

        - hndl returned from :ref:`qdma_queue_add() <doxid-libqdma__export_8h_1ad4cab740315f3bf19e1674c147cb68a5>`

.. _doxid-libqdma__export_8h_1a6bb13f7e7d8df25ce5f81558ebe9725c:
.. _cid-qdma_intr_ring_dump:

qdma_intr_ring_dump
-------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_intr_ring_dump (
	    unsigned long dev_hndl,
	    unsigned int vector_idx,
	    int start_idx,
	    int end_idx,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Display the interrupt ring info of a vector



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - vector_idx

        - vector number

    *
        - start_idx

        - interrupt ring start idx

    *
        - end_idx

        - interrupt ring end idx

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message bufferuffer



.. rubric:: Returns:

0 for success or <0 for error

.. _doxid-libqdma__export_8h_1a2ac68559a80a2e4685f15800be52cc2a:
.. _cid-qdma_descq_get_cmpt_udd:

qdma_descq_get_cmpt_udd
-----------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_descq_get_cmpt_udd (
	    unsigned long dev_hndl,
	    unsigned long id,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Function to receive the user defined data



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - queue handle

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message bufferuffer



.. rubric:: Returns:

0 for success or <0 for error

.. _doxid-libqdma__export_8h_1a9cc6d7ff2a2ed5d322f0bf88ced2da59:
.. _cid-qdma_descq_read_cmpt_data:

qdma_descq_read_cmpt_data
-------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_descq_read_cmpt_data (
	    unsigned long dev_hndl,
	    unsigned long id,
	    u32* num_entries,
	    u8** cmpt_entries,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Function to receive the completion data



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - id

        - queue handle

    *
        - num_entries

        - I/O number of entries

    *
        - cmpt_entries

        - List of completion entries

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message bufferuffer



.. rubric:: Returns:

0 for success or <0 for error

.. _doxid-libqdma__export_8h_1a4ff23250fd7a270627c84f2441c50fa2:
.. _cid-qdma_get_queue_count:

qdma_get_queue_count
--------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_get_queue_count (
	    unsigned long dev_hndl,
	    struct :ref:`qdma_queue_count<doxid-structqdma__queue__count>`* q_count,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Function to receive the queue count



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - q_count

        - queue count

    *
        - buflen

        - length of the input buffer

    *
        - buf

        - message bufferuffer



.. rubric:: Returns:

0 for success or <0 for error

.. _doxid-libqdma__export_8h_1af66d733e21564fbd53372fc722f5fbd2:
.. _cid-qdma_config_reg_info_dump:

qdma_config_reg_info_dump
-------------------------






.. rubric:: Syntax:
.. ref-code-block:: cpp
	:class: title-code-block

	int qdma_config_reg_info_dump (
	    unsigned long dev_hndl,
	    uint32_t reg_addr,
	    uint32_t num_regs,
	    char* buf,
	    int buflen
	    )

.. rubric:: Details:

Function to print out detailed information for register value



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - dev_hndl returned from :ref:`qdma_device_open() <doxid-libqdma__export_8h_1a1f891b6e4d189bfdec60edafc9679f64>`

    *
        - reg_addr

        - register address

    *
        - num_regs

        - num of registerse to be dumped

    *
        - buf

        - message bufferuffer

    *
        - buflen

        - length of the input buffer



.. rubric:: Returns:

0 for success or <0 for error

