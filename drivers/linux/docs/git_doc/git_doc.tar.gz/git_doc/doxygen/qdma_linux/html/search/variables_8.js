var searchData=
[
  ['latency_5foptimize',['latency_optimize',['../structqdma__queue__conf.html#a0b3b7459a543fbc95f8ebc0d1cf2a23c',1,'qdma_queue_conf']]],
  ['len',['len',['../structqdma__ul__cmpt__info.html#a6d1114401843edb7ddf8fb7861e8b5ba',1,'qdma_ul_cmpt_info::len()'],['../structqdma__sw__sg.html#a0731ded530a969f19abdff2773fa422c',1,'qdma_sw_sg::len()']]]
];
