.. index:: pair: struct; qdma_q_state
.. _doxid-structqdma__q__state:
.. _cid-qdma_q_state:

struct qdma_q_state
-------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

display queue state in a string buffer

.. 	
	// fields

	enum :ref:`q_state_t<doxid-group__libqdma__enums_1ga4e31046f711ac398650a6a56f3c0c0ce>` :ref:`qstate<doxid-structqdma__q__state_1a9583aac3bb7bd9e171fd4cbaa4f4dd54>`
	u32 :ref:`qidx<doxid-structqdma__q__state_1a88369072533880192fa1010cd48b445c>` :24
	u32 :ref:`st<doxid-structqdma__q__state_1a53707522e44fa5ede6911aa1654356e8>` :1
	enum :ref:`queue_type_t<doxid-group__libqdma__enums_1ga65e1a42224ea5650b05097504931ec7e>` :ref:`q_type<doxid-structqdma__q__state_1ac27c4b076a58650e9aae2ac7bac524e9>`

.. rubric:: Fields


.. _doxid-structqdma__q__state_1a9583aac3bb7bd9e171fd4cbaa4f4dd54:
.. _cid-qdma_q_state::qstate:
.. ref-code-block:: cpp
	:class: title-code-block

	enum :ref:`q_state_t<doxid-group__libqdma__enums_1ga4e31046f711ac398650a6a56f3c0c0ce>` qstate

current q state

.. _doxid-structqdma__q__state_1a88369072533880192fa1010cd48b445c:
.. _cid-qdma_q_state::qidx:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 qidx :24

0xFFFF: libqdma choose the queue idx 0 ~ ( :ref:`qdma_dev_conf.qsets_max <doxid-structqdma__dev__conf_1ad601e820f22f1490cfbaadd6f77b372e>` - 1) the calling function choose the queue idx

.. _doxid-structqdma__q__state_1a53707522e44fa5ede6911aa1654356e8:
.. _cid-qdma_q_state::st:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 st :1

Indicates the streaming mode

.. _doxid-structqdma__q__state_1ac27c4b076a58650e9aae2ac7bac524e9:
.. _cid-qdma_q_state::q_type:
.. ref-code-block:: cpp
	:class: title-code-block

	enum :ref:`queue_type_t<doxid-group__libqdma__enums_1ga65e1a42224ea5650b05097504931ec7e>` q_type

queue type

