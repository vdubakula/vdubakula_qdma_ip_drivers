var searchData=
[
  ['intr_5flegacy_5finit',['intr_legacy_init',['../libqdma__export_8h.html#aefc7d824542af39a820ea9141e8ea6f0',1,'libqdma_export.h']]]
];
