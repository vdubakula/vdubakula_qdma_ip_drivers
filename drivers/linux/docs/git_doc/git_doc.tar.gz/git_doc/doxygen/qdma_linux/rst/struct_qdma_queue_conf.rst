.. index:: pair: struct; qdma_queue_conf
.. _doxid-structqdma__queue__conf:
.. _cid-qdma_queue_conf:

struct qdma_queue_conf
----------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

qdma configuration parameters

:ref:`qdma_queue_conf <doxid-structqdma__queue__conf>` defines the per-dma Q property.

.. 	
	// fields

	u32 :ref:`qidx<doxid-structqdma__queue__conf_1a4725b7966fef7ecded5f3386989b0f9e>` :24
	u32 :ref:`st<doxid-structqdma__queue__conf_1a5ef48dd5edb988b4e1c9fea566ef16de>` :1
	u32 :ref:`q_type<doxid-structqdma__queue__conf_1ad3a0b7319b6748762952e5d6527abee3>` :2
	u32 :ref:`pipe<doxid-structqdma__queue__conf_1a0ebb543f4c02ae1b84da97b0804dfa8c>` :1
	u32 :ref:`irq_en<doxid-structqdma__queue__conf_1a7997065967ec5f9b763fcdd9f221210c>` :1
	u32 :ref:`desc_rng_sz_idx<doxid-structqdma__queue__conf_1a5285a4bd136b9a7a10ab0f0f9316f630>` :4
	u8 :ref:`wb_status_en<doxid-structqdma__queue__conf_1a9bfc8a2ced31cb75c3afbd266aa1f985>` :1
	u8 :ref:`cmpl_status_acc_en<doxid-structqdma__queue__conf_1a98ce6f59823abe6ffffbb3113f01fcbe>` :1
	u8 :ref:`cmpl_status_pend_chk<doxid-structqdma__queue__conf_1ab3f98b2a9df69f3e3f4dd495b439c482>` :1
	u8 :ref:`desc_bypass<doxid-structqdma__queue__conf_1accf91e2649412db949523d94843b6768>` :1
	u8 :ref:`pfetch_en<doxid-structqdma__queue__conf_1ad10853ae32442a8042e94333e8588d0c>` :1
	u8 :ref:`fetch_credit<doxid-structqdma__queue__conf_1aa80439aa5fea3c627133930d5093d1cc>` :1
	u8 :ref:`st_pkt_mode<doxid-structqdma__queue__conf_1a358b948e6ee3466d9776659abe2e532c>` :1
	u8 :ref:`c2h_buf_sz_idx<doxid-structqdma__queue__conf_1ab448e6bcba7a10d8692e3ca3cc473bd3>` :4
	u8 :ref:`cmpl_rng_sz_idx<doxid-structqdma__queue__conf_1a5fc8e7e0c08399b0c88ef9921b308302>` :4
	u8 :ref:`cmpl_desc_sz<doxid-structqdma__queue__conf_1ab5bf52ca755013ebbc6130f2ceb21489>` :2
	u8 :ref:`cmpl_stat_en<doxid-structqdma__queue__conf_1a58e2059853cb51a920e004ab398cb2d6>` :1
	u8 :ref:`cmpl_udd_en<doxid-structqdma__queue__conf_1afb9472bf4fdf89e6f2f4ba4612e5f3eb>` :1
	u8 :ref:`cmpl_timer_idx<doxid-structqdma__queue__conf_1aa8fd5c635a619469ab76d5ca5d5af5b3>` :4
	u8 :ref:`cmpl_cnt_th_idx<doxid-structqdma__queue__conf_1a1d9b8d8d7652ce5ebdf0ab8740eaf65e>` :4
	u8 :ref:`cmpl_trig_mode<doxid-structqdma__queue__conf_1a78fbde12289ee7cd81438fbee7e5f88b>` :3
	u8 :ref:`cmpl_en_intr<doxid-structqdma__queue__conf_1aec55d584f809b11d85a1cd1e215e3f87>` :1
	u8 :ref:`sw_desc_sz<doxid-structqdma__queue__conf_1a0efbbcf018bb107b57a4609013b275e9>` :2
	u8 :ref:`pfetch_bypass<doxid-structqdma__queue__conf_1a2e712164964a9a58bf7f72a06aa7fdcf>` :1
	u8 :ref:`cmpl_ovf_chk_dis<doxid-structqdma__queue__conf_1aa23c0afdb4a8f88491ef2db4aa176c06>` :1
	u8 :ref:`port_id<doxid-structqdma__queue__conf_1afcc4dc55eeb6f8d8fcc1c7045e313541>` :3
	u8 :ref:`at<doxid-structqdma__queue__conf_1af14e4c7cf50aad799e47e4a9ba64a594>` :1
	u8 :ref:`adaptive_rx<doxid-structqdma__queue__conf_1a36573a705d8a1cfbd54180daced79cb2>` :1
	u8 :ref:`latency_optimize<doxid-structqdma__queue__conf_1a0b3b7459a543fbc95f8ebc0d1cf2a23c>` :1
	u8 :ref:`init_pidx_dis<doxid-structqdma__queue__conf_1a2d8750b49aa95e7b72896a4993ea9b1f>` :1
	u8 :ref:`mm_channel<doxid-structqdma__queue__conf_1a11887eac0852b13316c0e658c94b2644>` :1
	unsigned long :ref:`quld<doxid-structqdma__queue__conf_1a260f0d4ec91e373f3bc41711a278c175>`
	u32 :ref:`pidx_acc<doxid-structqdma__queue__conf_1a2f96bcbc59435c682ac1d8c043082a9a>` :8
	void (* :ref:`fp_descq_isr_top<doxid-structqdma__queue__conf_1abe3d85ad8047c94af9360fa4edd34b26>`)(unsigned long qhndl, unsigned long quld)
	int (* :ref:`fp_descq_c2h_packet<doxid-structqdma__queue__conf_1a8fa4c78e81b406ff7757220dbf8ca2f7>`)(unsigned long qhndl, unsigned long quld, unsigned int len, unsigned int sgcnt, struct qdma_sw_sg *sgl, void *udd)
	int (* :ref:`fp_bypass_desc_fill<doxid-structqdma__queue__conf_1ad2a7811fb87edc68d9b58e9aa527990d>`)(void *q_hndl, enum qdma_q_mode q_mode, enum qdma_q_dir, struct qdma_request *req)
	int (* :ref:`fp_proc_ul_cmpt_entry<doxid-structqdma__queue__conf_1a0077156b5e0d4071a8542bfc9e56bd26>`)(void *cmpt_entry, struct qdma_ul_cmpt_info *cmpt_info)
	char :ref:`name<doxid-structqdma__queue__conf_1a080b7077b2b749a231b544669e312003>`[QDMA_QUEUE_NAME_MAXLEN]
	unsigned int :ref:`rngsz<doxid-structqdma__queue__conf_1a3e3db4c991d653ad3daf898e091dd1e1>`
	unsigned int :ref:`rngsz_cmpt<doxid-structqdma__queue__conf_1a4f0424af6fc5612da673b902823cd83a>`
	unsigned int :ref:`c2h_bufsz<doxid-structqdma__queue__conf_1ac72bca9c75c0ade6233a5d8cafb665ff>`
	u8 :ref:`ping_pong_en<doxid-structqdma__queue__conf_1aa265902a99ed9ecbc03e643482699ecb>` :1
	u32 :ref:`aperture_size<doxid-structqdma__queue__conf_1a5ce007662077eb7bd6bae219ef30f554>`

.. rubric:: Fields


.. _doxid-structqdma__queue__conf_1a4725b7966fef7ecded5f3386989b0f9e:
.. _cid-qdma_queue_conf::qidx:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 qidx :24



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - qidx

        - 0xFFFF: libqdma choose the queue idx 0 ~ ( :ref:`qdma_dev_conf.qsets_max <doxid-structqdma__dev__conf_1ad601e820f22f1490cfbaadd6f77b372e>` - 1) the calling function choose the queue idx

.. _doxid-structqdma__queue__conf_1a5ef48dd5edb988b4e1c9fea566ef16de:
.. _cid-qdma_queue_conf::st:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 st :1

config flags: byte #1 Indicates the streaming mode

.. _doxid-structqdma__queue__conf_1ad3a0b7319b6748762952e5d6527abee3:
.. _cid-qdma_queue_conf::q_type:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 q_type :2

queue_type_t

.. _doxid-structqdma__queue__conf_1a0ebb543f4c02ae1b84da97b0804dfa8c:
.. _cid-qdma_queue_conf::pipe:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 pipe :1

SDx only: inter-kernel communication pipe

.. _doxid-structqdma__queue__conf_1a7997065967ec5f9b763fcdd9f221210c:
.. _cid-qdma_queue_conf::irq_en:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 irq_en :1

poll or interrupt

.. _doxid-structqdma__queue__conf_1a5285a4bd136b9a7a10ab0f0f9316f630:
.. _cid-qdma_queue_conf::desc_rng_sz_idx:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 desc_rng_sz_idx :4

descriptor ring global_csr_conf.ringsz[N]

.. _doxid-structqdma__queue__conf_1a9bfc8a2ced31cb75c3afbd266aa1f985:
.. _cid-qdma_queue_conf::wb_status_en:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 wb_status_en :1

config flags: byte #2 writeback enable, disabled for ST C2H

.. _doxid-structqdma__queue__conf_1a98ce6f59823abe6ffffbb3113f01fcbe:
.. _cid-qdma_queue_conf::cmpl_status_acc_en:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_status_acc_en :1

sw context.cmpl_status_acc_en

.. _doxid-structqdma__queue__conf_1ab3f98b2a9df69f3e3f4dd495b439c482:
.. _cid-qdma_queue_conf::cmpl_status_pend_chk:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_status_pend_chk :1

sw context.cmpl_stauts_pend_chk

.. _doxid-structqdma__queue__conf_1accf91e2649412db949523d94843b6768:
.. _cid-qdma_queue_conf::desc_bypass:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 desc_bypass :1

send descriptor to bypass out

.. _doxid-structqdma__queue__conf_1ad10853ae32442a8042e94333e8588d0c:
.. _cid-qdma_queue_conf::pfetch_en:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 pfetch_en :1

descriptor prefetch enable control

.. _doxid-structqdma__queue__conf_1aa80439aa5fea3c627133930d5093d1cc:
.. _cid-qdma_queue_conf::fetch_credit:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 fetch_credit :1

sw context.frcd_en[32]

.. _doxid-structqdma__queue__conf_1a358b948e6ee3466d9776659abe2e532c:
.. _cid-qdma_queue_conf::st_pkt_mode:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 st_pkt_mode :1



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - st_pkt_mode

        - SDx only: ST packet mode (i.e., with TLAST to identify the packet boundary)

.. _doxid-structqdma__queue__conf_1ab448e6bcba7a10d8692e3ca3cc473bd3:
.. _cid-qdma_queue_conf::c2h_buf_sz_idx:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 c2h_buf_sz_idx :4

config flags: byte #3 :ref:`global_csr_conf.c2h_buf_sz <doxid-structglobal__csr__conf_1a66e744c84d47c7b26737c770a0a993d4>` [N]

.. _doxid-structqdma__queue__conf_1a5fc8e7e0c08399b0c88ef9921b308302:
.. _cid-qdma_queue_conf::cmpl_rng_sz_idx:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_rng_sz_idx :4

ST C2H Completion/Writeback ring global_csr_conf.ringsz[N]

.. _doxid-structqdma__queue__conf_1ab5bf52ca755013ebbc6130f2ceb21489:
.. _cid-qdma_queue_conf::cmpl_desc_sz:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_desc_sz :2

config flags: byte #4 C2H ST cmpt + immediate data, desc_sz_t

.. _doxid-structqdma__queue__conf_1a58e2059853cb51a920e004ab398cb2d6:
.. _cid-qdma_queue_conf::cmpl_stat_en:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_stat_en :1

enable status desc. for CMPT

.. _doxid-structqdma__queue__conf_1afb9472bf4fdf89e6f2f4ba4612e5f3eb:
.. _cid-qdma_queue_conf::cmpl_udd_en:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_udd_en :1

C2H Completion entry user-defined data

.. _doxid-structqdma__queue__conf_1aa8fd5c635a619469ab76d5ca5d5af5b3:
.. _cid-qdma_queue_conf::cmpl_timer_idx:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_timer_idx :4

:ref:`global_csr_conf.c2h_timer_cnt <doxid-structglobal__csr__conf_1a42511a376379a905e6d7566cb1198523>` [N]

.. _doxid-structqdma__queue__conf_1a1d9b8d8d7652ce5ebdf0ab8740eaf65e:
.. _cid-qdma_queue_conf::cmpl_cnt_th_idx:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_cnt_th_idx :4

config flags byte #5 :ref:`global_csr_conf.c2h_cnt_th <doxid-structglobal__csr__conf_1a75b3e18b9bbee2f3a2336fc7539621a0>` [N]

.. _doxid-structqdma__queue__conf_1a78fbde12289ee7cd81438fbee7e5f88b:
.. _cid-qdma_queue_conf::cmpl_trig_mode:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_trig_mode :3

tigger_mode_t

.. _doxid-structqdma__queue__conf_1aec55d584f809b11d85a1cd1e215e3f87:
.. _cid-qdma_queue_conf::cmpl_en_intr:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_en_intr :1

enable interrupt for CMPT

.. _doxid-structqdma__queue__conf_1a0efbbcf018bb107b57a4609013b275e9:
.. _cid-qdma_queue_conf::sw_desc_sz:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 sw_desc_sz :2

config flags byte #6 SW Context desc size, desc_sz_t

.. _doxid-structqdma__queue__conf_1a2e712164964a9a58bf7f72a06aa7fdcf:
.. _cid-qdma_queue_conf::pfetch_bypass:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 pfetch_bypass :1

prefetch bypass en

.. _doxid-structqdma__queue__conf_1aa23c0afdb4a8f88491ef2db4aa176c06:
.. _cid-qdma_queue_conf::cmpl_ovf_chk_dis:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_ovf_chk_dis :1

OVF_DIS C2H ST over flow disable

.. _doxid-structqdma__queue__conf_1afcc4dc55eeb6f8d8fcc1c7045e313541:
.. _cid-qdma_queue_conf::port_id:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 port_id :3

Port ID

.. _doxid-structqdma__queue__conf_1af14e4c7cf50aad799e47e4a9ba64a594:
.. _cid-qdma_queue_conf::at:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 at :1

Address Translation

.. _doxid-structqdma__queue__conf_1a36573a705d8a1cfbd54180daced79cb2:
.. _cid-qdma_queue_conf::adaptive_rx:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 adaptive_rx :1

Adaptive rx counter threshold

.. _doxid-structqdma__queue__conf_1a0b3b7459a543fbc95f8ebc0d1cf2a23c:
.. _cid-qdma_queue_conf::latency_optimize:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 latency_optimize :1

optimize for latency

.. _doxid-structqdma__queue__conf_1a2d8750b49aa95e7b72896a4993ea9b1f:
.. _cid-qdma_queue_conf::init_pidx_dis:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 init_pidx_dis :1

Disable pidx initialiaztion for ST C2H

.. _doxid-structqdma__queue__conf_1a11887eac0852b13316c0e658c94b2644:
.. _cid-qdma_queue_conf::mm_channel:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 mm_channel :1

MM Channel

.. _doxid-structqdma__queue__conf_1a260f0d4ec91e373f3bc41711a278c175:
.. _cid-qdma_queue_conf::quld:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned long quld

user provided per-Q irq handler

.. _doxid-structqdma__queue__conf_1a2f96bcbc59435c682ac1d8c043082a9a:
.. _cid-qdma_queue_conf::pidx_acc:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 pidx_acc :8

acummulate PIDX to batch packets

.. _doxid-structqdma__queue__conf_1abe3d85ad8047c94af9360fa4edd34b26:
.. _cid-qdma_queue_conf::fp_descq_isr_top:
.. ref-code-block:: cpp
	:class: title-code-block

	void (* fp_descq_isr_top )(unsigned long qhndl, unsigned long quld)

Q interrupt top, per-queue additional handling code for example, network rx napi_schedule(&Q->napi)



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - qhndl

        - Queue handle

    *
        - quld

        - Queue ID

.. _doxid-structqdma__queue__conf_1a8fa4c78e81b406ff7757220dbf8ca2f7:
.. _cid-qdma_queue_conf::fp_descq_c2h_packet:
.. ref-code-block:: cpp
	:class: title-code-block

	int (* fp_descq_c2h_packet )(unsigned long qhndl, unsigned long quld, unsigned int len, unsigned int sgcnt, struct qdma_sw_sg *sgl, void *udd)

optional rx packet handler: called from irq BH (i.e.qdma_queue_service_bh())

a. do NOT modify any field of sgl b. if zero copy, do a get_page() to prevent page freeing c. do loop through the sgl with sg->next and stop at sgcnt. the last sg may not have sg->next = NULL

A single packet could contain: in the case of c2h_udd_en = 1:

udd only (udd valid, sgcnt = 0, sgl = NULL), or udd + packet data in the case of c2h_udd_en = 0: packet data (udd = NULL, sgcnt > 0 and sgl valid)



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - qhndl

        - Queue handle

    *
        - quld

        - Queue ID

    *
        - len

        - Packet Length

    *
        - sgcnt

        - scatter gathher list count

    *
        - sgl

        - packet data in scatter-gather list

    *
        - udd

        - user defined data in the completion entry



.. rubric:: Returns:

0 to allow libqdma free/re-task the sgl < 0, libqdma will keep the packet for processing again

.. _doxid-structqdma__queue__conf_1ad2a7811fb87edc68d9b58e9aa527990d:
.. _cid-qdma_queue_conf::fp_bypass_desc_fill:
.. ref-code-block:: cpp
	:class: title-code-block

	int (* fp_bypass_desc_fill )(void *q_hndl, enum qdma_q_mode q_mode, enum qdma_q_dir, struct qdma_request *req)

fill the all the descriptors required for transfer



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - q_hndl

        - handle with which bypass module can request back info from libqdma

    *
        - q_mode

        - mode in which q is initialized

    *
        - q_dir

        - direction in which q is initialized

    *
        - sgcnt

        - number of scatter gather entries for this request

    *
        - sgl

        - list of scatter gather entries



.. rubric:: Returns:

On calling this API, bypass module can request for descriptor using qdma_q_desc_get and set up as many descriptors as required for each scatter gather entry. If descriptors required are not available, it can return the number of sgcnt addressed till now and return <0 in case of any failure

.. _doxid-structqdma__queue__conf_1a0077156b5e0d4071a8542bfc9e56bd26:
.. _cid-qdma_queue_conf::fp_proc_ul_cmpt_entry:
.. ref-code-block:: cpp
	:class: title-code-block

	int (* fp_proc_ul_cmpt_entry )(void *cmpt_entry, struct qdma_ul_cmpt_info *cmpt_info)

parse cmpt entry in bypass mode



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - cmpt_entry

        - cmpt entry descriptor

    *
        - cmpt_info

        - parsed bypass related info from cmpt_entry



.. rubric:: Returns:

0 for success

.. _doxid-structqdma__queue__conf_1a080b7077b2b749a231b544669e312003:
.. _cid-qdma_queue_conf::name:
.. ref-code-block:: cpp
	:class: title-code-block

	char name [QDMA_QUEUE_NAME_MAXLEN]

Following fileds are filled by libqdma name of the qdma device

.. _doxid-structqdma__queue__conf_1a3e3db4c991d653ad3daf898e091dd1e1:
.. _cid-qdma_queue_conf::rngsz:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int rngsz

ring size of the queue

.. _doxid-structqdma__queue__conf_1a4f0424af6fc5612da673b902823cd83a:
.. _cid-qdma_queue_conf::rngsz_cmpt:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int rngsz_cmpt

completion ring size of the queue

.. _doxid-structqdma__queue__conf_1ac72bca9c75c0ade6233a5d8cafb665ff:
.. _cid-qdma_queue_conf::c2h_bufsz:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int c2h_bufsz

C2H buffer size

.. _doxid-structqdma__queue__conf_1aa265902a99ed9ecbc03e643482699ecb:
.. _cid-qdma_queue_conf::ping_pong_en:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 ping_pong_en :1

Ping Pong measurement

.. _doxid-structqdma__queue__conf_1a5ce007662077eb7bd6bae219ef30f554:
.. _cid-qdma_queue_conf::aperture_size:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 aperture_size

Keyhole Aperture Size

