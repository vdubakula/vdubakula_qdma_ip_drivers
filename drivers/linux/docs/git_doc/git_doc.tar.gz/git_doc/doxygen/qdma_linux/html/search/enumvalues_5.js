var searchData=
[
  ['poll_5fmode',['POLL_MODE',['../group__libqdma__enums.html#ggada00378b695c456022546aec7d0e9e32a31ec31eed700e1eff898af96e9489a88',1,'libqdma_export.h']]]
];
