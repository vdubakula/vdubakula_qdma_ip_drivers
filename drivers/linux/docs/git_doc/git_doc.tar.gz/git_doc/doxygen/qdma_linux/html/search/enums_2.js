var searchData=
[
  ['intr_5fring_5fsize_5fsel',['intr_ring_size_sel',['../group__libqdma__enums.html#gab35fd77940d3f2986774dda02415447c',1,'libqdma_export.h']]]
];
