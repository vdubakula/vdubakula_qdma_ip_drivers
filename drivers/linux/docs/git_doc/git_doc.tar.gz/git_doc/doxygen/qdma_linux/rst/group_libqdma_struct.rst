.. index:: pair: group; Data Structures
.. _doxid-group__libqdma__struct:
.. _cid-libqdma_struct:

Data Structures
###############





.. include:: ../doxygen/qdma_linux/rst/struct_drv_mode_name.rst
.. include:: ../doxygen/qdma_linux/rst/struct_global_csr_conf.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_cmpl_ctrl.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_dev_conf.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_q_state.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_q_type.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_queue_conf.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_queue_count.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_request.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_sw_sg.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_ul_cmpt_info.rst
.. include:: ../doxygen/qdma_linux/rst/struct_qdma_version_info.rst



.. rubric:: Overview



.. 	
	// structs

	struct :ref:`drv_mode_name<doxid-structdrv__mode__name>` 
	struct :ref:`global_csr_conf<doxid-structglobal__csr__conf>` 
	struct :ref:`qdma_cmpl_ctrl<doxid-structqdma__cmpl__ctrl>` 
	struct :ref:`qdma_dev_conf<doxid-structqdma__dev__conf>` 
	struct :ref:`qdma_q_state<doxid-structqdma__q__state>` 
	struct :ref:`qdma_q_type<doxid-structqdma__q__type>` 
	struct :ref:`qdma_queue_conf<doxid-structqdma__queue__conf>` 
	struct :ref:`qdma_queue_count<doxid-structqdma__queue__count>` 
	struct :ref:`qdma_request<doxid-structqdma__request>` 
	struct :ref:`qdma_sw_sg<doxid-structqdma__sw__sg>` 
	struct :ref:`qdma_ul_cmpt_info<doxid-structqdma__ul__cmpt__info>` 
	struct :ref:`qdma_version_info<doxid-structqdma__version__info>` 

	// fields

	struct :ref:`drv_mode_name<doxid-structdrv__mode__name>` :ref:`mode_name_list<doxid-group__libqdma__struct_1ga0273499757d4829ebbb4a5d0b682292e>`[]
	struct :ref:`qdma_q_type<doxid-structqdma__q__type>` :ref:`q_type_list<doxid-group__libqdma__struct_1ga5dc4f80a3b9e9ba8b4281f08df757748>`[]

Global Variables


.. _doxid-group__libqdma__struct_1ga0273499757d4829ebbb4a5d0b682292e:
.. _cid-mode_name_list:
.. ref-code-block:: cpp
	:class: title-code-block

	struct :ref:`drv_mode_name<doxid-structdrv__mode__name>` mode_name_list []

Externel structure definition mode_name_list

.. _doxid-group__libqdma__struct_1ga5dc4f80a3b9e9ba8b4281f08df757748:
.. _cid-q_type_list:
.. ref-code-block:: cpp
	:class: title-code-block

	struct :ref:`qdma_q_type<doxid-structqdma__q__type>` q_type_list []

Externel structure definition q_type_list

