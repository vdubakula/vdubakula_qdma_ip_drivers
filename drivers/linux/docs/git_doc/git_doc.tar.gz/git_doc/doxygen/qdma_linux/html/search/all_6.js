var searchData=
[
  ['global_5fcsr_5fconf',['global_csr_conf',['../structglobal__csr__conf.html',1,'']]]
];
