var searchData=
[
  ['udd',['udd',['../structqdma__request.html#ae9ab34bf75a56af9a3c964544d51132d',1,'qdma_request']]],
  ['udd_5flen',['udd_len',['../structqdma__request.html#a51a8320397525100373ba5bf7f28dc20',1,'qdma_request']]],
  ['uld',['uld',['../structqdma__dev__conf.html#a7d21996961e054ff50baa8c133205b2c',1,'qdma_dev_conf']]],
  ['uld_5fdata',['uld_data',['../structqdma__request.html#aaaa7248d2d481e7293c64fc48edcbdfc',1,'qdma_request']]],
  ['user_5fmsix_5fqvec_5fmax',['user_msix_qvec_max',['../structqdma__dev__conf.html#a3282ef24eea6f4e0156fdb68df4ae740',1,'qdma_dev_conf']]]
];
