.. index:: pair: enum; qdma_q_mode
.. _doxid-group__libqdma__enums_1gaefb7758f05f40e42f0a298b3e55570e4:
.. _cid-qdma_q_mode:

enum qdma_q_mode
----------------




.. rubric:: Overview

Per queue DMA AXI Interface option

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`QDMA_Q_MODE_MM<doxid-group__libqdma__enums_1ggaefb7758f05f40e42f0a298b3e55570e4afa69a275caba58f68d58d206705e4ae0>` 
	:ref:`QDMA_Q_MODE_ST<doxid-group__libqdma__enums_1ggaefb7758f05f40e42f0a298b3e55570e4a77aee435aa599a72b058978178c7df1a>` 

.. _details-doxid-group__libqdma__enums_1gaefb7758f05f40e42f0a298b3e55570e4:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1ggaefb7758f05f40e42f0a298b3e55570e4afa69a275caba58f68d58d206705e4ae0:
.. _cid-qdma_q_mode::qdma_q_mode_mm:

:raw-html:`<tr><td>` 
QDMA_Q_MODE_MM

:raw-html:`</td><td>` 
AXI Memory Mapped Mode

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggaefb7758f05f40e42f0a298b3e55570e4a77aee435aa599a72b058978178c7df1a:
.. _cid-qdma_q_mode::qdma_q_mode_st:

:raw-html:`<tr><td>` 
QDMA_Q_MODE_ST

:raw-html:`</td><td>` 
AXI Stream Mode

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

