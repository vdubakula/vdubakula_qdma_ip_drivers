.. index:: pair: enum; cmpt_desc_sz_t
.. _doxid-group__libqdma__enums_1ga4fde724ed70ff4414fa0ab2d6bbe62d9:
.. _cid-cmpt_desc_sz_t:

enum cmpt_desc_sz_t
-------------------




.. rubric:: Overview

Descriptor sizes

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`CMPT_DESC_SZ_8B<doxid-group__libqdma__enums_1gga4fde724ed70ff4414fa0ab2d6bbe62d9aded13d624d97ca98ab256c2a5cea358c>` = 0
	:ref:`CMPT_DESC_SZ_16B<doxid-group__libqdma__enums_1gga4fde724ed70ff4414fa0ab2d6bbe62d9a2a92d2bb54d04a9aeda33c20084e4327>` 
	:ref:`CMPT_DESC_SZ_32B<doxid-group__libqdma__enums_1gga4fde724ed70ff4414fa0ab2d6bbe62d9a8e434ee2bee74d758d3ce42814660607>` 
	:ref:`CMPT_DESC_SZ_64B<doxid-group__libqdma__enums_1gga4fde724ed70ff4414fa0ab2d6bbe62d9aac5f975c710a60da28613d1c4d9515d5>` 

.. _details-doxid-group__libqdma__enums_1ga4fde724ed70ff4414fa0ab2d6bbe62d9:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1gga4fde724ed70ff4414fa0ab2d6bbe62d9aded13d624d97ca98ab256c2a5cea358c:
.. _cid-cmpt_desc_sz_t::cmpt_desc_sz_8b:

:raw-html:`<tr><td>` 
CMPT_DESC_SZ_8B

:raw-html:`</td><td>` 
completion size 8B

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4fde724ed70ff4414fa0ab2d6bbe62d9a2a92d2bb54d04a9aeda33c20084e4327:
.. _cid-cmpt_desc_sz_t::cmpt_desc_sz_16b:

:raw-html:`<tr><td>` 
CMPT_DESC_SZ_16B

:raw-html:`</td><td>` 
completion size 16B

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4fde724ed70ff4414fa0ab2d6bbe62d9a8e434ee2bee74d758d3ce42814660607:
.. _cid-cmpt_desc_sz_t::cmpt_desc_sz_32b:

:raw-html:`<tr><td>` 
CMPT_DESC_SZ_32B

:raw-html:`</td><td>` 
completion size 32B

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4fde724ed70ff4414fa0ab2d6bbe62d9aac5f975c710a60da28613d1c4d9515d5:
.. _cid-cmpt_desc_sz_t::cmpt_desc_sz_64b:

:raw-html:`<tr><td>` 
CMPT_DESC_SZ_64B

:raw-html:`</td><td>` 
completion size 64B

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

