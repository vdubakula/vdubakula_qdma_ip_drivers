var searchData=
[
  ['zerolen_5fdma',['zerolen_dma',['../structqdma__dev__conf.html#a186714981051de022a9d3324b26ca058',1,'qdma_dev_conf']]]
];
