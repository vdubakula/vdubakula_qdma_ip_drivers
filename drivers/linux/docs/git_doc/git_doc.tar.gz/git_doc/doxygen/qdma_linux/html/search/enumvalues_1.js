var searchData=
[
  ['cmpt_5fdesc_5fsz_5f16b',['CMPT_DESC_SZ_16B',['../group__libqdma__enums.html#gga4fde724ed70ff4414fa0ab2d6bbe62d9a2a92d2bb54d04a9aeda33c20084e4327',1,'libqdma_export.h']]],
  ['cmpt_5fdesc_5fsz_5f32b',['CMPT_DESC_SZ_32B',['../group__libqdma__enums.html#gga4fde724ed70ff4414fa0ab2d6bbe62d9a8e434ee2bee74d758d3ce42814660607',1,'libqdma_export.h']]],
  ['cmpt_5fdesc_5fsz_5f64b',['CMPT_DESC_SZ_64B',['../group__libqdma__enums.html#gga4fde724ed70ff4414fa0ab2d6bbe62d9aac5f975c710a60da28613d1c4d9515d5',1,'libqdma_export.h']]],
  ['cmpt_5fdesc_5fsz_5f8b',['CMPT_DESC_SZ_8B',['../group__libqdma__enums.html#gga4fde724ed70ff4414fa0ab2d6bbe62d9aded13d624d97ca98ab256c2a5cea358c',1,'libqdma_export.h']]]
];
