var searchData=
[
  ['idx',['idx',['../structqdma__dev__conf.html#ad699e13e0430b3708032459bfa83e9f2',1,'qdma_dev_conf']]],
  ['init_5fpidx_5fdis',['init_pidx_dis',['../structqdma__queue__conf.html#a2d8750b49aa95e7b72896a4993ea9b1f',1,'qdma_queue_conf']]],
  ['intr_5fmoderation',['intr_moderation',['../structqdma__dev__conf.html#aa68acda3b40f233d2417a5df4ddc14a6',1,'qdma_dev_conf']]],
  ['intr_5frngsz',['intr_rngsz',['../structqdma__dev__conf.html#abdd65e022d4aba3b838cb0483097acb3',1,'qdma_dev_conf']]],
  ['ip_5fstr',['ip_str',['../structqdma__version__info.html#aa31b441b7c819d64e7b720dd4b31a61d',1,'qdma_version_info']]],
  ['irq_5fen',['irq_en',['../structqdma__queue__conf.html#a7997065967ec5f9b763fcdd9f221210c',1,'qdma_queue_conf']]]
];
