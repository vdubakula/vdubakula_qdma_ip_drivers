var searchData=
[
  ['pdev',['pdev',['../structqdma__dev__conf.html#ad94710251cab15f76e4784c9add9c009',1,'qdma_dev_conf']]],
  ['pfetch_5fbypass',['pfetch_bypass',['../structqdma__queue__conf.html#a2e712164964a9a58bf7f72a06aa7fdcf',1,'qdma_queue_conf']]],
  ['pfetch_5fen',['pfetch_en',['../structqdma__queue__conf.html#ad10853ae32442a8042e94333e8588d0c',1,'qdma_queue_conf']]],
  ['pg',['pg',['../structqdma__sw__sg.html#acc5fa51aee5e1ad7d267606bff9af737',1,'qdma_sw_sg']]],
  ['pidx',['pidx',['../structqdma__ul__cmpt__info.html#a2d4baac6f400430ab8cb3dbadd37348f',1,'qdma_ul_cmpt_info']]],
  ['pidx_5facc',['pidx_acc',['../structqdma__queue__conf.html#a2f96bcbc59435c682ac1d8c043082a9a',1,'qdma_queue_conf']]],
  ['ping_5fpong_5fen',['ping_pong_en',['../structqdma__queue__conf.html#aa265902a99ed9ecbc03e643482699ecb',1,'qdma_queue_conf']]],
  ['pipe',['pipe',['../structqdma__queue__conf.html#a0ebb543f4c02ae1b84da97b0804dfa8c',1,'qdma_queue_conf']]],
  ['port_5fid',['port_id',['../structqdma__queue__conf.html#afcc4dc55eeb6f8d8fcc1c7045e313541',1,'qdma_queue_conf']]]
];
