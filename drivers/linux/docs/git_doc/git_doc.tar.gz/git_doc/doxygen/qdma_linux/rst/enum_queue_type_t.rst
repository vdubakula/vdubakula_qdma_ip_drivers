.. index:: pair: enum; queue_type_t
.. _doxid-group__libqdma__enums_1ga65e1a42224ea5650b05097504931ec7e:
.. _cid-queue_type_t:

enum queue_type_t
-----------------




.. rubric:: Overview

Queue direction types

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`Q_H2C<doxid-group__libqdma__enums_1gga65e1a42224ea5650b05097504931ec7ea8433458edf191b7d40fc6cadff08b198>` 
	:ref:`Q_C2H<doxid-group__libqdma__enums_1gga65e1a42224ea5650b05097504931ec7eab5a1a8fb7f92caca401819adb6a69d6f>` 
	:ref:`Q_CMPT<doxid-group__libqdma__enums_1gga65e1a42224ea5650b05097504931ec7ea1e575ed467420fe24f07cba1d38f1970>` 
	:ref:`Q_H2C_C2H<doxid-group__libqdma__enums_1gga65e1a42224ea5650b05097504931ec7ea9382cc8a13d979fce21f27fba3966513>` 

.. _details-doxid-group__libqdma__enums_1ga65e1a42224ea5650b05097504931ec7e:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1gga65e1a42224ea5650b05097504931ec7ea8433458edf191b7d40fc6cadff08b198:
.. _cid-queue_type_t::q_h2c:

:raw-html:`<tr><td>` 
Q_H2C

:raw-html:`</td><td>` 
host to card

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga65e1a42224ea5650b05097504931ec7eab5a1a8fb7f92caca401819adb6a69d6f:
.. _cid-queue_type_t::q_c2h:

:raw-html:`<tr><td>` 
Q_C2H

:raw-html:`</td><td>` 
card to host

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga65e1a42224ea5650b05097504931ec7ea1e575ed467420fe24f07cba1d38f1970:
.. _cid-queue_type_t::q_cmpt:

:raw-html:`<tr><td>` 
Q_CMPT

:raw-html:`</td><td>` 
cmpt queue

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga65e1a42224ea5650b05097504931ec7ea9382cc8a13d979fce21f27fba3966513:
.. _cid-queue_type_t::q_h2c_c2h:

:raw-html:`<tr><td>` 
Q_H2C_C2H

:raw-html:`</td><td>` 
Both H2C and C2H directions

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

