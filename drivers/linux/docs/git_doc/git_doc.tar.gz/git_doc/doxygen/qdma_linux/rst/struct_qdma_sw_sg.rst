.. index:: pair: struct; qdma_sw_sg
.. _doxid-structqdma__sw__sg:
.. _cid-qdma_sw_sg:

struct qdma_sw_sg
-----------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

qdma scatter gather request

.. 	
	// fields

	struct :ref:`qdma_sw_sg<doxid-structqdma__sw__sg>`* :ref:`next<doxid-structqdma__sw__sg_1ab8b2b733bfc270befae23b6d520878d4>`
	struct page* :ref:`pg<doxid-structqdma__sw__sg_1acc5fa51aee5e1ad7d267606bff9af737>`
	unsigned int :ref:`offset<doxid-structqdma__sw__sg_1a06cc841f6346cc20f1cc21fef6bcd553>`
	unsigned int :ref:`len<doxid-structqdma__sw__sg_1a0731ded530a969f19abdff2773fa422c>`
	dma_addr_t :ref:`dma_addr<doxid-structqdma__sw__sg_1a7daec386d7e7355b7767660be7861ace>`

.. rubric:: Fields


.. _doxid-structqdma__sw__sg_1ab8b2b733bfc270befae23b6d520878d4:
.. _cid-qdma_sw_sg::next:
.. ref-code-block:: cpp
	:class: title-code-block

	struct :ref:`qdma_sw_sg<doxid-structqdma__sw__sg>`* next

pointer to next page

.. _doxid-structqdma__sw__sg_1acc5fa51aee5e1ad7d267606bff9af737:
.. _cid-qdma_sw_sg::pg:
.. ref-code-block:: cpp
	:class: title-code-block

	struct page* pg

pointer to current page

.. _doxid-structqdma__sw__sg_1a06cc841f6346cc20f1cc21fef6bcd553:
.. _cid-qdma_sw_sg::offset:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int offset

offset in current page

.. _doxid-structqdma__sw__sg_1a0731ded530a969f19abdff2773fa422c:
.. _cid-qdma_sw_sg::len:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int len

length of the page

.. _doxid-structqdma__sw__sg_1a7daec386d7e7355b7767660be7861ace:
.. _cid-qdma_sw_sg::dma_addr:
.. ref-code-block:: cpp
	:class: title-code-block

	dma_addr_t dma_addr

dma address of the allocated page

