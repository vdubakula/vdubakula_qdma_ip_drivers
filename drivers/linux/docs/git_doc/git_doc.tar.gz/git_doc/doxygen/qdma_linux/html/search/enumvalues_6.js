var searchData=
[
  ['q_5fc2h',['Q_C2H',['../group__libqdma__enums.html#gga65e1a42224ea5650b05097504931ec7eab5a1a8fb7f92caca401819adb6a69d6f',1,'libqdma_export.h']]],
  ['q_5fcmpt',['Q_CMPT',['../group__libqdma__enums.html#gga65e1a42224ea5650b05097504931ec7ea1e575ed467420fe24f07cba1d38f1970',1,'libqdma_export.h']]],
  ['q_5fh2c',['Q_H2C',['../group__libqdma__enums.html#gga65e1a42224ea5650b05097504931ec7ea8433458edf191b7d40fc6cadff08b198',1,'libqdma_export.h']]],
  ['q_5fh2c_5fc2h',['Q_H2C_C2H',['../group__libqdma__enums.html#gga65e1a42224ea5650b05097504931ec7ea9382cc8a13d979fce21f27fba3966513',1,'libqdma_export.h']]],
  ['q_5fstate_5fdisabled',['Q_STATE_DISABLED',['../group__libqdma__enums.html#gga4e31046f711ac398650a6a56f3c0c0cea6f166bafd5b4a912832660bc5522189b',1,'libqdma_export.h']]],
  ['q_5fstate_5fenabled',['Q_STATE_ENABLED',['../group__libqdma__enums.html#gga4e31046f711ac398650a6a56f3c0c0cea1f20a89daa0f08b31d3bf8d1a75fba54',1,'libqdma_export.h']]],
  ['q_5fstate_5fonline',['Q_STATE_ONLINE',['../group__libqdma__enums.html#gga4e31046f711ac398650a6a56f3c0c0ceaf1fc79e81f91a149607c34d50f9ad82a',1,'libqdma_export.h']]],
  ['qdma_5fq_5fdir_5fc2h',['QDMA_Q_DIR_C2H',['../group__libqdma__enums.html#ggafd6884069689db6ff5c38c7bc0df8ea4afd0f9583e9738f39c60ce11a9daaf017',1,'libqdma_export.h']]],
  ['qdma_5fq_5fdir_5fh2c',['QDMA_Q_DIR_H2C',['../group__libqdma__enums.html#ggafd6884069689db6ff5c38c7bc0df8ea4ada5a9c4994b3ca19581e88dea2c1d660',1,'libqdma_export.h']]],
  ['qdma_5fq_5fmode_5fmm',['QDMA_Q_MODE_MM',['../group__libqdma__enums.html#ggaefb7758f05f40e42f0a298b3e55570e4afa69a275caba58f68d58d206705e4ae0',1,'libqdma_export.h']]],
  ['qdma_5fq_5fmode_5fst',['QDMA_Q_MODE_ST',['../group__libqdma__enums.html#ggaefb7758f05f40e42f0a298b3e55570e4a77aee435aa599a72b058978178c7df1a',1,'libqdma_export.h']]],
  ['qmax_5fcfg_5finitial',['QMAX_CFG_INITIAL',['../group__libqdma__enums.html#gga252f71bb17ef7f319490e0c89f07e5bcae7b5498579feaa334085d9f683d5599b',1,'libqdma_export.h']]],
  ['qmax_5fcfg_5funconfigured',['QMAX_CFG_UNCONFIGURED',['../group__libqdma__enums.html#gga252f71bb17ef7f319490e0c89f07e5bca835db2d933a25969bc774c9ab68e6992',1,'libqdma_export.h']]],
  ['qmax_5fcfg_5fuser',['QMAX_CFG_USER',['../group__libqdma__enums.html#gga252f71bb17ef7f319490e0c89f07e5bca1330593c4f0420936cd38e647ecb249f',1,'libqdma_export.h']]]
];
