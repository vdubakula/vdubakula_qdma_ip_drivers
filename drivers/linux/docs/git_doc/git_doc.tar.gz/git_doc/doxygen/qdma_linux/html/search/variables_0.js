var searchData=
[
  ['adaptive_5frx',['adaptive_rx',['../structqdma__queue__conf.html#a36573a705d8a1cfbd54180daced79cb2',1,'qdma_queue_conf']]],
  ['aperture_5fsize',['aperture_size',['../structqdma__queue__conf.html#a5ce007662077eb7bd6bae219ef30f554',1,'qdma_queue_conf']]],
  ['at',['at',['../structqdma__queue__conf.html#af14e4c7cf50aad799e47e4a9ba64a594',1,'qdma_queue_conf']]]
];
