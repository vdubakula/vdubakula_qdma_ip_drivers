var searchData=
[
  ['tigger_5fmode_5ft',['tigger_mode_t',['../group__libqdma__enums.html#ga4bb6156b0570debde51f16f2a8b509a9',1,'libqdma_export.h']]]
];
