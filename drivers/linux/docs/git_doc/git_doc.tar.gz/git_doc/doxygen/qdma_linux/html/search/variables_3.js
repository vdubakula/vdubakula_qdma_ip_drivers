var searchData=
[
  ['data_5fmsix_5fqvec_5fmax',['data_msix_qvec_max',['../structqdma__dev__conf.html#a27006da4091d1be72772d1e67fa6a295',1,'qdma_dev_conf']]],
  ['debugfs_5fdev_5froot',['debugfs_dev_root',['../structqdma__dev__conf.html#a30abd21b3456470a5cba8e6af702103b',1,'qdma_dev_conf']]],
  ['desc_5fbypass',['desc_bypass',['../structqdma__queue__conf.html#accf91e2649412db949523d94843b6768',1,'qdma_queue_conf']]],
  ['desc_5frng_5fsz_5fidx',['desc_rng_sz_idx',['../structqdma__queue__conf.html#a5285a4bd136b9a7a10ab0f0f9316f630',1,'qdma_queue_conf']]],
  ['desc_5fused',['desc_used',['../structqdma__ul__cmpt__info.html#abcfffeda190bc401af358c641787e28a',1,'qdma_ul_cmpt_info']]],
  ['device_5ftype_5fstr',['device_type_str',['../structqdma__version__info.html#a2489509cb87f0824c06010ea1b2a8674',1,'qdma_version_info']]],
  ['dma_5faddr',['dma_addr',['../structqdma__sw__sg.html#a7daec386d7e7355b7767660be7861ace',1,'qdma_sw_sg']]],
  ['dma_5fmapped',['dma_mapped',['../structqdma__request.html#ac1355dce7c53e2a127cb072a9060692c',1,'qdma_request']]],
  ['drv_5fmode',['drv_mode',['../structdrv__mode__name.html#a1d4257c25b4178d82fbd13ed282e417c',1,'drv_mode_name']]]
];
