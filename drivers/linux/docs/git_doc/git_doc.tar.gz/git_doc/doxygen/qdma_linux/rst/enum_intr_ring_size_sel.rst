.. index:: pair: enum; intr_ring_size_sel
.. _doxid-group__libqdma__enums_1gab35fd77940d3f2986774dda02415447c:
.. _cid-intr_ring_size_sel:

enum intr_ring_size_sel
-----------------------




.. rubric:: Overview

Qdma interrupt ring size selection

Each interrupt vector can be associated with 1 or more interrupt rings. The software can choose 8 different interrupt ring sizes. The ring size for each vector is programmed during interrupt context programming

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`INTR_RING_SZ_4KB<doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca899e3f7ea193a1d9fa15e465ec8aad81>` = 0
	:ref:`INTR_RING_SZ_8KB<doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca05ace36afd05287decfd171547a98cab>` 
	:ref:`INTR_RING_SZ_12KB<doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca267fe4ad6dd47c449e20b97034c8174e>` 
	:ref:`INTR_RING_SZ_16KB<doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447caf10a1fba7e6117bf8092db14f3a36a96>` 
	:ref:`INTR_RING_SZ_20KB<doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447cae0f3468d8d3660212071b186e5ee892a>` 
	:ref:`INTR_RING_SZ_24KB<doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca5a61ded806d003f6206359c2b6b6556d>` 
	:ref:`INTR_RING_SZ_28KB<doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447cac27d7eac61ff0b20336d35a59041930c>` 
	:ref:`INTR_RING_SZ_32KB<doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca7b0467e09ccd3872f1484529773aa94f>` 

.. _details-doxid-group__libqdma__enums_1gab35fd77940d3f2986774dda02415447c:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca899e3f7ea193a1d9fa15e465ec8aad81:
.. _cid-intr_ring_size_sel::intr_ring_sz_4kb:

:raw-html:`<tr><td>` 
INTR_RING_SZ_4KB

:raw-html:`</td><td>` 
accommodates 512 entries

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca05ace36afd05287decfd171547a98cab:
.. _cid-intr_ring_size_sel::intr_ring_sz_8kb:

:raw-html:`<tr><td>` 
INTR_RING_SZ_8KB

:raw-html:`</td><td>` 
accommodates 1024 entries

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca267fe4ad6dd47c449e20b97034c8174e:
.. _cid-intr_ring_size_sel::intr_ring_sz_12kb:

:raw-html:`<tr><td>` 
INTR_RING_SZ_12KB

:raw-html:`</td><td>` 
accommodates 1536 entries

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447caf10a1fba7e6117bf8092db14f3a36a96:
.. _cid-intr_ring_size_sel::intr_ring_sz_16kb:

:raw-html:`<tr><td>` 
INTR_RING_SZ_16KB

:raw-html:`</td><td>` 
accommodates 2048 entries

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447cae0f3468d8d3660212071b186e5ee892a:
.. _cid-intr_ring_size_sel::intr_ring_sz_20kb:

:raw-html:`<tr><td>` 
INTR_RING_SZ_20KB

:raw-html:`</td><td>` 
accommodates 2560 entries

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca5a61ded806d003f6206359c2b6b6556d:
.. _cid-intr_ring_size_sel::intr_ring_sz_24kb:

:raw-html:`<tr><td>` 
INTR_RING_SZ_24KB

:raw-html:`</td><td>` 
accommodates 3072 entries

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447cac27d7eac61ff0b20336d35a59041930c:
.. _cid-intr_ring_size_sel::intr_ring_sz_28kb:

:raw-html:`<tr><td>` 
INTR_RING_SZ_28KB

:raw-html:`</td><td>` 
accommodates 3584 entries

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggab35fd77940d3f2986774dda02415447ca7b0467e09ccd3872f1484529773aa94f:
.. _cid-intr_ring_size_sel::intr_ring_sz_32kb:

:raw-html:`<tr><td>` 
INTR_RING_SZ_32KB

:raw-html:`</td><td>` 
accommodates 4096 entries

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

