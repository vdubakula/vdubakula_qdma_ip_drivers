.. index:: pair: struct; qdma_q_type
.. _doxid-structqdma__q__type:
.. _cid-qdma_q_type:

struct qdma_q_type
------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

Queue type

Look up table for name of the queue type and enum

.. 	
	// fields

	const char* :ref:`name<doxid-structqdma__q__type_1afb5b6562883d90369b8ec5366b24b831>`
	enum :ref:`queue_type_t<doxid-group__libqdma__enums_1ga65e1a42224ea5650b05097504931ec7e>` :ref:`q_type<doxid-structqdma__q__type_1aec168868f58bfcba300cac73b29e4b5b>`

.. rubric:: Fields


.. _doxid-structqdma__q__type_1afb5b6562883d90369b8ec5366b24b831:
.. _cid-qdma_q_type::name:
.. ref-code-block:: cpp
	:class: title-code-block

	const char* name

Queue type name

.. _doxid-structqdma__q__type_1aec168868f58bfcba300cac73b29e4b5b:
.. _cid-qdma_q_type::q_type:
.. ref-code-block:: cpp
	:class: title-code-block

	enum :ref:`queue_type_t<doxid-group__libqdma__enums_1ga65e1a42224ea5650b05097504931ec7e>` q_type

Queue type

