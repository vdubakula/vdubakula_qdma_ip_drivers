.. index:: pair: group; Definitions
.. _doxid-group__libqdma__defines:
.. _cid-libqdma_defines:

Definitions
###########








.. rubric:: Overview



.. 	
	// macros

	#define :ref:`DEVICE_VERSION_INFO_STR_LENGTH<doxid-group__libqdma__defines_1gabe6fa2d94e71aa3f740a996b1eaf569a>`
	#define :ref:`QDMA_DEV_NAME_MAXLEN<doxid-group__libqdma__defines_1gab4320c7434dccd6b84e1590fed855e9a>`
	#define :ref:`QDMA_FUNC_ID_INVALID<doxid-group__libqdma__defines_1ga5bc05b59b1631e6fa628657bf9eac3b1>`
	#define :ref:`QDMA_QUEUE_IDX_INVALID<doxid-group__libqdma__defines_1gae168a38d476610e8ee964f722f1b0b62>`
	#define :ref:`QDMA_QUEUE_NAME_MAXLEN<doxid-group__libqdma__defines_1ga802600b551da03925a314bc513c23bc4>`
	#define :ref:`QDMA_QUEUE_VEC_INVALID<doxid-group__libqdma__defines_1ga67136280e4723ae4a90175eb523b5f77>`
	#define :ref:`QDMA_REQ_OPAQUE_SIZE<doxid-group__libqdma__defines_1gaf876ffaacb505d5671ce1570ecebd61c>`
	#define :ref:`QDMA_UDD_MAXLEN<doxid-group__libqdma__defines_1gab9b01e82a91686606380701978fc0c56>`

Macros
------

.. _doxid-group__libqdma__defines_1gabe6fa2d94e71aa3f740a996b1eaf569a:
.. _cid-device_version_info_str_length:
.. ref-code-block:: cpp
	:class: title-code-block

	#define DEVICE_VERSION_INFO_STR_LENGTH

DEVICE_VERSION_INFO_STR_LENGTH - QDMA HW version string array length, change this if QDMA_HW_VERSION_STRING_LEN is changed in access code

.. _doxid-group__libqdma__defines_1gab4320c7434dccd6b84e1590fed855e9a:
.. _cid-qdma_dev_name_maxlen:
.. ref-code-block:: cpp
	:class: title-code-block

	#define QDMA_DEV_NAME_MAXLEN

QDMA_DEV_NAME_MAXLEN - Maxinum length of the QDMA device name

.. _doxid-group__libqdma__defines_1ga5bc05b59b1631e6fa628657bf9eac3b1:
.. _cid-qdma_func_id_invalid:
.. ref-code-block:: cpp
	:class: title-code-block

	#define QDMA_FUNC_ID_INVALID

Invalid QDMA function number

.. _doxid-group__libqdma__defines_1gae168a38d476610e8ee964f722f1b0b62:
.. _cid-qdma_queue_idx_invalid:
.. ref-code-block:: cpp
	:class: title-code-block

	#define QDMA_QUEUE_IDX_INVALID

QDMA_QUEUE_IDX_INVALID - Invalid queue index

.. _doxid-group__libqdma__defines_1ga802600b551da03925a314bc513c23bc4:
.. _cid-qdma_queue_name_maxlen:
.. ref-code-block:: cpp
	:class: title-code-block

	#define QDMA_QUEUE_NAME_MAXLEN

QDMA_QUEUE_NAME_MAXLEN - Maximum queue name length

.. _doxid-group__libqdma__defines_1ga67136280e4723ae4a90175eb523b5f77:
.. _cid-qdma_queue_vec_invalid:
.. ref-code-block:: cpp
	:class: title-code-block

	#define QDMA_QUEUE_VEC_INVALID

QDMA_QUEUE_VEC_INVALID - Invalid MSIx vector index

.. _doxid-group__libqdma__defines_1gaf876ffaacb505d5671ce1570ecebd61c:
.. _cid-qdma_req_opaque_size:
.. ref-code-block:: cpp
	:class: title-code-block

	#define QDMA_REQ_OPAQUE_SIZE

QDMA_REQ_OPAQUE_SIZE - Maximum request length

.. _doxid-group__libqdma__defines_1gab9b01e82a91686606380701978fc0c56:
.. _cid-qdma_udd_maxlen:
.. ref-code-block:: cpp
	:class: title-code-block

	#define QDMA_UDD_MAXLEN

QDMA_UDD_MAXLEN - Maximum length of the user defined data

