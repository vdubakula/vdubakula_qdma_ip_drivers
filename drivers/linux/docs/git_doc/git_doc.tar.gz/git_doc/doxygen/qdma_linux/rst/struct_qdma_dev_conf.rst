.. index:: pair: struct; qdma_dev_conf
.. _doxid-structqdma__dev__conf:
.. _cid-qdma_dev_conf:

struct qdma_dev_conf
--------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

Defines the per-device qdma property.

.. 	
	// fields

	struct pci_dev* :ref:`pdev<doxid-structqdma__dev__conf_1ad94710251cab15f76e4784c9add9c009>`
	unsigned short :ref:`qsets_max<doxid-structqdma__dev__conf_1ad601e820f22f1490cfbaadd6f77b372e>`
	unsigned short :ref:`rsvd2<doxid-structqdma__dev__conf_1ac5ae57008064a5c53e1739a809ebd008>`
	u8 :ref:`zerolen_dma<doxid-structqdma__dev__conf_1a186714981051de022a9d3324b26ca058>` :1
	u8 :ref:`master_pf<doxid-structqdma__dev__conf_1a9ebe9df1b95044213781c7915c2295ad>` :1
	u8 :ref:`intr_moderation<doxid-structqdma__dev__conf_1aa68acda3b40f233d2417a5df4ddc14a6>` :1
	u8 :ref:`rsvd1<doxid-structqdma__dev__conf_1a96d8117b8de2f5a8cbf64ea7063fccef>` :5
	u8 :ref:`vf_max<doxid-structqdma__dev__conf_1a1181cf69efbbd62ddc4fbda29eee7e88>`
	u8 :ref:`intr_rngsz<doxid-structqdma__dev__conf_1abdd65e022d4aba3b838cb0483097acb3>`
	u16 :ref:`msix_qvec_max<doxid-structqdma__dev__conf_1a4e6669de97901154e0351db57b3a20f1>`
	u16 :ref:`user_msix_qvec_max<doxid-structqdma__dev__conf_1a3282ef24eea6f4e0156fdb68df4ae740>`
	u16 :ref:`data_msix_qvec_max<doxid-structqdma__dev__conf_1a27006da4091d1be72772d1e67fa6a295>`
	unsigned long :ref:`uld<doxid-structqdma__dev__conf_1a7d21996961e054ff50baa8c133205b2c>`
	enum :ref:`qdma_drv_mode<doxid-group__libqdma__enums_1gada00378b695c456022546aec7d0e9e32>` :ref:`qdma_drv_mode<doxid-structqdma__dev__conf_1a466fbe403f645670bb3ea9a352affcbf>`
	char :ref:`name<doxid-structqdma__dev__conf_1a64d6863fba518a4d2ed6a3154c5fb790>`[QDMA_DEV_NAME_MAXLEN]
	char :ref:`bar_num_config<doxid-structqdma__dev__conf_1a7bed251b6b4b16507fbf803af8788fef>`
	char :ref:`bar_num_user<doxid-structqdma__dev__conf_1addde2029d0639ef0bbf077c6c9e7eefc>`
	char :ref:`bar_num_bypass<doxid-structqdma__dev__conf_1ad0aa560262137ba2d13b67ab14395676>`
	int :ref:`qsets_base<doxid-structqdma__dev__conf_1a030cfdb26ef47de06176f6283dac3241>`
	u32 :ref:`bdf<doxid-structqdma__dev__conf_1af1e165b08d1f631e58908846af7e70fc>`
	u32 :ref:`idx<doxid-structqdma__dev__conf_1ad699e13e0430b3708032459bfa83e9f2>`
	void (* :ref:`fp_user_isr_handler<doxid-structqdma__dev__conf_1a9b48b44bf488db993747f49b817cf8ad>`)(unsigned long dev_hndl, unsigned long uld)
	void (* :ref:`fp_q_isr_top_dev<doxid-structqdma__dev__conf_1a6c5647fe3ebd898bf60d540a8b6be983>`)(unsigned long dev_hndl, unsigned long uld)
	void (* :ref:`fp_flr_free_resource<doxid-structqdma__dev__conf_1ac0f6bb9a6ce11b8f5f1119e72f9955b8>`)(unsigned long dev_hndl)
	void* :ref:`debugfs_dev_root<doxid-structqdma__dev__conf_1a30abd21b3456470a5cba8e6af702103b>`

.. rubric:: Fields


.. _doxid-structqdma__dev__conf_1ad94710251cab15f76e4784c9add9c009:
.. _cid-qdma_dev_conf::pdev:
.. ref-code-block:: cpp
	:class: title-code-block

	struct pci_dev* pdev

pointer to pci_dev

.. _doxid-structqdma__dev__conf_1ad601e820f22f1490cfbaadd6f77b372e:
.. _cid-qdma_dev_conf::qsets_max:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned short qsets_max

Maximum number of queue pairs per device

.. _doxid-structqdma__dev__conf_1ac5ae57008064a5c53e1739a809ebd008:
.. _cid-qdma_dev_conf::rsvd2:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned short rsvd2

Reserved

.. _doxid-structqdma__dev__conf_1a186714981051de022a9d3324b26ca058:
.. _cid-qdma_dev_conf::zerolen_dma:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 zerolen_dma :1

Indicates whether zero length DMA is allowed or not

.. _doxid-structqdma__dev__conf_1a9ebe9df1b95044213781c7915c2295ad:
.. _cid-qdma_dev_conf::master_pf:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 master_pf :1

Indicates whether the current pf is master_pf or not

.. _doxid-structqdma__dev__conf_1aa68acda3b40f233d2417a5df4ddc14a6:
.. _cid-qdma_dev_conf::intr_moderation:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 intr_moderation :1

moderate interrupt generation

.. _doxid-structqdma__dev__conf_1a96d8117b8de2f5a8cbf64ea7063fccef:
.. _cid-qdma_dev_conf::rsvd1:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 rsvd1 :5

Reserved1

.. _doxid-structqdma__dev__conf_1a1181cf69efbbd62ddc4fbda29eee7e88:
.. _cid-qdma_dev_conf::vf_max:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 vf_max

Maximum number of virtual functions for current physical function

.. _doxid-structqdma__dev__conf_1abdd65e022d4aba3b838cb0483097acb3:
.. _cid-qdma_dev_conf::intr_rngsz:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 intr_rngsz

Interrupt ring size

.. _doxid-structqdma__dev__conf_1a4e6669de97901154e0351db57b3a20f1:
.. _cid-qdma_dev_conf::msix_qvec_max:
.. ref-code-block:: cpp
	:class: title-code-block

	u16 msix_qvec_max

interrupt:

* MSI-X only max of QDMA_DEV_MSIX_VEC_MAX per function, 32 in Versal

* 1 vector is reserved for user interrupt

* 1 vector is reserved mailbox

* 1 vector on pf0 is reserved for error interrupt

* the remaining vectors will be used for queues max. of vectors used for queues. libqdma update w/ actual #

.. _doxid-structqdma__dev__conf_1a3282ef24eea6f4e0156fdb68df4ae740:
.. _cid-qdma_dev_conf::user_msix_qvec_max:
.. ref-code-block:: cpp
	:class: title-code-block

	u16 user_msix_qvec_max

Max user msix vectors

.. _doxid-structqdma__dev__conf_1a27006da4091d1be72772d1e67fa6a295:
.. _cid-qdma_dev_conf::data_msix_qvec_max:
.. ref-code-block:: cpp
	:class: title-code-block

	u16 data_msix_qvec_max

Max data msix vectors

.. _doxid-structqdma__dev__conf_1a7d21996961e054ff50baa8c133205b2c:
.. _cid-qdma_dev_conf::uld:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned long uld

upper layer data, i.e. callback data

.. _doxid-structqdma__dev__conf_1a466fbe403f645670bb3ea9a352affcbf:
.. _cid-qdma_dev_conf::qdma_drv_mode:
.. ref-code-block:: cpp
	:class: title-code-block

	enum :ref:`qdma_drv_mode<doxid-group__libqdma__enums_1gada00378b695c456022546aec7d0e9e32>` qdma_drv_mode

qdma driver mode

.. _doxid-structqdma__dev__conf_1a64d6863fba518a4d2ed6a3154c5fb790:
.. _cid-qdma_dev_conf::name:
.. ref-code-block:: cpp
	:class: title-code-block

	char name [QDMA_DEV_NAME_MAXLEN]

an unique string to identify the dev. current format: qdma[pf|vf][idx] filled in by libqdma

.. _doxid-structqdma__dev__conf_1a7bed251b6b4b16507fbf803af8788fef:
.. _cid-qdma_dev_conf::bar_num_config:
.. ref-code-block:: cpp
	:class: title-code-block

	char bar_num_config

dma config bar #, < 0 not present

.. _doxid-structqdma__dev__conf_1addde2029d0639ef0bbf077c6c9e7eefc:
.. _cid-qdma_dev_conf::bar_num_user:
.. ref-code-block:: cpp
	:class: title-code-block

	char bar_num_user

AXI Master Lite(user bar)

.. _doxid-structqdma__dev__conf_1ad0aa560262137ba2d13b67ab14395676:
.. _cid-qdma_dev_conf::bar_num_bypass:
.. ref-code-block:: cpp
	:class: title-code-block

	char bar_num_bypass

AXI Bridge Master(bypass bar)

.. _doxid-structqdma__dev__conf_1a030cfdb26ef47de06176f6283dac3241:
.. _cid-qdma_dev_conf::qsets_base:
.. ref-code-block:: cpp
	:class: title-code-block

	int qsets_base

queue base for this function

.. _doxid-structqdma__dev__conf_1af1e165b08d1f631e58908846af7e70fc:
.. _cid-qdma_dev_conf::bdf:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 bdf

device index

.. _doxid-structqdma__dev__conf_1ad699e13e0430b3708032459bfa83e9f2:
.. _cid-qdma_dev_conf::idx:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 idx

index of device in device list

.. _doxid-structqdma__dev__conf_1a9b48b44bf488db993747f49b817cf8ad:
.. _cid-qdma_dev_conf::fp_user_isr_handler:
.. ref-code-block:: cpp
	:class: title-code-block

	void (* fp_user_isr_handler )(unsigned long dev_hndl, unsigned long uld)

user interrupt, if null, default libqdma handler is used



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - Device Handler

    *
        - uld

        - upper layer data, i.e. callback data

.. _doxid-structqdma__dev__conf_1a6c5647fe3ebd898bf60d540a8b6be983:
.. _cid-qdma_dev_conf::fp_q_isr_top_dev:
.. ref-code-block:: cpp
	:class: title-code-block

	void (* fp_q_isr_top_dev )(unsigned long dev_hndl, unsigned long uld)

Q interrupt top, per-device addtional handling code.



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - Device Handler

    *
        - uld

        - upper layer data, i.e. callback data

.. _doxid-structqdma__dev__conf_1ac0f6bb9a6ce11b8f5f1119e72f9955b8:
.. _cid-qdma_dev_conf::fp_flr_free_resource:
.. ref-code-block:: cpp
	:class: title-code-block

	void (* fp_flr_free_resource )(unsigned long dev_hndl)

for freeing any resources in FLR process



.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - dev_hndl

        - Device Handler

.. _doxid-structqdma__dev__conf_1a30abd21b3456470a5cba8e6af702103b:
.. _cid-qdma_dev_conf::debugfs_dev_root:
.. ref-code-block:: cpp
	:class: title-code-block

	void* debugfs_dev_root

root path for debugfs

