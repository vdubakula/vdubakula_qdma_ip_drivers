.. index:: pair: enum; tigger_mode_t
.. _doxid-group__libqdma__enums_1ga4bb6156b0570debde51f16f2a8b509a9:
.. _cid-tigger_mode_t:

enum tigger_mode_t
------------------




.. rubric:: Overview

Trigger modes

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`TRIG_MODE_DISABLE<doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9a4811da58c386134ca593e7084e6cc562>` 
	:ref:`TRIG_MODE_ANY<doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9a2e7233b9f8a9bd57e01ac3c9980dca10>` 
	:ref:`TRIG_MODE_COUNTER<doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9aafbe404bd9a2059b553ad5fd833b463b>` 
	:ref:`TRIG_MODE_USER<doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9a4e890c867918bcfd59a31923be57a0c3>` 
	:ref:`TRIG_MODE_TIMER<doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9ad317977e3c0e0bd29dae52030b77b42a>` 
	:ref:`TRIG_MODE_COMBO<doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9a8b7337423ad330a366f63712eb9b9d28>` 

.. _details-doxid-group__libqdma__enums_1ga4bb6156b0570debde51f16f2a8b509a9:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9a4811da58c386134ca593e7084e6cc562:
.. _cid-tigger_mode_t::trig_mode_disable:

:raw-html:`<tr><td>` 
TRIG_MODE_DISABLE

:raw-html:`</td><td>` 
disable trigger mode

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9a2e7233b9f8a9bd57e01ac3c9980dca10:
.. _cid-tigger_mode_t::trig_mode_any:

:raw-html:`<tr><td>` 
TRIG_MODE_ANY

:raw-html:`</td><td>` 
any trigger mode

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9aafbe404bd9a2059b553ad5fd833b463b:
.. _cid-tigger_mode_t::trig_mode_counter:

:raw-html:`<tr><td>` 
TRIG_MODE_COUNTER

:raw-html:`</td><td>` 
counter trigger mode

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9a4e890c867918bcfd59a31923be57a0c3:
.. _cid-tigger_mode_t::trig_mode_user:

:raw-html:`<tr><td>` 
TRIG_MODE_USER

:raw-html:`</td><td>` 
trigger mode of user choice

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9ad317977e3c0e0bd29dae52030b77b42a:
.. _cid-tigger_mode_t::trig_mode_timer:

:raw-html:`<tr><td>` 
TRIG_MODE_TIMER

:raw-html:`</td><td>` 
timer trigger mode

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4bb6156b0570debde51f16f2a8b509a9a8b7337423ad330a366f63712eb9b9d28:
.. _cid-tigger_mode_t::trig_mode_combo:

:raw-html:`<tr><td>` 
TRIG_MODE_COMBO

:raw-html:`</td><td>` 
timer and counter combo trigger mode

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

