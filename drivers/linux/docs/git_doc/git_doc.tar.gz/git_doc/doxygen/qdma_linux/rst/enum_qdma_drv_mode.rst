.. index:: pair: enum; qdma_drv_mode
.. _doxid-group__libqdma__enums_1gada00378b695c456022546aec7d0e9e32:
.. _cid-qdma_drv_mode:

enum qdma_drv_mode
------------------




.. rubric:: Overview

PF/VF qdma driver modes

QDMA PF/VF drivers can be loaded in one of these modes. Mode options is exposed as a user configurable module parameter

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`AUTO_MODE<doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32ab1d633b014db4f3b67ec587e14035755>` 
	:ref:`POLL_MODE<doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32a31ec31eed700e1eff898af96e9489a88>` 
	:ref:`DIRECT_INTR_MODE<doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32a5a5568ee6bc2a8b32830f3ce76cae84f>` 
	:ref:`INDIRECT_INTR_MODE<doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32a1d7531960286f3f53bde6d5b590ddb2f>` 
	:ref:`LEGACY_INTR_MODE<doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32ac97851070b3d86674cec11e4857837a6>` 

.. _details-doxid-group__libqdma__enums_1gada00378b695c456022546aec7d0e9e32:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32ab1d633b014db4f3b67ec587e14035755:
.. _cid-qdma_drv_mode::auto_mode:

:raw-html:`<tr><td>` 
AUTO_MODE

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - AUTO_MODE

        - Auto mode is mix of Poll and Interrupt Aggregation mode. Driver polls for the write back status updates. Interrupt aggregation is used for processing the completion ring

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32a31ec31eed700e1eff898af96e9489a88:
.. _cid-qdma_drv_mode::poll_mode:

:raw-html:`<tr><td>` 
POLL_MODE

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - POLL_MODE

        - In Poll Mode, Software polls for the write back completions (Status Descriptor Write Back)

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32a5a5568ee6bc2a8b32830f3ce76cae84f:
.. _cid-qdma_drv_mode::direct_intr_mode:

:raw-html:`<tr><td>` 
DIRECT_INTR_MODE

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - DIRECT_INTR_MODE

        - Direct Interrupt mode, each queue is assigned to one of the available interrupt vectors in a round robin fashion to service the requests. Interrupt is raised by the HW upon receiving the completions and software reads the completion status.

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32a1d7531960286f3f53bde6d5b590ddb2f:
.. _cid-qdma_drv_mode::indirect_intr_mode:

:raw-html:`<tr><td>` 
INDIRECT_INTR_MODE

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - INDIRECT_INTR_MODE

        - In Indirect Interrupt mode or Interrupt Aggregation mode, each vector has an associated Interrupt Aggregation Ring. The QID and status of queues requiring service are written into the Interrupt Aggregation Ring. When a PCIe MSI-X interrupt is received by the Host, the software reads the Interrupt Aggregation Ring to determine which queue needs service. Mapping of queues to vectors is programmable

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggada00378b695c456022546aec7d0e9e32ac97851070b3d86674cec11e4857837a6:
.. _cid-qdma_drv_mode::legacy_intr_mode:

:raw-html:`<tr><td>` 
LEGACY_INTR_MODE

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - LEGACY_INTR_MODE

        - Driver is inserted in legacy interrupt mode Software serves status updates upon receiving the legacy interrupt

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

