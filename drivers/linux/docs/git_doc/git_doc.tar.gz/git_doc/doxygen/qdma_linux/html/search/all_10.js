var searchData=
[
  ['sgcnt',['sgcnt',['../structqdma__request.html#aa8a652f80c8c192588a8bb1a71c720c1',1,'qdma_request']]],
  ['sgl',['sgl',['../structqdma__request.html#aa1c9f478fceee678c16db8a367df1ec4',1,'qdma_request']]],
  ['st',['st',['../structqdma__queue__conf.html#a5ef48dd5edb988b4e1c9fea566ef16de',1,'qdma_queue_conf::st()'],['../structqdma__q__state.html#a53707522e44fa5ede6911aa1654356e8',1,'qdma_q_state::st()']]],
  ['st_5fpkt_5fmode',['st_pkt_mode',['../structqdma__queue__conf.html#a358b948e6ee3466d9776659abe2e532c',1,'qdma_queue_conf']]],
  ['sw_5fdesc_5fsz',['sw_desc_sz',['../structqdma__queue__conf.html#a0efbbcf018bb107b57a4609013b275e9',1,'qdma_queue_conf']]]
];
