.. index:: pair: enum; desc_sz_t
.. _doxid-group__libqdma__enums_1gad333efea5db7a4bd3ccab5f9c682f995:
.. _cid-desc_sz_t:

enum desc_sz_t
--------------




.. rubric:: Overview

Descriptor sizes

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`DESC_SZ_8B<doxid-group__libqdma__enums_1ggad333efea5db7a4bd3ccab5f9c682f995aa0a21e5212c6ed3d1931bfb08b1bdab9>` = 0
	:ref:`DESC_SZ_16B<doxid-group__libqdma__enums_1ggad333efea5db7a4bd3ccab5f9c682f995a18e9bc5102572f3e0aa137117ad0456a>` 
	:ref:`DESC_SZ_32B<doxid-group__libqdma__enums_1ggad333efea5db7a4bd3ccab5f9c682f995a74fbc791b671e1878826305e74bebe56>` 
	:ref:`DESC_SZ_64B<doxid-group__libqdma__enums_1ggad333efea5db7a4bd3ccab5f9c682f995a455599145898c49ff04e56c27194ed15>` 

.. _details-doxid-group__libqdma__enums_1gad333efea5db7a4bd3ccab5f9c682f995:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1ggad333efea5db7a4bd3ccab5f9c682f995aa0a21e5212c6ed3d1931bfb08b1bdab9:
.. _cid-desc_sz_t::desc_sz_8b:

:raw-html:`<tr><td>` 
DESC_SZ_8B

:raw-html:`</td><td>` 
descriptor size 8B

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggad333efea5db7a4bd3ccab5f9c682f995a18e9bc5102572f3e0aa137117ad0456a:
.. _cid-desc_sz_t::desc_sz_16b:

:raw-html:`<tr><td>` 
DESC_SZ_16B

:raw-html:`</td><td>` 
descriptor size 16B

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggad333efea5db7a4bd3ccab5f9c682f995a74fbc791b671e1878826305e74bebe56:
.. _cid-desc_sz_t::desc_sz_32b:

:raw-html:`<tr><td>` 
DESC_SZ_32B

:raw-html:`</td><td>` 
descriptor size 32B

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggad333efea5db7a4bd3ccab5f9c682f995a455599145898c49ff04e56c27194ed15:
.. _cid-desc_sz_t::desc_sz_64b:

:raw-html:`<tr><td>` 
DESC_SZ_64B

:raw-html:`</td><td>` 
descriptor size 64B

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

