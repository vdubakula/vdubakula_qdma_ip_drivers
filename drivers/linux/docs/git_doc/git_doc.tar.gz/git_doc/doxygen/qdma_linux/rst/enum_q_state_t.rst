.. index:: pair: enum; q_state_t
.. _doxid-group__libqdma__enums_1ga4e31046f711ac398650a6a56f3c0c0ce:
.. _cid-q_state_t:

enum q_state_t
--------------




.. rubric:: Overview

Queue can be in one of the following states

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`Q_STATE_DISABLED<doxid-group__libqdma__enums_1gga4e31046f711ac398650a6a56f3c0c0cea6f166bafd5b4a912832660bc5522189b>` = 0
	:ref:`Q_STATE_ENABLED<doxid-group__libqdma__enums_1gga4e31046f711ac398650a6a56f3c0c0cea1f20a89daa0f08b31d3bf8d1a75fba54>` 
	:ref:`Q_STATE_ONLINE<doxid-group__libqdma__enums_1gga4e31046f711ac398650a6a56f3c0c0ceaf1fc79e81f91a149607c34d50f9ad82a>` 

.. _details-doxid-group__libqdma__enums_1ga4e31046f711ac398650a6a56f3c0c0ce:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1gga4e31046f711ac398650a6a56f3c0c0cea6f166bafd5b4a912832660bc5522189b:
.. _cid-q_state_t::q_state_disabled:

:raw-html:`<tr><td>` 
Q_STATE_DISABLED

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - Q_STATE_DISABLED

        - Queue is not taken

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4e31046f711ac398650a6a56f3c0c0cea1f20a89daa0f08b31d3bf8d1a75fba54:
.. _cid-q_state_t::q_state_enabled:

:raw-html:`<tr><td>` 
Q_STATE_ENABLED

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - Q_STATE_ENABLED

        - Assigned/taken. Partial config is done

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga4e31046f711ac398650a6a56f3c0c0ceaf1fc79e81f91a149607c34d50f9ad82a:
.. _cid-q_state_t::q_state_online:

:raw-html:`<tr><td>` 
Q_STATE_ONLINE

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - Q_STATE_ONLINE

        - Resource/context is initialized for the queue and is available for data consumption

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

