var searchData=
[
  ['timeout_5fms',['timeout_ms',['../structqdma__request.html#a372ea74bbbe306452e55cae86529d4b9',1,'qdma_request']]],
  ['timer_5fidx',['timer_idx',['../structqdma__cmpl__ctrl.html#a2ba8b93f2e7fb0e49ed50df8892ed9f0',1,'qdma_cmpl_ctrl']]],
  ['trigger_5fmode',['trigger_mode',['../structqdma__cmpl__ctrl.html#afa7aba3bd3582c8ca6e2067f5e7f80d3',1,'qdma_cmpl_ctrl']]]
];
