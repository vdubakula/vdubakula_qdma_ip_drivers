.. index:: pair: group; Enumerations
.. _doxid-group__libqdma__enums:
.. _cid-libqdma_enums:

Enumerations
############





.. include:: ../doxygen/qdma_linux/rst/enum_cmpt_desc_sz_t.rst
.. include:: ../doxygen/qdma_linux/rst/enum_desc_sz_t.rst
.. include:: ../doxygen/qdma_linux/rst/enum_intr_ring_size_sel.rst
.. include:: ../doxygen/qdma_linux/rst/enum_q_state_t.rst
.. include:: ../doxygen/qdma_linux/rst/enum_qdma_dev_qmax_state.rst
.. include:: ../doxygen/qdma_linux/rst/enum_qdma_drv_mode.rst
.. include:: ../doxygen/qdma_linux/rst/enum_qdma_q_dir.rst
.. include:: ../doxygen/qdma_linux/rst/enum_qdma_q_mode.rst
.. include:: ../doxygen/qdma_linux/rst/enum_queue_type_t.rst
.. include:: ../doxygen/qdma_linux/rst/enum_tigger_mode_t.rst





.. 	
	// enums

	enum :ref:`cmpt_desc_sz_t<doxid-group__libqdma__enums_1ga4fde724ed70ff4414fa0ab2d6bbe62d9>`
	enum :ref:`desc_sz_t<doxid-group__libqdma__enums_1gad333efea5db7a4bd3ccab5f9c682f995>`
	enum :ref:`intr_ring_size_sel<doxid-group__libqdma__enums_1gab35fd77940d3f2986774dda02415447c>`
	enum :ref:`q_state_t<doxid-group__libqdma__enums_1ga4e31046f711ac398650a6a56f3c0c0ce>`
	enum :ref:`qdma_dev_qmax_state<doxid-group__libqdma__enums_1ga252f71bb17ef7f319490e0c89f07e5bc>`
	enum :ref:`qdma_drv_mode<doxid-group__libqdma__enums_1gada00378b695c456022546aec7d0e9e32>`
	enum :ref:`qdma_q_dir<doxid-group__libqdma__enums_1gafd6884069689db6ff5c38c7bc0df8ea4>`
	enum :ref:`qdma_q_mode<doxid-group__libqdma__enums_1gaefb7758f05f40e42f0a298b3e55570e4>`
	enum :ref:`queue_type_t<doxid-group__libqdma__enums_1ga65e1a42224ea5650b05097504931ec7e>`
	enum :ref:`tigger_mode_t<doxid-group__libqdma__enums_1ga4bb6156b0570debde51f16f2a8b509a9>`

