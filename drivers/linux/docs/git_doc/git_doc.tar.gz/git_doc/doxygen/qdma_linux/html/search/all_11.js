var searchData=
[
  ['tigger_5fmode_5ft',['tigger_mode_t',['../group__libqdma__enums.html#ga4bb6156b0570debde51f16f2a8b509a9',1,'libqdma_export.h']]],
  ['timeout_5fms',['timeout_ms',['../structqdma__request.html#a372ea74bbbe306452e55cae86529d4b9',1,'qdma_request']]],
  ['timer_5fidx',['timer_idx',['../structqdma__cmpl__ctrl.html#a2ba8b93f2e7fb0e49ed50df8892ed9f0',1,'qdma_cmpl_ctrl']]],
  ['trig_5fmode_5fany',['TRIG_MODE_ANY',['../group__libqdma__enums.html#gga4bb6156b0570debde51f16f2a8b509a9a2e7233b9f8a9bd57e01ac3c9980dca10',1,'libqdma_export.h']]],
  ['trig_5fmode_5fcombo',['TRIG_MODE_COMBO',['../group__libqdma__enums.html#gga4bb6156b0570debde51f16f2a8b509a9a8b7337423ad330a366f63712eb9b9d28',1,'libqdma_export.h']]],
  ['trig_5fmode_5fcounter',['TRIG_MODE_COUNTER',['../group__libqdma__enums.html#gga4bb6156b0570debde51f16f2a8b509a9aafbe404bd9a2059b553ad5fd833b463b',1,'libqdma_export.h']]],
  ['trig_5fmode_5fdisable',['TRIG_MODE_DISABLE',['../group__libqdma__enums.html#gga4bb6156b0570debde51f16f2a8b509a9a4811da58c386134ca593e7084e6cc562',1,'libqdma_export.h']]],
  ['trig_5fmode_5ftimer',['TRIG_MODE_TIMER',['../group__libqdma__enums.html#gga4bb6156b0570debde51f16f2a8b509a9ad317977e3c0e0bd29dae52030b77b42a',1,'libqdma_export.h']]],
  ['trig_5fmode_5fuser',['TRIG_MODE_USER',['../group__libqdma__enums.html#gga4bb6156b0570debde51f16f2a8b509a9a4e890c867918bcfd59a31923be57a0c3',1,'libqdma_export.h']]],
  ['trigger_5fmode',['trigger_mode',['../structqdma__cmpl__ctrl.html#afa7aba3bd3582c8ca6e2067f5e7f80d3',1,'qdma_cmpl_ctrl']]]
];
