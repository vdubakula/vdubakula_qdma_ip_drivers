var searchData=
[
  ['q_5ftype',['q_type',['../structqdma__q__type.html#aec168868f58bfcba300cac73b29e4b5b',1,'qdma_q_type::q_type()'],['../structqdma__queue__conf.html#ad3a0b7319b6748762952e5d6527abee3',1,'qdma_queue_conf::q_type()'],['../structqdma__q__state.html#ac27c4b076a58650e9aae2ac7bac524e9',1,'qdma_q_state::q_type()']]],
  ['q_5ftype_5flist',['q_type_list',['../group__libqdma__struct.html#ga5dc4f80a3b9e9ba8b4281f08df757748',1,'libqdma_export.h']]],
  ['qdma_5fdrv_5fmode',['qdma_drv_mode',['../structqdma__dev__conf.html#a466fbe403f645670bb3ea9a352affcbf',1,'qdma_dev_conf']]],
  ['qidx',['qidx',['../structqdma__queue__conf.html#a4725b7966fef7ecded5f3386989b0f9e',1,'qdma_queue_conf::qidx()'],['../structqdma__q__state.html#a88369072533880192fa1010cd48b445c',1,'qdma_q_state::qidx()']]],
  ['qsets_5fbase',['qsets_base',['../structqdma__dev__conf.html#a030cfdb26ef47de06176f6283dac3241',1,'qdma_dev_conf']]],
  ['qsets_5fmax',['qsets_max',['../structqdma__dev__conf.html#ad601e820f22f1490cfbaadd6f77b372e',1,'qdma_dev_conf']]],
  ['qstate',['qstate',['../structqdma__q__state.html#a9583aac3bb7bd9e171fd4cbaa4f4dd54',1,'qdma_q_state']]],
  ['quld',['quld',['../structqdma__queue__conf.html#a260f0d4ec91e373f3bc41711a278c175',1,'qdma_queue_conf']]]
];
