var searchData=
[
  ['desc_5fsz_5f16b',['DESC_SZ_16B',['../group__libqdma__enums.html#ggad333efea5db7a4bd3ccab5f9c682f995a18e9bc5102572f3e0aa137117ad0456a',1,'libqdma_export.h']]],
  ['desc_5fsz_5f32b',['DESC_SZ_32B',['../group__libqdma__enums.html#ggad333efea5db7a4bd3ccab5f9c682f995a74fbc791b671e1878826305e74bebe56',1,'libqdma_export.h']]],
  ['desc_5fsz_5f64b',['DESC_SZ_64B',['../group__libqdma__enums.html#ggad333efea5db7a4bd3ccab5f9c682f995a455599145898c49ff04e56c27194ed15',1,'libqdma_export.h']]],
  ['desc_5fsz_5f8b',['DESC_SZ_8B',['../group__libqdma__enums.html#ggad333efea5db7a4bd3ccab5f9c682f995aa0a21e5212c6ed3d1931bfb08b1bdab9',1,'libqdma_export.h']]],
  ['direct_5fintr_5fmode',['DIRECT_INTR_MODE',['../group__libqdma__enums.html#ggada00378b695c456022546aec7d0e9e32a5a5568ee6bc2a8b32830f3ce76cae84f',1,'libqdma_export.h']]]
];
