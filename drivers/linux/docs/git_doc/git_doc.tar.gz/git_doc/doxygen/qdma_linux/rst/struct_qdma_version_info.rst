.. index:: pair: struct; qdma_version_info
.. _doxid-structqdma__version__info:
.. _cid-qdma_version_info:

struct qdma_version_info
------------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

defines the per-device version information

.. 	
	// fields

	char :ref:`rtl_version_str<doxid-structqdma__version__info_1a9dbdafa1178e24fcf3a3884d108ea3f5>`[DEVICE_VERSION_INFO_STR_LENGTH]
	char :ref:`vivado_release_str<doxid-structqdma__version__info_1af428d093fe3e43f44e9d7c2db8f21c58>`[DEVICE_VERSION_INFO_STR_LENGTH]
	char :ref:`ip_str<doxid-structqdma__version__info_1aa31b441b7c819d64e7b720dd4b31a61d>`[DEVICE_VERSION_INFO_STR_LENGTH]
	char :ref:`device_type_str<doxid-structqdma__version__info_1a2489509cb87f0824c06010ea1b2a8674>`[DEVICE_VERSION_INFO_STR_LENGTH]

.. rubric:: Fields


.. _doxid-structqdma__version__info_1a9dbdafa1178e24fcf3a3884d108ea3f5:
.. _cid-qdma_version_info::rtl_version_str:
.. ref-code-block:: cpp
	:class: title-code-block

	char rtl_version_str [DEVICE_VERSION_INFO_STR_LENGTH]

Version string

.. _doxid-structqdma__version__info_1af428d093fe3e43f44e9d7c2db8f21c58:
.. _cid-qdma_version_info::vivado_release_str:
.. ref-code-block:: cpp
	:class: title-code-block

	char vivado_release_str [DEVICE_VERSION_INFO_STR_LENGTH]

Release string

.. _doxid-structqdma__version__info_1aa31b441b7c819d64e7b720dd4b31a61d:
.. _cid-qdma_version_info::ip_str:
.. ref-code-block:: cpp
	:class: title-code-block

	char ip_str [DEVICE_VERSION_INFO_STR_LENGTH]

IP version string

.. _doxid-structqdma__version__info_1a2489509cb87f0824c06010ea1b2a8674:
.. _cid-qdma_version_info::device_type_str:
.. ref-code-block:: cpp
	:class: title-code-block

	char device_type_str [DEVICE_VERSION_INFO_STR_LENGTH]

Qdma device type string

