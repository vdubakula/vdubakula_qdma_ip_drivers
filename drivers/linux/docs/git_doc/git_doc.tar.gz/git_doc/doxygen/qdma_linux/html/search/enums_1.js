var searchData=
[
  ['desc_5fsz_5ft',['desc_sz_t',['../group__libqdma__enums.html#gad333efea5db7a4bd3ccab5f9c682f995',1,'libqdma_export.h']]]
];
