var searchData=
[
  ['name',['name',['../structdrv__mode__name.html#a7a689a355f387c592c2f3e45e2ba1f86',1,'drv_mode_name::name()'],['../structqdma__q__type.html#afb5b6562883d90369b8ec5366b24b831',1,'qdma_q_type::name()'],['../structqdma__dev__conf.html#a64d6863fba518a4d2ed6a3154c5fb790',1,'qdma_dev_conf::name()'],['../structqdma__queue__conf.html#a080b7077b2b749a231b544669e312003',1,'qdma_queue_conf::name()']]],
  ['next',['next',['../structqdma__sw__sg.html#ab8b2b733bfc270befae23b6d520878d4',1,'qdma_sw_sg']]],
  ['no_5fmemcpy',['no_memcpy',['../structqdma__request.html#afcda577d1f496ec0eb83af91567bf78e',1,'qdma_request']]]
];
