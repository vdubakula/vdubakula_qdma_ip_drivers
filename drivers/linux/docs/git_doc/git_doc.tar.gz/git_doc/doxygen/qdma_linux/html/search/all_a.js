var searchData=
[
  ['master_5fpf',['master_pf',['../structqdma__dev__conf.html#a9ebe9df1b95044213781c7915c2295ad',1,'qdma_dev_conf']]],
  ['mm_5fchannel',['mm_channel',['../structqdma__queue__conf.html#a11887eac0852b13316c0e658c94b2644',1,'qdma_queue_conf']]],
  ['mode_5fname_5flist',['mode_name_list',['../group__libqdma__struct.html#ga0273499757d4829ebbb4a5d0b682292e',1,'libqdma_export.h']]],
  ['msix_5fqvec_5fmax',['msix_qvec_max',['../structqdma__dev__conf.html#a4e6669de97901154e0351db57b3a20f1',1,'qdma_dev_conf']]]
];
