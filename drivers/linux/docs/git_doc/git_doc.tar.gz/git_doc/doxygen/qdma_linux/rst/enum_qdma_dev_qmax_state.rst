.. index:: pair: enum; qdma_dev_qmax_state
.. _doxid-group__libqdma__enums_1ga252f71bb17ef7f319490e0c89f07e5bc:
.. _cid-qdma_dev_qmax_state:

enum qdma_dev_qmax_state
------------------------




.. rubric:: Overview

Qdma function states

Each PF/VF device can be configured with 0 or more number of queues. When the queue is not assigned to any function, function is in unfonfigured state. Sysfs interface enables the users to configure the number of queues to different functions. Upon adding the queues, function moves to user configured state.

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`QMAX_CFG_UNCONFIGURED<doxid-group__libqdma__enums_1gga252f71bb17ef7f319490e0c89f07e5bca835db2d933a25969bc774c9ab68e6992>` 
	:ref:`QMAX_CFG_INITIAL<doxid-group__libqdma__enums_1gga252f71bb17ef7f319490e0c89f07e5bcae7b5498579feaa334085d9f683d5599b>` 
	:ref:`QMAX_CFG_USER<doxid-group__libqdma__enums_1gga252f71bb17ef7f319490e0c89f07e5bca1330593c4f0420936cd38e647ecb249f>` 

.. _details-doxid-group__libqdma__enums_1ga252f71bb17ef7f319490e0c89f07e5bc:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1gga252f71bb17ef7f319490e0c89f07e5bca835db2d933a25969bc774c9ab68e6992:
.. _cid-qdma_dev_qmax_state::qmax_cfg_unconfigured:

:raw-html:`<tr><td>` 
QMAX_CFG_UNCONFIGURED

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - QMAX_CFG_UNCONFIGURED

        - queue max not configured

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga252f71bb17ef7f319490e0c89f07e5bcae7b5498579feaa334085d9f683d5599b:
.. _cid-qdma_dev_qmax_state::qmax_cfg_initial:

:raw-html:`<tr><td>` 
QMAX_CFG_INITIAL

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - QMAX_CFG_INITIAL

        - queue max configured with initial default values

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1gga252f71bb17ef7f319490e0c89f07e5bca1330593c4f0420936cd38e647ecb249f:
.. _cid-qdma_dev_qmax_state::qmax_cfg_user:

:raw-html:`<tr><td>` 
QMAX_CFG_USER

:raw-html:`</td><td>` 


.. rubric:: Parameters:

.. list-table::
    :widths: 20 80

    *
        - QMAX_CFG_USER

        - queue max configured from sysfs as per user choice

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

