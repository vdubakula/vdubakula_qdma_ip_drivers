var searchData=
[
  ['definitions',['Definitions',['../group__libqdma__defines.html',1,'']]],
  ['data_20structures',['Data Structures',['../group__libqdma__struct.html',1,'']]]
];
