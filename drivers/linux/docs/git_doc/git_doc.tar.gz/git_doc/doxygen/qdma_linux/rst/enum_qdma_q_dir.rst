.. index:: pair: enum; qdma_q_dir
.. _doxid-group__libqdma__enums_1gafd6884069689db6ff5c38c7bc0df8ea4:
.. _cid-qdma_q_dir:

enum qdma_q_dir
---------------




.. rubric:: Overview

Direction of the queue

.. ref-code-block:: cpp
	:class: overview-code-block

	// enum values

	:ref:`QDMA_Q_DIR_H2C<doxid-group__libqdma__enums_1ggafd6884069689db6ff5c38c7bc0df8ea4ada5a9c4994b3ca19581e88dea2c1d660>` 
	:ref:`QDMA_Q_DIR_C2H<doxid-group__libqdma__enums_1ggafd6884069689db6ff5c38c7bc0df8ea4afd0f9583e9738f39c60ce11a9daaf017>` 

.. _details-doxid-group__libqdma__enums_1gafd6884069689db6ff5c38c7bc0df8ea4:


.. rubric:: Enum values

.. role:: raw-html(raw)
   :format: html

:raw-html:`<table><tr><th>Value</th><th>Description</th></tr>`

.. _doxid-group__libqdma__enums_1ggafd6884069689db6ff5c38c7bc0df8ea4ada5a9c4994b3ca19581e88dea2c1d660:
.. _cid-qdma_q_dir::qdma_q_dir_h2c:

:raw-html:`<tr><td>` 
QDMA_Q_DIR_H2C

:raw-html:`</td><td>` 
host to card

:raw-html:`</td></tr>` 



.. _doxid-group__libqdma__enums_1ggafd6884069689db6ff5c38c7bc0df8ea4afd0f9583e9738f39c60ce11a9daaf017:
.. _cid-qdma_q_dir::qdma_q_dir_c2h:

:raw-html:`<tr><td>` 
QDMA_Q_DIR_C2H

:raw-html:`</td><td>` 
card to host

:raw-html:`</td></tr>` 



:raw-html:`</table>` 

