var searchData=
[
  ['legacy_5fintr_5fmode',['LEGACY_INTR_MODE',['../group__libqdma__enums.html#ggada00378b695c456022546aec7d0e9e32ac97851070b3d86674cec11e4857837a6',1,'libqdma_export.h']]]
];
