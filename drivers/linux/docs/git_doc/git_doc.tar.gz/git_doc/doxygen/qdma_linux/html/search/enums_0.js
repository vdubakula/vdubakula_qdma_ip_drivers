var searchData=
[
  ['cmpt_5fdesc_5fsz_5ft',['cmpt_desc_sz_t',['../group__libqdma__enums.html#ga4fde724ed70ff4414fa0ab2d6bbe62d9',1,'libqdma_export.h']]]
];
