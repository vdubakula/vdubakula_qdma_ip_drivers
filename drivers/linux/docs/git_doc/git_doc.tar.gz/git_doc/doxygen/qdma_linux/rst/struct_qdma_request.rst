.. index:: pair: struct; qdma_request
.. _doxid-structqdma__request:
.. _cid-qdma_request:

struct qdma_request
-------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

qdma request for read or write

.. _doxid-structqdma__request_1a37a07f70ceae5e4288abf30ac1813463:
.. _cid-qdma_request::_pad:
.. 	
	// fields

	unsigned char :ref:`opaque<doxid-structqdma__request_1aad50743f8c56c3cd0ff9059064d28fd5>`[QDMA_REQ_OPAQUE_SIZE]
	unsigned long :ref:`uld_data<doxid-structqdma__request_1aaaa7248d2d481e7293c64fc48edcbdfc>`
	int (* :ref:`fp_done<doxid-structqdma__request_1a204cc6cbbeefcb8a8cdebf87da7ecf99>`)(struct qdma_request *req, unsigned int bytes_done, int err)
	unsigned int :ref:`timeout_ms<doxid-structqdma__request_1a372ea74bbbe306452e55cae86529d4b9>`
	unsigned int :ref:`count<doxid-structqdma__request_1afbdffe0ae2cfa59f094d484414b60211>`
	u64 :ref:`ep_addr<doxid-structqdma__request_1ae57a1c71638332402aa653e6712a8305>`
	u8 :ref:`no_memcpy<doxid-structqdma__request_1afcda577d1f496ec0eb83af91567bf78e>` :1
	u8 :ref:`write<doxid-structqdma__request_1aaf4640f77ca09e2bf2216e3775d4d877>` :1
	u8 :ref:`dma_mapped<doxid-structqdma__request_1ac1355dce7c53e2a127cb072a9060692c>` :1
	u8 :ref:`h2c_eot<doxid-structqdma__request_1aecd22d0d8c5febe656f35cf01c9beffe>` :1
	u8 :ref:`check_qstate_disabled<doxid-structqdma__request_1ad85cdc8854f2a79a092773e2efd38d9f>` :1
	u8 _pad :3
	u8 :ref:`udd_len<doxid-structqdma__request_1a51a8320397525100373ba5bf7f28dc20>`
	unsigned int :ref:`sgcnt<doxid-structqdma__request_1aa8a652f80c8c192588a8bb1a71c720c1>`
	struct :ref:`qdma_sw_sg<doxid-structqdma__sw__sg>`* :ref:`sgl<doxid-structqdma__request_1aa1c9f478fceee678c16db8a367df1ec4>`
	u8 :ref:`udd<doxid-structqdma__request_1ae9ab34bf75a56af9a3c964544d51132d>`[QDMA_UDD_MAXLEN]

.. rubric:: Fields


.. _doxid-structqdma__request_1aad50743f8c56c3cd0ff9059064d28fd5:
.. _cid-qdma_request::opaque:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned char opaque [QDMA_REQ_OPAQUE_SIZE]

private to the dma driver, do NOT touch

.. _doxid-structqdma__request_1aaaa7248d2d481e7293c64fc48edcbdfc:
.. _cid-qdma_request::uld_data:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned long uld_data

filled in by the calling function for the calling function

.. _doxid-structqdma__request_1a204cc6cbbeefcb8a8cdebf87da7ecf99:
.. _cid-qdma_request::fp_done:
.. ref-code-block:: cpp
	:class: title-code-block

	int (* fp_done )(struct qdma_request *req, unsigned int bytes_done, int err)

set fp_done for non-blocking mode

.. _doxid-structqdma__request_1a372ea74bbbe306452e55cae86529d4b9:
.. _cid-qdma_request::timeout_ms:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int timeout_ms

timeout in mili-seconds, 0 - no timeout

.. _doxid-structqdma__request_1afbdffe0ae2cfa59f094d484414b60211:
.. _cid-qdma_request::count:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int count

total data size

.. _doxid-structqdma__request_1ae57a1c71638332402aa653e6712a8305:
.. _cid-qdma_request::ep_addr:
.. ref-code-block:: cpp
	:class: title-code-block

	u64 ep_addr

MM only, DDR/BRAM memory addr

.. _doxid-structqdma__request_1afcda577d1f496ec0eb83af91567bf78e:
.. _cid-qdma_request::no_memcpy:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 no_memcpy :1

flag to indicate if memcpy is required

.. _doxid-structqdma__request_1aaf4640f77ca09e2bf2216e3775d4d877:
.. _cid-qdma_request::write:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 write :1

if write to the device

.. _doxid-structqdma__request_1ac1355dce7c53e2a127cb072a9060692c:
.. _cid-qdma_request::dma_mapped:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 dma_mapped :1

if sgt is already dma mapped

.. _doxid-structqdma__request_1aecd22d0d8c5febe656f35cf01c9beffe:
.. _cid-qdma_request::h2c_eot:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 h2c_eot :1

indicates end of transfer towards user kernel

.. _doxid-structqdma__request_1ad85cdc8854f2a79a092773e2efd38d9f:
.. _cid-qdma_request::check_qstate_disabled:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 check_qstate_disabled :1

state check disbaled in queue pkt API

.. _doxid-structqdma__request_1a51a8320397525100373ba5bf7f28dc20:
.. _cid-qdma_request::udd_len:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 udd_len

user defined data present

.. _doxid-structqdma__request_1aa8a652f80c8c192588a8bb1a71c720c1:
.. _cid-qdma_request::sgcnt:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int sgcnt

number of scatter-gather entries < 64K

.. _doxid-structqdma__request_1aa1c9f478fceee678c16db8a367df1ec4:
.. _cid-qdma_request::sgl:
.. ref-code-block:: cpp
	:class: title-code-block

	struct :ref:`qdma_sw_sg<doxid-structqdma__sw__sg>`* sgl

scatter-gather list of data bufs

.. _doxid-structqdma__request_1ae9ab34bf75a56af9a3c964544d51132d:
.. _cid-qdma_request::udd:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 udd [QDMA_UDD_MAXLEN]

udd data

