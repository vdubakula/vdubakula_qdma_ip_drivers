var searchData=
[
  ['bar_5fnum_5fbypass',['bar_num_bypass',['../structqdma__dev__conf.html#ad0aa560262137ba2d13b67ab14395676',1,'qdma_dev_conf']]],
  ['bar_5fnum_5fconfig',['bar_num_config',['../structqdma__dev__conf.html#a7bed251b6b4b16507fbf803af8788fef',1,'qdma_dev_conf']]],
  ['bar_5fnum_5fuser',['bar_num_user',['../structqdma__dev__conf.html#addde2029d0639ef0bbf077c6c9e7eefc',1,'qdma_dev_conf']]],
  ['bdf',['bdf',['../structqdma__dev__conf.html#af1e165b08d1f631e58908846af7e70fc',1,'qdma_dev_conf']]]
];
