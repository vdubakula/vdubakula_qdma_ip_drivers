var searchData=
[
  ['en_5fstat_5fdesc',['en_stat_desc',['../structqdma__cmpl__ctrl.html#abc9f3df4a90f40c001731d14fb070cd7',1,'qdma_cmpl_ctrl']]],
  ['entry',['entry',['../structqdma__ul__cmpt__info.html#aca877a815ec1d127f130541571d5dc9c',1,'qdma_ul_cmpt_info']]],
  ['eot',['eot',['../structqdma__ul__cmpt__info.html#aad9caeb082e420f7ed189a8f6a0ff12e',1,'qdma_ul_cmpt_info']]],
  ['ep_5faddr',['ep_addr',['../structqdma__request.html#ae57a1c71638332402aa653e6712a8305',1,'qdma_request']]],
  ['err',['err',['../structqdma__ul__cmpt__info.html#aa10a0a130ec850f97983bc5ecd46d439',1,'qdma_ul_cmpt_info']]]
];
