var searchData=
[
  ['indirect_5fintr_5fmode',['INDIRECT_INTR_MODE',['../group__libqdma__enums.html#ggada00378b695c456022546aec7d0e9e32a1d7531960286f3f53bde6d5b590ddb2f',1,'libqdma_export.h']]],
  ['intr_5fring_5fsz_5f12kb',['INTR_RING_SZ_12KB',['../group__libqdma__enums.html#ggab35fd77940d3f2986774dda02415447ca267fe4ad6dd47c449e20b97034c8174e',1,'libqdma_export.h']]],
  ['intr_5fring_5fsz_5f16kb',['INTR_RING_SZ_16KB',['../group__libqdma__enums.html#ggab35fd77940d3f2986774dda02415447caf10a1fba7e6117bf8092db14f3a36a96',1,'libqdma_export.h']]],
  ['intr_5fring_5fsz_5f20kb',['INTR_RING_SZ_20KB',['../group__libqdma__enums.html#ggab35fd77940d3f2986774dda02415447cae0f3468d8d3660212071b186e5ee892a',1,'libqdma_export.h']]],
  ['intr_5fring_5fsz_5f24kb',['INTR_RING_SZ_24KB',['../group__libqdma__enums.html#ggab35fd77940d3f2986774dda02415447ca5a61ded806d003f6206359c2b6b6556d',1,'libqdma_export.h']]],
  ['intr_5fring_5fsz_5f28kb',['INTR_RING_SZ_28KB',['../group__libqdma__enums.html#ggab35fd77940d3f2986774dda02415447cac27d7eac61ff0b20336d35a59041930c',1,'libqdma_export.h']]],
  ['intr_5fring_5fsz_5f32kb',['INTR_RING_SZ_32KB',['../group__libqdma__enums.html#ggab35fd77940d3f2986774dda02415447ca7b0467e09ccd3872f1484529773aa94f',1,'libqdma_export.h']]],
  ['intr_5fring_5fsz_5f4kb',['INTR_RING_SZ_4KB',['../group__libqdma__enums.html#ggab35fd77940d3f2986774dda02415447ca899e3f7ea193a1d9fa15e465ec8aad81',1,'libqdma_export.h']]],
  ['intr_5fring_5fsz_5f8kb',['INTR_RING_SZ_8KB',['../group__libqdma__enums.html#ggab35fd77940d3f2986774dda02415447ca05ace36afd05287decfd171547a98cab',1,'libqdma_export.h']]]
];
