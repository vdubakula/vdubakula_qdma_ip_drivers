.. index:: pair: struct; qdma_cmpl_ctrl
.. _doxid-structqdma__cmpl__ctrl:
.. _cid-qdma_cmpl_ctrl:

struct qdma_cmpl_ctrl
---------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

Completion control

.. 	
	// fields

	u8 :ref:`cnt_th_idx<doxid-structqdma__cmpl__ctrl_1abfc469dc23d43012300ec185b184b43c>` :4
	u8 :ref:`timer_idx<doxid-structqdma__cmpl__ctrl_1a2ba8b93f2e7fb0e49ed50df8892ed9f0>` :4
	u8 :ref:`trigger_mode<doxid-structqdma__cmpl__ctrl_1afa7aba3bd3582c8ca6e2067f5e7f80d3>` :3
	u8 :ref:`en_stat_desc<doxid-structqdma__cmpl__ctrl_1abc9f3df4a90f40c001731d14fb070cd7>` :1
	u8 :ref:`cmpl_en_intr<doxid-structqdma__cmpl__ctrl_1ab5f33e2efb09e61be66f6d264639cab2>` :1

.. rubric:: Fields


.. _doxid-structqdma__cmpl__ctrl_1abfc469dc23d43012300ec185b184b43c:
.. _cid-qdma_cmpl_ctrl::cnt_th_idx:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cnt_th_idx :4

:ref:`global_csr_conf.c2h_cnt_th <doxid-structglobal__csr__conf_1a75b3e18b9bbee2f3a2336fc7539621a0>` [N]

.. _doxid-structqdma__cmpl__ctrl_1a2ba8b93f2e7fb0e49ed50df8892ed9f0:
.. _cid-qdma_cmpl_ctrl::timer_idx:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 timer_idx :4

:ref:`global_csr_conf.c2h_timer_cnt <doxid-structglobal__csr__conf_1a42511a376379a905e6d7566cb1198523>` [N]

.. _doxid-structqdma__cmpl__ctrl_1afa7aba3bd3582c8ca6e2067f5e7f80d3:
.. _cid-qdma_cmpl_ctrl::trigger_mode:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 trigger_mode :3

tigger_mode

.. _doxid-structqdma__cmpl__ctrl_1abc9f3df4a90f40c001731d14fb070cd7:
.. _cid-qdma_cmpl_ctrl::en_stat_desc:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 en_stat_desc :1

enable status desc. for CMPT

.. _doxid-structqdma__cmpl__ctrl_1ab5f33e2efb09e61be66f6d264639cab2:
.. _cid-qdma_cmpl_ctrl::cmpl_en_intr:
.. ref-code-block:: cpp
	:class: title-code-block

	u8 cmpl_en_intr :1

enable interrupt for CMPT

