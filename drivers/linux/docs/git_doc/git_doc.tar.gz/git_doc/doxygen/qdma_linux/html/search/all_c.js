var searchData=
[
  ['offset',['offset',['../structqdma__sw__sg.html#a06cc841f6346cc20f1cc21fef6bcd553',1,'qdma_sw_sg']]],
  ['opaque',['opaque',['../structqdma__request.html#aad50743f8c56c3cd0ff9059064d28fd5',1,'qdma_request']]]
];
