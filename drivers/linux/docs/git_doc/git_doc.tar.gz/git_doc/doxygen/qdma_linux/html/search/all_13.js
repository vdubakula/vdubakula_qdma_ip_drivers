var searchData=
[
  ['vf_5fmax',['vf_max',['../structqdma__dev__conf.html#a1181cf69efbbd62ddc4fbda29eee7e88',1,'qdma_dev_conf']]],
  ['vivado_5frelease_5fstr',['vivado_release_str',['../structqdma__version__info.html#af428d093fe3e43f44e9d7c2db8f21c58',1,'qdma_version_info']]]
];
