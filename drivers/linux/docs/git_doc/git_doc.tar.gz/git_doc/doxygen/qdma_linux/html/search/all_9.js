var searchData=
[
  ['latency_5foptimize',['latency_optimize',['../structqdma__queue__conf.html#a0b3b7459a543fbc95f8ebc0d1cf2a23c',1,'qdma_queue_conf']]],
  ['legacy_5fintr_5fmode',['LEGACY_INTR_MODE',['../group__libqdma__enums.html#ggada00378b695c456022546aec7d0e9e32ac97851070b3d86674cec11e4857837a6',1,'libqdma_export.h']]],
  ['len',['len',['../structqdma__ul__cmpt__info.html#a6d1114401843edb7ddf8fb7861e8b5ba',1,'qdma_ul_cmpt_info::len()'],['../structqdma__sw__sg.html#a0731ded530a969f19abdff2773fa422c',1,'qdma_sw_sg::len()']]],
  ['libqdma_5fexit',['libqdma_exit',['../libqdma__export_8h.html#ae17b39672d285044885a0637dbdf45d1',1,'libqdma_export.h']]],
  ['libqdma_5fexport_2eh',['libqdma_export.h',['../libqdma__export_8h.html',1,'']]],
  ['libqdma_5finit',['libqdma_init',['../libqdma__export_8h.html#a9be491da0929478d3669f05c31ec4aa0',1,'libqdma_export.h']]]
];
