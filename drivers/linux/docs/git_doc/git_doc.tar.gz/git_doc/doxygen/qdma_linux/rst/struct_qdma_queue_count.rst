.. index:: pair: struct; qdma_queue_count
.. _doxid-structqdma__queue__count:
.. _cid-qdma_queue_count:

struct qdma_queue_count
-----------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

QDMA queue count

.. 	
	// fields

	u32 :ref:`h2c_qcnt<doxid-structqdma__queue__count_1ae73ecad7e011a0eb4351129198f3dcd8>`
	u32 :ref:`c2h_qcnt<doxid-structqdma__queue__count_1a4d7947220b57685ee3a3e06f268475d2>`
	u32 :ref:`cmpt_qcnt<doxid-structqdma__queue__count_1a20a338085f83846e5aeee83bfbd4ebfa>`

.. rubric:: Fields


.. _doxid-structqdma__queue__count_1ae73ecad7e011a0eb4351129198f3dcd8:
.. _cid-qdma_queue_count::h2c_qcnt:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 h2c_qcnt

H2C queue count

.. _doxid-structqdma__queue__count_1a4d7947220b57685ee3a3e06f268475d2:
.. _cid-qdma_queue_count::c2h_qcnt:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 c2h_qcnt

C2H queue count

.. _doxid-structqdma__queue__count_1a20a338085f83846e5aeee83bfbd4ebfa:
.. _cid-qdma_queue_count::cmpt_qcnt:
.. ref-code-block:: cpp
	:class: title-code-block

	u32 cmpt_qcnt

CMPT queue count

