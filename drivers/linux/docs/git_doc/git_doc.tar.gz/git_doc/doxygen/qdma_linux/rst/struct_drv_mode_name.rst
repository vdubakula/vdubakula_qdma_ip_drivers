.. index:: pair: struct; drv_mode_name
.. _doxid-structdrv__mode__name:
.. _cid-drv_mode_name:

struct drv_mode_name
--------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

Structure to hold the driver name and mode

Mode can be set for each PF or VF group using module parameters Refer enum qdma_drv_mode for different mode options

.. 	
	// fields

	enum :ref:`qdma_drv_mode<doxid-group__libqdma__enums_1gada00378b695c456022546aec7d0e9e32>` :ref:`drv_mode<doxid-structdrv__mode__name_1a1d4257c25b4178d82fbd13ed282e417c>`
	char :ref:`name<doxid-structdrv__mode__name_1a7a689a355f387c592c2f3e45e2ba1f86>`[20]

.. rubric:: Fields


.. _doxid-structdrv__mode__name_1a1d4257c25b4178d82fbd13ed282e417c:
.. _cid-drv_mode_name::drv_mode:
.. ref-code-block:: cpp
	:class: title-code-block

	enum :ref:`qdma_drv_mode<doxid-group__libqdma__enums_1gada00378b695c456022546aec7d0e9e32>` drv_mode

Mode of the function

.. _doxid-structdrv__mode__name_1a7a689a355f387c592c2f3e45e2ba1f86:
.. _cid-drv_mode_name::name:
.. ref-code-block:: cpp
	:class: title-code-block

	char name [20]

Driver Name

