.. index:: pair: struct; global_csr_conf
.. _doxid-structglobal__csr__conf:
.. _cid-global_csr_conf:

struct global_csr_conf
----------------------


.. code-block:: cpp
	:class: overview-code-block

	#include "libqdma_export.h"






.. rubric:: Overview

global CSR configuration

.. 	
	// fields

	unsigned int :ref:`ring_sz<doxid-structglobal__csr__conf_1a267c2b0898276a84d13c1206e10d2672>`[QDMA_GLOBAL_CSR_ARRAY_SZ]
	unsigned int :ref:`c2h_timer_cnt<doxid-structglobal__csr__conf_1a42511a376379a905e6d7566cb1198523>`[QDMA_GLOBAL_CSR_ARRAY_SZ]
	unsigned int :ref:`c2h_cnt_th<doxid-structglobal__csr__conf_1a75b3e18b9bbee2f3a2336fc7539621a0>`[QDMA_GLOBAL_CSR_ARRAY_SZ]
	unsigned int :ref:`c2h_buf_sz<doxid-structglobal__csr__conf_1a66e744c84d47c7b26737c770a0a993d4>`[QDMA_GLOBAL_CSR_ARRAY_SZ]
	unsigned int :ref:`wb_intvl<doxid-structglobal__csr__conf_1a4a09a626ca50257f82e8c316996154ec>`

.. rubric:: Fields


.. _doxid-structglobal__csr__conf_1a267c2b0898276a84d13c1206e10d2672:
.. _cid-global_csr_conf::ring_sz:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int ring_sz [QDMA_GLOBAL_CSR_ARRAY_SZ]

Descriptor ring size ie. queue depth

.. _doxid-structglobal__csr__conf_1a42511a376379a905e6d7566cb1198523:
.. _cid-global_csr_conf::c2h_timer_cnt:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int c2h_timer_cnt [QDMA_GLOBAL_CSR_ARRAY_SZ]

C2H timer count list

.. _doxid-structglobal__csr__conf_1a75b3e18b9bbee2f3a2336fc7539621a0:
.. _cid-global_csr_conf::c2h_cnt_th:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int c2h_cnt_th [QDMA_GLOBAL_CSR_ARRAY_SZ]

C2H counter threshold list

.. _doxid-structglobal__csr__conf_1a66e744c84d47c7b26737c770a0a993d4:
.. _cid-global_csr_conf::c2h_buf_sz:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int c2h_buf_sz [QDMA_GLOBAL_CSR_ARRAY_SZ]

C2H buffer size list

.. _doxid-structglobal__csr__conf_1a4a09a626ca50257f82e8c316996154ec:
.. _cid-global_csr_conf::wb_intvl:
.. ref-code-block:: cpp
	:class: title-code-block

	unsigned int wb_intvl

Writeback interval

