var searchData=
[
  ['h2c_5feot',['h2c_eot',['../structqdma__request.html#aecd22d0d8c5febe656f35cf01c9beffe',1,'qdma_request']]],
  ['h2c_5fqcnt',['h2c_qcnt',['../structqdma__queue__count.html#ae73ecad7e011a0eb4351129198f3dcd8',1,'qdma_queue_count']]]
];
