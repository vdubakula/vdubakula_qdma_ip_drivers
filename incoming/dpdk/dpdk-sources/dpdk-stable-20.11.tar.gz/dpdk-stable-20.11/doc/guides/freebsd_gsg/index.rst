..  SPDX-License-Identifier: BSD-3-Clause
    Copyright(c) 2010-2014 Intel Corporation.

.. _freebsd_gsg:

Getting Started Guide for FreeBSD
=================================

.. toctree::
    :maxdepth: 2
    :numbered:

    intro
    install_from_ports
    build_dpdk
    build_sample_apps
    freebsd_eal_parameters
